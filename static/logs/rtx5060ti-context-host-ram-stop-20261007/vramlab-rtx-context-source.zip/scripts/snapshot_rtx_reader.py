#!/usr/bin/env python3
"""Verify the exact fresh reader build; never install, build, or run a request.

Copy alongside the package scripts before use. Evidence stays under the one
reader reproduction directory. No CUDA device query or completion request is
made here. All children remain in the Windows guard-owned process group.
"""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import subprocess
import time

PACKAGE = Path(__file__).resolve().parents[1]
DATA = PACKAGE / 'data/rtx'
REPRO = DATA / 'reproduction-20261007'
BUILD = REPRO / 'build'
SOURCE = DATA / 'llama.cpp'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def guard_check():
    """No GPU query: the owning host guard supplies current health."""
    if os.environ.get('WSL_DISTRO_NAME') != 'VRAMLab-RTX-Context':
        raise RuntimeError('Wrong experiment guest')
    directory = os.environ.get('VRAMLAB_GUARD_DIRECTORY')
    if not directory or not Path(directory).resolve().is_relative_to((DATA / 'guards').resolve()):
        raise RuntimeError('Exact package Windows guard required')
    sample = read(Path(directory) / 'heartbeat.json')
    numeric = (sample['time'], sample['available_ram_bytes'], sample['disk_free_bytes'])
    if any(isinstance(v, bool) or not math.isfinite(float(v)) for v in numeric):
        raise RuntimeError('Malformed guard heartbeat')
    age = time.time() - sample['time']
    if age < -2 or age > 8 or sample['abort']:
        raise RuntimeError('Guard stale or aborted: ' + str(sample.get('abort')))
    if sample['available_ram_bytes'] < 2 * 1024**3 or sample['disk_free_bytes'] < 5 * 1024**3:
        raise RuntimeError('Host RAM or work disk safety cutoff')
    return sample


def sanitized_environment():
    env = {k: v for k, v in os.environ.items()
           if not k.startswith(('LLAMA_ARG_', 'GGML_', 'CUDA_', 'LD_'))}
    env.update(LD_LIBRARY_PATH='/usr/local/cuda-13.2/lib64:/usr/lib/wsl/lib',
               CUDA_VISIBLE_DEVICES='0', OMP_NUM_THREADS='4')
    return env


def stable_hash(path, check):
    """Hash an actual file while checking the host; reject concurrent changes."""
    path = Path(path)
    resolved = path.resolve(strict=True)
    digest = hashlib.sha256()
    with resolved.open('rb') as stream:
        before = os.fstat(stream.fileno())
        for chunk in iter(lambda: stream.read(8 * 1024**2), b''):
            check()
            digest.update(chunk)
        after = os.fstat(stream.fileno())
    identity = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    if identity(before) != identity(after) or identity(after) != identity(resolved.stat()):
        raise ValueError('File changed during hashing: ' + str(path))
    return {'resolved': str(resolved), 'bytes': after.st_size, 'sha256': digest.hexdigest()}


def run(argv, env, check, timeout=30):
    check()
    completed = subprocess.run(argv, env=env, capture_output=True, text=True,
                               timeout=timeout, check=True)
    check()
    return completed.stdout


def checked_cache():
    cache = {}
    for line in (BUILD / 'CMakeCache.txt').read_text().splitlines():
        match = re.match(r'^([^#/:][^:]*):[^=]*=(.*)$', line)
        if match:
            cache[match[1]] = match[2]
    expected = {'GGML_CUDA': 'ON', 'CMAKE_BUILD_TYPE': 'Release',
                'CMAKE_CUDA_ARCHITECTURES': '120-real', 'GGML_CUDA_FA_QUANTS': 'f16-f16',
                'CMAKE_CUDA_COMPILER': '/usr/local/cuda-13.2/bin/nvcc',
                'CMAKE_CUDA_HOST_COMPILER': '/usr/bin/g++',
                'CMAKE_C_COMPILER': '/usr/bin/gcc', 'CMAKE_CXX_COMPILER': '/usr/bin/g++',
                'CMAKE_GENERATOR': 'Ninja', 'LLAMA_OPENSSL': 'OFF', 'LLAMA_BUILD_TESTS': 'OFF',
                'CMAKE_C_COMPILER_LAUNCHER': '', 'CMAKE_CXX_COMPILER_LAUNCHER': '',
                'CMAKE_CUDA_COMPILER_LAUNCHER': ''}
    if any(cache.get(k) != v for k, v in expected.items()):
        raise ValueError('Reader CMake/toolchain/cache flags differ from fixed build')
    return expected


def checked_inputs(check, source_directory=None, model=None):
    from rtx_measure import input_manifest
    check()
    source = SOURCE if source_directory is None else Path(source_directory)
    lock_path = PACKAGE / 'inputs.lock.json'
    lock = read(lock_path)
    expected_model = DATA / 'models' / lock['model']['filename']
    model = expected_model if model is None else Path(model)
    if source.resolve() != SOURCE.resolve() or model.resolve() != expected_model.resolve():
        raise ValueError('Reader source/model overrides must be the locked existing inputs')
    expected = input_manifest()
    env = sanitized_environment()
    commit = run(['git', '-C', str(source), 'rev-parse', 'HEAD'], env, check).strip()
    dirty = run(['git', '-C', str(source), '-c', 'core.filemode=false', 'status', '--porcelain'], env, check)
    tree = run(['git', '-C', str(source), 'rev-parse', 'HEAD^{tree}'], env, check).strip()
    if commit != lock['llama_cpp']['commit'] or dirty:
        raise ValueError('Locked source commit/content changed')
    actual_model = stable_hash(model, check)
    if actual_model['bytes'] != lock['model']['bytes'] or actual_model['sha256'] != lock['model']['sha256']:
        raise ValueError('Actual full model hash/size differs from lock')
    full_tokens = read(PACKAGE / 'fixtures/rtx-tokenizer.json')['tokens']
    for context in (2048, 4096, 8192, 16384):
        tokens = read(PACKAGE / f'fixtures/rtx-tokens-{context}.json')
        if (len(tokens) != context - 256 or any(type(t) is not int or t < 0 for t in tokens)
                or tokens != full_tokens[:context - 256]):
            raise ValueError('Fixture count/type/tokenizer prefix mismatch')
    if input_manifest() != expected:
        raise ValueError('Inputs changed during verification')
    if (run(['git', '-C', str(source), 'rev-parse', 'HEAD'], env, check).strip() != commit
            or run(['git', '-C', str(source), '-c', 'core.filemode=false', 'status', '--porcelain'], env, check)):
        raise ValueError('Source changed during input verification')
    return {'source_commit': commit, 'source_status': dirty, 'source_tree': tree,
            'source_directory': str(source.resolve()), 'model_actual': actual_model,
            'input_verification': expected,
            'loader_environment': {k: env[k] for k in ('LD_LIBRARY_PATH', 'CUDA_VISIBLE_DEVICES', 'OMP_NUM_THREADS')}}


def reserve_evidence(destination):
    destination = Path(destination)
    if (REPRO.is_symlink() or BUILD.is_symlink()
            or not REPRO.resolve().is_relative_to(DATA.resolve())
            or destination.resolve() == REPRO.resolve()
            or not destination.parent.resolve(strict=True).is_relative_to(REPRO.resolve())):
        raise ValueError('Evidence must stay inside the exact reader reproduction directory')
    sidecar = destination.with_name(destination.name + '.verification.json')
    if destination.exists() or sidecar.exists() or destination.is_symlink() or sidecar.is_symlink():
        raise FileExistsError('Fresh evidence paths required')
    return destination, sidecar


def write_new(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def capture(destination, build_directory, source_directory=None, model=None, guard_callback=None):
    """Return a runner-compatible verified runtime and its verification sidecar.

    build_directory must be the exact new reproduction build. No original build
    is accepted. guard_callback=rtx_measure.host_health is suitable for a reader
    driver with GPU telemetry; default guard_check also permits no-GPU setup.
    """
    from rtx_measure import binding_fingerprint, input_manifest
    check = guard_callback or guard_check
    check()
    if Path(build_directory).resolve() != BUILD or REPRO.is_symlink() or BUILD.is_symlink():
        raise ValueError('Exact alternate reader build required')
    destination, sidecar = reserve_evidence(destination)
    receipt = {'status': 'started', 'started_epoch': time.time(), 'scope': 'reader_only'}
    try:
        result = checked_inputs(check, source_directory, model)
        env = sanitized_environment()
        cache_flags = checked_cache()
        paths = {BUILD / 'bin/llama-server', BUILD / 'CMakeCache.txt'}
        paths.update((BUILD / 'bin').glob('*.so*'))
        linkage = {}
        for name in ('llama-server', 'libggml-cuda.so'):
            output = run(['ldd', str(BUILD / 'bin' / name)], env, check)
            if 'not found' in output:
                raise ValueError('Unresolved reader runtime library')
            linkage[name] = output
            for line in output.splitlines():
                match = re.search(r'=> (/.+?) \(', line) or re.search(r'^\s*(/.+?) \(', line)
                if match:
                    paths.add(Path(match[1]))
        result.update(time=time.time(), files={str(p): stable_hash(p, check) for p in sorted(paths)},
                      ldd=linkage, reader_build_directory=str(BUILD),
                      checked_cmake_flags=cache_flags,
                      scope='reader_only_existing_guest_source_and_toolchain',
                      closure_limit='Listed build objects and ldd-resolved libraries; no claim to all possible dlopen paths',
                      reader_scripts_sha256={p.name: stable_hash(p, check)['sha256'] for p in
                          (Path(__file__), PACKAGE / 'scripts/build_rtx_reader.sh')})
        if input_manifest() != result['input_verification']:
            raise ValueError('Inputs changed while collecting reader closure')
        if (run(['git', '-C', str(SOURCE), 'rev-parse', 'HEAD'], env, check).strip() != result['source_commit']
                or run(['git', '-C', str(SOURCE), '-c', 'core.filemode=false', 'status', '--porcelain'], env, check)):
            raise ValueError('Source changed while collecting reader closure')
        check()
        write_new(destination, result)
        receipt.update(status='PASS', runtime_sha256=stable_hash(destination, check)['sha256'],
                       input_binding_fingerprint=binding_fingerprint(result))
        return result
    except Exception as error:
        receipt.update(status='FAIL', failure_class='instrumentation_invalid', error=f'{type(error).__name__}: {error}')
        raise
    finally:
        receipt['finished_epoch'] = time.time()
        write_new(sidecar, receipt)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('destination', type=Path, nargs='?')
    parser.add_argument('--build-directory', type=Path, default=BUILD)
    parser.add_argument('--inputs-only', action='store_true')
    parser.add_argument('--check-guard', action='store_true')
    args = parser.parse_args()
    if args.check_guard:
        guard_check()
        return
    if args.destination is None:
        parser.error('destination required')
    if args.inputs_only:
        destination, _ = reserve_evidence(args.destination)
        result = checked_inputs(guard_check)
        result.update(scope='reader_build_input_check_only', time=time.time())
        guard_check()
        write_new(destination, result)
    else:
        capture(args.destination, args.build_directory)
    print('Reader input/closure evidence written: ' + str(args.destination), flush=True)


if __name__ == '__main__':
    main()
