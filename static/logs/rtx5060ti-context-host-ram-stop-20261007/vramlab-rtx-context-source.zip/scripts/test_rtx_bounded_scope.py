#!/usr/bin/env python3
"""Synthetic no-GPU controls. No WSL, network, real engine or real model import."""
import copy
import importlib.util
import json
import os
from pathlib import Path
import tempfile
import time
import types
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent


class FakeClock:
    def __init__(self):
        self.now = 0.0

    def monotonic(self):
        return self.now

    def sleep(self, duration):
        self.now += duration


def synthetic_sample(now=0, ram=6 * 1024**3, gpu=2000, util=2):
    return {'monotonic': now, 'epoch': 1000 + now, 'host': {
        'time': 1000 + now, 'abort': None, 'available_ram_bytes': ram,
        'disk_free_bytes': 10 * 1024**3,
        'gpu': {'total_mib': '16000', 'used_mib': str(gpu), 'utilization_percent': str(util)}},
        'guest_available_bytes': 5 * 1024**3, 'guest_swap_used_bytes': 0,
        'process_rss_bytes': None, 'process_hwm_bytes': None, 'process_status_raw': None,
        'meminfo_raw': 'MemAvailable: 5242880 kB\nSwapTotal: 0 kB\nSwapFree: 0 kB\n',
        'guest_swap_counters_pages': {'pswpin': 0, 'pswpout': 0}, 'sample_duration_s': 0.001}


def load_driver():
    fake = types.ModuleType('rtx_measure')
    fake.BindingError = type('BindingError', (ValueError,), {})
    fake.CONTEXTS = (2048, 4096, 8192, 16384)
    fake.trial = lambda *args, **kwargs: None
    fake.utc = lambda: '2026-10-07T00:00:00Z'
    fake.classify_failure = lambda error: 'instrumentation_invalid'
    fake.binding_identity = lambda runtime: runtime
    fake.host_health = lambda: {'time': time.time(), 'abort': None}
    fake.memory_sample = lambda: (_ for _ in ()).throw(AssertionError('Real sample must never be called'))
    fake.fcntl = types.SimpleNamespace(LOCK_EX=1, LOCK_NB=2, flock=lambda *args: None)
    valid = types.ModuleType('validate_rtx_trial')
    valid.validate = lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError('Real validator must never be called'))
    spec = importlib.util.spec_from_file_location('rtx_bounded_scope_controls', HERE / 'rtx_bounded_scope.py')
    module = importlib.util.module_from_spec(spec)
    with patch.dict('sys.modules', {'rtx_measure': fake, 'validate_rtx_trial': valid}):
        # compile/exec avoids creating a source cache in the staging installation.
        exec(compile((HERE / 'rtx_bounded_scope.py').read_text(encoding='utf-8'), str(HERE / 'rtx_bounded_scope.py'), 'exec'), module.__dict__)
    return module


class Controls(unittest.TestCase):
    def setUp(self):
        # Keep all created and recursively cleaned test paths under this exact
        # writable staging directory rather than the Windows sandbox temp ACL.
        self.tmp = tempfile.TemporaryDirectory(prefix='synthetic-', dir=HERE)
        self.addCleanup(self.tmp.cleanup)
        self.d = load_driver()
        self.pkg = Path(self.tmp.name).resolve()
        self.d.PACKAGE = self.pkg
        self.d.DATA = self.pkg / 'data/rtx'
        self.d.RUN = self.d.DATA / 'article-20261007'
        self.d.SCOUTS = self.d.RUN / 'scouts-v4'
        self.d.BASE = self.d.RUN / 'bounded-v1'
        self.d.DRIVER = self.pkg / 'scripts/rtx_bounded_scope.py'
        self.d.DERIVED = self.d.BASE / 'protocol-derived.json'
        self.d.PROTOCOL = self.d.BASE / 'protocol.json'
        self.d.PRIMARY = self.d.BASE / 'primary'
        self.d.SETTLING = self.d.BASE / 'settling'
        self.d.__file__ = str(self.d.DRIVER)
        (self.pkg / 'scripts').mkdir()
        self.d.SCOUTS.mkdir(parents=True)
        self.d.BASE.mkdir()
        self.d.SETTLING.mkdir()
        for name in self.d.CORE_SHA256:
            (self.pkg / 'scripts' / name).write_text('synthetic-' + name, encoding='utf-8')
        self.d.CORE_SHA256 = {name: self.d.sha(self.pkg / 'scripts' / name) for name in self.d.CORE_SHA256}
        self.d.DRIVER.write_text('synthetic ancillary driver', encoding='utf-8')
        self.d.core.PACKAGE, self.d.core.DATA = self.pkg, self.d.DATA
        self.d.core.__file__ = str(self.pkg / 'scripts/rtx_measure.py')
        self.d.validator.__file__ = str(self.pkg / 'scripts/validate_rtx_trial.py')
        self.model = self.d.DATA / 'models/model.gguf'
        self.model.parent.mkdir()
        self.model.write_bytes(b'only synthetic small model bytes')
        self.lock = {'model': {'filename': self.model.name, 'bytes': self.model.stat().st_size,
                               'sha256': self.d.sha(self.model)}}
        self.put(self.pkg / 'inputs.lock.json', self.lock)
        self.guard = self.d.DATA / 'guards/fake-primary'
        self.guard.mkdir(parents=True)
        self.put(self.guard / 'command.json', {'command': ['python3', str(self.d.DRIVER), 'primary'],
            'timeout': 15480, 'min_host_ram_bytes': 2 * 1024**3, 'min_disk_bytes': 5 * 1024**3})
        (self.guard / 'host-memory.jsonl').write_text(json.dumps({'time': time.time() - 1}) + '\n', encoding='utf-8')
        self.env = patch.dict(os.environ, {'WSL_DISTRO_NAME': 'VRAMLab-RTX-Context', 'VRAMLAB_GUARD_DIRECTORY': str(self.guard)})
        self.env.start()
        self.addCleanup(self.env.stop)
        self.clock = FakeClock()

    def put(self, path, value):
        path.write_text(json.dumps(value), encoding='utf-8')

    def samples(self):
        return [synthetic_sample(i) for i in range(30)]

    def fake_hash(self, path):
        self.d.write_new(path, {'status': 'PASS', 'elapsed_seconds': 0,
                               'actual_sha256': self.lock['model']['sha256'], 'bytes_read': self.lock['model']['bytes']})

    def settle(self, fn):
        return self.d.settle_before_trial(self.d.expected_order()[0], 0, 'protocol', 'driver',
            sample_fn=fn, monotonic=self.clock.monotonic, sleep=self.clock.sleep, hash_fn=self.fake_hash)

    def protocol(self):
        derived = {'original_conditions': copy.deepcopy(self.d.CONDITIONS), 'retained': copy.deepcopy(self.d.CONDITIONS),
            'excluded': [], 'order': self.d.expected_order(), 'guard_budget_seconds': 390 * 18 + 900}
        self.put(self.d.DERIVED, derived)
        result = self.d.extend_protocol(derived, [], {'actual': 'history'}, {'actual': 'inventory'})
        self.put(self.d.PROTOCOL, result)
        self.d.core.check_protocol = lambda path: self.d.read(path)
        return result

    def scope_check(self):
        with patch.object(self.d, 'validate_scouts', return_value=[]), patch.object(self.d, 'historical_scope', return_value={'actual': 'history'}), \
                patch.object(self.d, 'history_inventory', return_value={'actual': 'inventory'}):
            return self.d.check_scope_protocol()

    def wrapper_state(self):
        self.put(self.d.PROTOCOL, {})
        return {'actual_trial_calls': 0, 'settling_records': [], 'driver_sha256_before': self.d.sha(self.d.DRIVER),
            'core_scripts_sha256_before': self.d.CORE_SHA256.copy(), 'protocol_sha256': self.d.sha(self.d.PROTOCOL),
            'guard_directory': str(self.guard), 'outer_guard_budget_seconds': 15480, 'started_monotonic': time.monotonic()}

    def fake_settle(self, item, index, protocol_sha, driver_sha):
        folder = self.d.SETTLING / item['id']
        folder.mkdir()
        state = {'status': 'PASS', 'original_trial_called': False, 'model_hash_sha256': 'synthetic'}
        self.put(folder / 'settling.json', state)
        return state

    def original_success(self, out, *args, **kwargs):
        out.mkdir(parents=True)
        result = {'status': 'completed_pending_validation', 'server_pid': 99}
        self.put(out / 'result.json', result)
        return result

    def freeze_receipt(self):
        protocol = self.protocol()
        guard = self.d.DATA / 'guards/fake-freeze'
        guard.mkdir()
        self.put(guard / 'command.json', {'command': ['python3', str(self.d.DRIVER), 'freeze'], 'timeout': 600})
        self.put(guard / 'host-result.json', {'exit_code': 0, 'abort': None})
        self.put(guard / 'guest-result.json', {'exit_code': 0, 'abort': None, 'child_group_cleanup_attempted': True})
        frozen = {'phase': 'freeze', 'status': 'frozen_bounded_scope', 'success': True, 'driver_exit_code': 0,
            'scope_id': 'bounded-v1', 'actual_trial_calls': 0, 'immutable_history': True,
            'driver_sha256_before': self.d.sha(self.d.DRIVER), 'driver_sha256_after': self.d.sha(self.d.DRIVER),
            'core_scripts_sha256_before': self.d.CORE_SHA256, 'core_scripts_sha256_after': self.d.CORE_SHA256,
            'protocol_sha256': self.d.sha(self.d.PROTOCOL), 'derived_protocol_sha256': self.d.sha(self.d.DERIVED),
            'historical_inventory_before_sha256': protocol['historical_inventory_sha256'],
            'historical_inventory_after_sha256': protocol['historical_inventory_sha256'],
            'guard_directory': str(guard), 'guard_command_sha256': self.d.sha(guard / 'command.json')}
        self.put(self.d.BASE / 'freeze-driver-receipt.json', frozen)
        return protocol, frozen, guard

    def test_01_balanced_order_is_exact_eighteen(self):
        order = self.d.expected_order()
        self.assertEqual(len(order), 18)
        self.assertEqual([[r['context'], r['gpu_layers']] for r in order[:6]], self.d.CONDITIONS)
        self.assertEqual(order[6]['context'], 8192)
        self.assertEqual(order[12]['context'], 4096)
        self.assertEqual(len({r['id'] for r in order}), 18)

    def test_02_budget_and_scope_use_final_prospective_contract(self):
        protocol = self.protocol()
        self.assertEqual(protocol['guard_budget_seconds'], 7920)
        self.assertEqual(protocol['outer_guard_budget_seconds'], 15480)
        self.assertEqual(protocol['scope_contract']['historical_eight_condition_contract'], 'NOT_MET')
        self.assertEqual(protocol['scope_contract']['core_trial_wrapper'], 'pretrial_model_hash_then_settling_only')
        self.assertEqual(protocol['per_trial_model_hash']['max_elapsed_seconds'], 120)

    def test_03_context_and_callable_restore_on_failure(self):
        original = self.d.core.trial
        with self.assertRaises(RuntimeError):
            with self.d.bounded_core(lambda: None):
                self.assertEqual(self.d.core.CONTEXTS, (2048, 4096, 8192))
                raise RuntimeError('synthetic stop')
        self.assertEqual(self.d.core.CONTEXTS, self.d.ORIGINAL_CONTEXTS)
        self.assertIs(self.d.core.trial, original)

    def test_04_existing_global_override_rejected(self):
        self.d.core.CONTEXTS = (2048,)
        with self.assertRaises(self.d.ScopeError):
            with self.d.bounded_core():
                pass

    def test_05_clean_window_recomputes_finite_summary(self):
        summary, failures = self.d.summarize_window(self.samples())
        self.assertEqual(failures, [])
        self.assertEqual(summary['unique_host_queries'], 30)
        self.assertEqual(summary['max_effective_gpu_gap_seconds'], 1)

    def test_06_thresholds_are_inclusive_and_unchanged(self):
        samples = self.samples()
        samples[-1]['host']['available_ram_bytes'] += 512 * 1024**2
        samples[-1]['host']['gpu']['used_mib'] = '2128'
        for s in samples:
            s['host']['gpu']['utilization_percent'] = '10'
        self.assertEqual(self.d.summarize_window(samples)[1], [])

    def test_07_ram_spread_wait_is_not_model_failure(self):
        samples = self.samples()
        samples[-1]['host']['available_ram_bytes'] += 513 * 1024**2
        self.assertEqual(self.d.summarize_window(samples)[1], ['host_ram_spread'])

    def test_08_vram_spread_wait(self):
        samples = self.samples()
        samples[-1]['host']['gpu']['used_mib'] = '2129'
        self.assertEqual(self.d.summarize_window(samples)[1], ['global_vram_spread'])

    def test_09_utilization_wait(self):
        samples = self.samples()
        for s in samples:
            s['host']['gpu']['utilization_percent'] = '11'
        self.assertEqual(self.d.summarize_window(samples)[1], ['gpu_utilization'])

    def test_10_stale_heartbeat_fails(self):
        sample = synthetic_sample()
        sample['host']['time'] -= 9
        with self.assertRaises(self.d.ScopeError):
            self.d.check_sample(sample)

    def test_11_future_heartbeat_fails(self):
        sample = synthetic_sample()
        sample['host']['time'] += 1
        with self.assertRaises(self.d.ScopeError):
            self.d.check_sample(sample)

    def test_12_nonfinite_gpu_rejected(self):
        sample = synthetic_sample()
        sample['host']['gpu']['used_mib'] = 'nan'
        with self.assertRaises(self.d.ScopeError):
            self.d.check_sample(sample)

    def test_13_boolean_numeric_rejected(self):
        sample = synthetic_sample()
        sample['host']['available_ram_bytes'] = True
        with self.assertRaises(self.d.ScopeError):
            self.d.check_sample(sample)

    def test_14_hard_floor_is_immediate_failure(self):
        sample = synthetic_sample(ram=2 * 1024**3 - 1)
        with self.assertRaises(self.d.ScopeError):
            self.d.check_sample(sample)

    def test_15_guard_abort_is_not_threshold_retry(self):
        sample = synthetic_sample()
        sample['host']['abort'] = 'host_ram_below_2gib'
        with self.assertRaises(self.d.ScopeError):
            self.d.check_sample(sample)

    def test_16_cadence_gap_fails(self):
        samples = self.samples()
        samples[-1]['monotonic'] += 4
        with self.assertRaises(self.d.ScopeError):
            self.d.summarize_window(samples)

    def test_17_duplicate_host_read_is_one_gpu_observation(self):
        samples = self.samples()
        for i in range(1, 30, 2):
            samples[i]['host'] = copy.deepcopy(samples[i-1]['host'])
        self.assertEqual(self.d.summarize_window(samples)[0]['unique_host_queries'], 15)

    def test_18_same_host_time_different_raw_fails(self):
        samples = self.samples()
        samples[1]['host']['time'] = samples[0]['host']['time']
        samples[1]['host']['available_ram_bytes'] += 1
        with self.assertRaises(self.d.ScopeError):
            self.d.summarize_window(samples)

    def test_19_fewer_than_twenty_five_observations_fail(self):
        with self.assertRaises(self.d.ScopeError):
            self.d.summarize_window(self.samples()[:24])

    def test_20_full_raw_meminfo_required(self):
        sample = synthetic_sample()
        sample['meminfo_raw'] = ''
        with self.assertRaises(self.d.ScopeError):
            self.d.check_sample(sample)

    def test_21_one_pass_window_is_thirty_seconds(self):
        state = self.settle(lambda: synthetic_sample(self.clock.now))
        self.assertEqual(state['status'], 'PASS')
        self.assertEqual(state['elapsed_seconds'], 30)
        self.assertFalse(state['original_trial_called'])
        window = self.d.read(Path(state['windows'][0]['source']) / 'window.json')
        self.assertEqual(window['sample_count'], 30)

    def test_22_failed_window_then_pass_has_no_model_retry(self):
        def sample():
            return synthetic_sample(self.clock.now, ram=6 * 1024**3 + (700 * 1024**2 if self.clock.now < 30 and int(self.clock.now) % 2 else 0))
        state = self.settle(sample)
        self.assertEqual([r['status'] for r in state['windows']], ['THRESHOLD_WAIT', 'PASS'])
        self.assertEqual(state['elapsed_seconds'], 60)
        self.assertFalse(state['original_trial_called'])

    def test_23_ten_failed_windows_stop_without_model_call(self):
        with self.assertRaises(self.d.ScopeError):
            self.settle(lambda: synthetic_sample(self.clock.now, util=11))
        state = self.d.read(self.d.SETTLING / self.d.expected_order()[0]['id'] / 'settling.json')
        self.assertEqual(len(state['windows']), 10)
        self.assertEqual(state['elapsed_seconds'], 300)
        self.assertFalse(state['original_trial_called'])

    def test_24_malformed_window_preserves_partial_raw_and_stops(self):
        def sample():
            result = synthetic_sample(self.clock.now)
            result['host']['abort'] = 'synthetic guard abort'
            return result
        with self.assertRaises(self.d.ScopeError):
            self.settle(sample)
        folder = self.d.SETTLING / self.d.expected_order()[0]['id']
        self.assertEqual(len(self.d.read(folder / 'settling.json')['windows']), 1)
        self.assertEqual(self.d.read(folder / 'window-01/window.json')['sample_count'], 1)
        self.assertTrue((folder / 'window-01/memory.jsonl').read_text())

    def test_25_window_overrun_is_fail_closed(self):
        folder = self.d.SETTLING / 'overrun'
        def sample():
            value = synthetic_sample(self.clock.now)
            self.clock.now += 301
            return value
        with self.assertRaises(self.d.ScopeError):
            self.d.collect_window(folder, 1, 300, sample, self.clock.monotonic, self.clock.sleep)
        self.assertEqual(self.d.read(folder / 'window.json')['status'], 'FAIL')

    def test_26_insufficient_remaining_window_budget_has_receipt(self):
        folder = self.d.SETTLING / 'insufficient'
        with self.assertRaises(self.d.ScopeError):
            self.d.collect_window(folder, 1, 29, lambda: synthetic_sample(), self.clock.monotonic, self.clock.sleep)
        self.assertEqual(self.d.read(folder / 'window.json')['sample_count'], 0)

    def test_27_full_synthetic_model_hash_passes_and_records_health(self):
        result = self.d.hash_model_before_trial(self.d.SETTLING / 'hash.json')
        self.assertEqual(result['status'], 'PASS')
        self.assertEqual(result['actual_sha256'], self.lock['model']['sha256'])
        self.assertEqual(result['host_health_checks'], 3)
        self.assertEqual(len(result['health_observations']), 3)

    def test_28_model_size_mismatch_preserves_failure(self):
        self.model.write_bytes(b'changed')
        with self.assertRaises(self.d.ScopeError):
            self.d.hash_model_before_trial(self.d.SETTLING / 'hash.json')
        self.assertEqual(self.d.read(self.d.SETTLING / 'hash.json')['status'], 'FAIL')

    def test_29_same_size_model_hash_mismatch_fails(self):
        self.model.write_bytes(b'x' * self.lock['model']['bytes'])
        with self.assertRaises(self.d.ScopeError):
            self.d.hash_model_before_trial(self.d.SETTLING / 'hash.json')
        self.assertEqual(self.d.read(self.d.SETTLING / 'hash.json')['bytes_read'], self.lock['model']['bytes'])

    def test_30_hash_deadline_overrun_stops(self):
        def health():
            self.clock.now += 121
            return {'time': time.time(), 'abort': None}
        with self.assertRaises(self.d.ScopeError):
            self.d.hash_model_before_trial(self.d.SETTLING / 'hash.json', self.clock.monotonic, health)
        self.assertEqual(self.d.read(self.d.SETTLING / 'hash.json')['status'], 'FAIL')

    def test_31_hash_host_abort_stops(self):
        with self.assertRaises(self.d.ScopeError):
            self.d.hash_model_before_trial(self.d.SETTLING / 'hash.json', health=lambda: {'time': time.time(), 'abort': 'floor'})

    def test_32_layout_rejects_wrong_guest(self):
        with patch.dict(os.environ, {'WSL_DISTRO_NAME': 'Ubuntu-24.04'}), self.assertRaises(self.d.ScopeError):
            self.d.require_layout('primary')

    def test_33_layout_rejects_wrong_guard_budget(self):
        command = self.d.read(self.guard / 'command.json')
        command['timeout'] = 13320
        self.put(self.guard / 'command.json', command)
        with self.assertRaises(self.d.ScopeError):
            self.d.require_layout('primary')

    def test_34_layout_rejects_guard_argv_override(self):
        command = self.d.read(self.guard / 'command.json')
        command['command'].extend(['--out', 'other'])
        self.put(self.guard / 'command.json', command)
        with self.assertRaises(self.d.ScopeError):
            self.d.require_layout('primary')

    def test_35_core_hash_change_rejected(self):
        (self.pkg / 'scripts/guard_rtx.py').write_text('changed')
        with self.assertRaises(self.d.ScopeError):
            self.d.current_core_hashes()

    def test_36_output_reuse_is_rejected_without_overwrite(self):
        path = self.d.SETTLING / 'original.json'
        path.write_text('preserve me')
        with self.assertRaises(self.d.ScopeError):
            self.d.fresh(path)
        self.assertEqual(path.read_text(), 'preserve me')

    def test_37_receipt_atomic_replace_refuses_existing_tmp(self):
        path = self.d.BASE / 'receipt.json'
        self.d.atomic_receipt(path, {'success': False})
        self.d.atomic_receipt(path, {'success': True})
        Path(str(path) + '.tmp').write_text('old partial')
        with self.assertRaises(self.d.ScopeError):
            self.d.atomic_receipt(path, {'success': False})
        self.assertTrue(self.d.read(path)['success'])

    def test_38_data_escape_rejected(self):
        with self.assertRaises(self.d.ScopeError):
            self.d.safe_path(self.pkg / 'elsewhere.json')

    def test_39_scope_protocol_driver_tamper_rejected(self):
        self.protocol()
        self.d.DRIVER.write_text('changed ancillary')
        with self.assertRaises(self.d.ScopeError):
            self.scope_check()

    def test_40_scope_protocol_budget_tamper_rejected(self):
        value = self.protocol()
        value['outer_guard_budget_seconds'] = 13320
        self.put(self.d.PROTOCOL, value)
        with self.assertRaises(self.d.ScopeError):
            self.scope_check()

    def test_41_scope_protocol_order_tamper_rejected(self):
        value = self.protocol()
        value['order'][0], value['order'][1] = value['order'][1], value['order'][0]
        self.put(self.d.PROTOCOL, value)
        with self.assertRaises(self.d.ScopeError):
            self.scope_check()

    def test_42_partial_sixteen_k_cannot_be_retained(self):
        value = self.protocol()
        value['retained'].append([16384, '18'])
        self.put(self.d.PROTOCOL, value)
        with self.assertRaises(self.d.ScopeError):
            self.scope_check()

    def test_43_valid_scope_protocol_passes(self):
        self.protocol()
        self.assertEqual(self.scope_check()['outer_guard_budget_seconds'], 15480)

    def test_44_wrapper_preserves_original_reference_and_arguments(self):
        state, runtime, reference = self.wrapper_state(), {'actual': 'runtime'}, {'first': 'baseline'}
        protocol = {'order': self.d.expected_order(), 'runtime_reference': runtime}
        called = []
        def original(*args, **kwargs):
            called.append((args, kwargs))
            return self.original_success(*args, **kwargs)
        wrapped = self.d.make_trial_wrapper(original, protocol, state, self.d.BASE / 'primary-driver-receipt.json')
        item = protocol['order'][0]
        with patch.object(self.d, 'settle_before_trial', side_effect=self.fake_settle):
            wrapped(self.d.PRIMARY / item['id'], item['context'], item['gpu_layers'], 'primary', self.d.PROTOCOL,
                    reference, runtime=runtime)
        self.assertEqual(state['actual_trial_calls'], 1)
        self.assertIs(called[0][0][5], reference)
        self.assertIs(called[0][1]['runtime'], runtime)
        self.assertTrue(state['settling_records'][0]['server_started'])

    def test_45_wrapper_settle_failure_never_calls_original(self):
        state, runtime = self.wrapper_state(), {'actual': 'runtime'}
        protocol = {'order': self.d.expected_order(), 'runtime_reference': runtime}
        original = unittest.mock.Mock()
        item = protocol['order'][0]
        def stopped(*args):
            result = self.fake_settle(*args)
            result['status'] = 'STOPPED'
            self.put(self.d.SETTLING / item['id'] / 'settling.json', result)
            raise self.d.ScopeError('No host window passed')
        with patch.object(self.d, 'settle_before_trial', side_effect=stopped), self.assertRaises(self.d.ScopeError):
            self.d.make_trial_wrapper(original, protocol, state, self.d.BASE / 'primary-driver-receipt.json')(
                self.d.PRIMARY / item['id'], item['context'], item['gpu_layers'], 'primary', self.d.PROTOCOL, runtime=runtime)
        original.assert_not_called()
        self.assertEqual(state['actual_trial_calls'], 0)
        self.assertEqual(state['settling_records'][0]['status'], 'STOPPED')

    def test_46_internal_baseline_failure_has_no_server_start(self):
        state, runtime = self.wrapper_state(), {'actual': 'runtime'}
        protocol = {'order': self.d.expected_order(), 'runtime_reference': runtime}
        def failed(out, *args, **kwargs):
            out.mkdir(parents=True)
            result = {'status': 'failed', 'failure_class': 'resource_or_budget_stop'}
            self.put(out / 'result.json', result)
            return result
        wrapped = self.d.make_trial_wrapper(failed, protocol, state, self.d.BASE / 'primary-driver-receipt.json')
        item = protocol['order'][0]
        with patch.object(self.d, 'settle_before_trial', side_effect=self.fake_settle):
            wrapped(self.d.PRIMARY / item['id'], item['context'], item['gpu_layers'], 'primary', self.d.PROTOCOL, runtime=runtime)
        self.assertTrue(state['settling_records'][0]['original_trial_called'])
        self.assertFalse(state['settling_records'][0]['server_started'])
        next_item = protocol['order'][1]
        with self.assertRaises(self.d.ScopeError):
            wrapped(self.d.PRIMARY / next_item['id'], next_item['context'], next_item['gpu_layers'], 'primary', self.d.PROTOCOL, runtime=runtime)

    def test_47_wrapper_rejects_wrong_order_before_host_window(self):
        state, runtime = self.wrapper_state(), {'actual': 'runtime'}
        protocol = {'order': self.d.expected_order(), 'runtime_reference': runtime}
        item = protocol['order'][1]
        with self.assertRaises(self.d.ScopeError):
            self.d.make_trial_wrapper(self.original_success, protocol, state, self.d.BASE / 'primary-driver-receipt.json')(
                self.d.PRIMARY / item['id'], item['context'], item['gpu_layers'], 'primary', self.d.PROTOCOL, runtime=runtime)
        self.assertEqual(state['actual_trial_calls'], 0)

    def test_48_guard_elapsed_bound_uses_actual_host_start(self):
        (self.guard / 'host-memory.jsonl').write_text(json.dumps({'time': time.time() - 100}) + '\n')
        with self.assertRaises(self.d.ScopeError):
            self.d.guard_elapsed(self.guard, 10)

    def test_49_measurement_lock_collision_prevents_reservation(self):
        self.d.core.fcntl.flock = unittest.mock.Mock(side_effect=BlockingIOError('occupied'))
        with self.assertRaises(BlockingIOError):
            self.d.execute('primary')
        self.assertFalse((self.d.BASE / 'primary-driver-receipt.json').exists())

    def test_50_atomic_receipt_temporary_symlink_rejected(self):
        target = self.pkg / 'preserve-target'
        target.write_text('preserve me')
        temporary = self.d.BASE / 'receipt.json.tmp'
        try:
            temporary.symlink_to(target)
        except OSError:
            self.skipTest('Windows lacks symlink permission; production Linux guard is still checked in code')
        with self.assertRaises(self.d.ScopeError):
            self.d.atomic_receipt(self.d.BASE / 'receipt.json', {})
        self.assertEqual(target.read_text(), 'preserve me')

    def test_51_freeze_receipt_positive_provenance_and_guard(self):
        protocol, _, _ = self.freeze_receipt()
        self.d.check_freeze_receipt(protocol)

    def test_52_freeze_receipt_wrong_phase_fails(self):
        protocol, frozen, _ = self.freeze_receipt()
        frozen['phase'] = 'primary'
        self.put(self.d.BASE / 'freeze-driver-receipt.json', frozen)
        with self.assertRaises(self.d.ScopeError):
            self.d.check_freeze_receipt(protocol)

    def test_53_freeze_receipt_changed_driver_fails(self):
        protocol, frozen, _ = self.freeze_receipt()
        frozen['driver_sha256_after'] = 'changed'
        self.put(self.d.BASE / 'freeze-driver-receipt.json', frozen)
        with self.assertRaises(self.d.ScopeError):
            self.d.check_freeze_receipt(protocol)

    def test_54_freeze_receipt_changed_protocol_hash_fails(self):
        protocol, frozen, _ = self.freeze_receipt()
        frozen['protocol_sha256'] = 'changed'
        self.put(self.d.BASE / 'freeze-driver-receipt.json', frozen)
        with self.assertRaises(self.d.ScopeError):
            self.d.check_freeze_receipt(protocol)

    def test_55_freeze_receipt_changed_derived_hash_fails(self):
        protocol, frozen, _ = self.freeze_receipt()
        frozen['derived_protocol_sha256'] = 'changed'
        self.put(self.d.BASE / 'freeze-driver-receipt.json', frozen)
        with self.assertRaises(self.d.ScopeError):
            self.d.check_freeze_receipt(protocol)

    def test_56_freeze_guard_failed_exit_fails(self):
        protocol, _, guard = self.freeze_receipt()
        self.put(guard / 'host-result.json', {'exit_code': 1, 'abort': None})
        with self.assertRaises(self.d.ScopeError):
            self.d.check_freeze_receipt(protocol)

    def test_57_freeze_guard_abort_fails(self):
        protocol, _, guard = self.freeze_receipt()
        self.put(guard / 'guest-result.json', {'exit_code': 0, 'abort': 'timeout', 'child_group_cleanup_attempted': True})
        with self.assertRaises(self.d.ScopeError):
            self.d.check_freeze_receipt(protocol)

    def test_58_freeze_guard_missing_terminal_fails(self):
        protocol, _, guard = self.freeze_receipt()
        (guard / 'guest-result.json').unlink()
        with self.assertRaises(FileNotFoundError):
            self.d.check_freeze_receipt(protocol)

    def test_59_multiple_model_chunks_have_exact_health_coverage(self):
        self.d.MODEL_HASH_POLICY['chunk_bytes'] = 4
        result = self.d.hash_model_before_trial(self.d.SETTLING / 'hash.json')
        self.assertEqual(result['status'], 'PASS')
        self.assertEqual(result['host_health_checks'], (self.model.stat().st_size + 3) // 4 + 2)
        self.assertEqual(result['actual_sha256'], self.lock['model']['sha256'])

    def test_60_after_chunk_read_deadline_overrun_fails(self):
        original_open = Path.open
        clock, model = self.clock, self.model
        class SlowRead:
            def __init__(self, stream):
                self.stream = stream
            def __enter__(self):
                return self
            def __exit__(self, *args):
                self.stream.close()
            def read(self, size):
                value = self.stream.read(size)
                clock.now += 121
                return value
        def patched_open(path, *args, **kwargs):
            result = original_open(path, *args, **kwargs)
            return SlowRead(result) if path == model and args == ('rb',) else result
        with patch.object(Path, 'open', patched_open), self.assertRaises(self.d.ScopeError):
            self.d.hash_model_before_trial(self.d.SETTLING / 'hash.json', clock.monotonic)
        receipt = self.d.read(self.d.SETTLING / 'hash.json')
        self.assertEqual(receipt['status'], 'FAIL')
        self.assertIn('overran', receipt['error'])

    def test_61_core_primary_exception_gets_terminal_driver_receipt(self):
        protocol = self.protocol()
        self.put(self.d.BASE / 'freeze-driver-receipt.json', {'success': True})
        self.d.SETTLING.rmdir()  # This exact fresh, empty synthetic directory only.
        self.d.core.run_primary = unittest.mock.Mock(side_effect=RuntimeError('synthetic original engine stop'))
        original_trial = self.d.core.trial
        with patch.object(self.d, 'check_scope_protocol', return_value=protocol), \
                patch.object(self.d, 'check_freeze_receipt'), patch.object(self.d, 'history_inventory', return_value={}):
            state = self.d.execute('primary')
        self.assertFalse(state['success'])
        self.assertEqual(state['driver_exit_code'], 1)
        self.assertEqual(state['actual_trial_calls'], 0)
        self.assertEqual(self.d.read(self.d.BASE / 'primary-driver-receipt.json')['status'], 'supplemental_scope_failed')
        self.assertEqual(self.d.core.CONTEXTS, self.d.ORIGINAL_CONTEXTS)
        self.assertIs(self.d.core.trial, original_trial)

    def test_62_final_batch_missing_post_binding_is_rejected(self):
        self.d.PRIMARY.mkdir()
        self.put(self.d.PRIMARY / 'batch.json', {'status': 'all_retained_primary_trials_validated',
            'input_verification_status': 'FAIL', 'runtime_unchanged': False, 'raw_validation_status': 'raw_checks_passed'})
        with self.assertRaises(self.d.ScopeError):
            self.d.final_primary_evidence({'order': self.d.expected_order()})

    def test_63_historical_raw_inventory_change_is_rejected(self):
        self.protocol()
        with patch.object(self.d, 'validate_scouts', return_value=[]), \
                patch.object(self.d, 'historical_scope', return_value={'actual': 'history'}), \
                patch.object(self.d, 'history_inventory', return_value={'actual': 'changed raw hash'}), self.assertRaises(self.d.ScopeError):
            self.d.check_scope_protocol()

    def test_64_hash_failure_never_starts_idle_or_original_trial(self):
        self.model.write_bytes(b'changed size')
        with self.assertRaises(self.d.ScopeError):
            self.d.settle_before_trial(self.d.expected_order()[0], 0, 'protocol', 'driver')
        folder = self.d.SETTLING / self.d.expected_order()[0]['id']
        state = self.d.read(folder / 'settling.json')
        self.assertEqual(state['windows'], [])
        self.assertFalse(state['original_trial_called'])
        self.assertEqual(self.d.read(folder / 'model-hash.json')['status'], 'FAIL')


if __name__ == '__main__':
    unittest.main(verbosity=2)
