#!/usr/bin/env python3
"""Windows RAM/disk/timeout guard plus Linux child-process-group supervisor.

Run on Windows: python guard_rtx.py --label build-v1 --timeout 3600 -- bash SCRIPT
The guest is always VRAMLab-RTX-Context. Raw telemetry stays in ignored data/rtx.
"""
import argparse
import ctypes
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

PACKAGE = Path(__file__).resolve().parents[1]
DISTRO = "VRAMLab-RTX-Context"


def write_json(path, value):
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
    # A WSL reader on drvfs can briefly hold the destination without delete sharing.
    # Retry that file-sharing race within the 8-second heartbeat deadline.
    for attempt in range(40):
        try:
            temporary.replace(path)
            return
        except PermissionError:
            if attempt == 39:
                raise
            time.sleep(0.05)


def windows_memory():
    class Memory(ctypes.Structure):
        _fields_ = [("length", ctypes.c_ulong), ("load", ctypes.c_ulong)] + [
            (key, ctypes.c_ulonglong) for key in
            ("total", "available", "total_page", "available_page", "total_virtual", "available_virtual", "extended")
        ]
    value = Memory()
    value.length = ctypes.sizeof(value)
    if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(value)):
        raise ctypes.WinError()
    return value.available


def wsl_path(path):
    path = Path(path).resolve()
    return "/mnt/" + path.drive[0].lower() + path.as_posix()[2:]


def verify_guest_registration():
    import winreg
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Lxss") as root:
        for index in range(winreg.QueryInfoKey(root)[0]):
            name = winreg.EnumKey(root, index)
            with winreg.OpenKey(root, name) as key:
                if winreg.QueryValueEx(key, "DistributionName")[0] != DISTRO:
                    continue
                base = winreg.QueryValueEx(key, "BasePath")[0]
                if base.startswith("\\\\?\\"):
                    base = base[4:]
                if Path(base).resolve() != (PACKAGE / "data/rtx/distro").resolve():
                    raise RuntimeError("Experiment guest registration points outside this package")
                if winreg.QueryValueEx(key, "Version")[0] != 2:
                    raise RuntimeError("Expected WSL2")
                return {"id": name, "base_path": base}
    raise RuntimeError("Experiment guest is not registered")


def guest(directory, command):
    if os.environ.get("WSL_DISTRO_NAME") != DISTRO:
        raise RuntimeError("Wrong WSL distribution")
    child = None
    cause = None
    started = time.monotonic()
    try:
        health = json.loads((directory / "heartbeat.json").read_text())
        if time.time() - health["time"] > 8 or health["abort"]:
            raise RuntimeError("Host guard unavailable")
        child = subprocess.Popen(command, start_new_session=True,
                                 env=dict(os.environ, VRAMLAB_GUARD_DIRECTORY=str(directory)))
        write_json(directory / "guest-process.json", {"pid": child.pid, "argv": command})
        while child.poll() is None:
            try:
                health = json.loads((directory / "heartbeat.json").read_text())
                if time.time() - health["time"] > 8:
                    cause = "host_guard_stale"
                elif health["abort"]:
                    cause = health["abort"]
            except (OSError, ValueError):
                cause = "host_guard_unreadable"
            if cause:
                break
            time.sleep(0.2)
    finally:
        if child is not None:
            # Signal only this child's dedicated session, including surviving descendants.
            try:
                os.killpg(child.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                child.wait(timeout=3)
            except subprocess.TimeoutExpired:
                pass
            try:
                os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            child.wait(timeout=3)
        code = child.returncode if child is not None else None
        write_json(directory / "guest-result.json", {
            "exit_code": code, "abort": cause, "elapsed_seconds": time.monotonic() - started,
            "child_group_cleanup_attempted": child is not None,
        })
    return 124 if cause else (code if code is not None else 1)


def host(args, command):
    if os.name != "nt":
        raise RuntimeError("Host guard requires Windows")
    registration = verify_guest_registration()
    if not args.label or any(c not in "abcdefghijklmnopqrstuvwxyz0123456789-_" for c in args.label):
        raise ValueError("Use a simple unique lowercase label")
    directory = PACKAGE / "data/rtx/guards" / args.label
    directory.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    abort = None
    child = None
    write_json(directory / "command.json", {"command": command, "timeout": args.timeout, "registration": registration,
               "min_host_ram_bytes": 2 * 1024**3, "min_disk_bytes": 5 * 1024**3})
    with (directory / "host-memory.jsonl").open("w") as samples, (directory / "console.log").open("wb") as log:
        try:
            while True:
                available = windows_memory()
                disk_free = shutil.disk_usage(PACKAGE).free
                if available < 2 * 1024**3:
                    abort = abort or "host_ram_below_2gib"
                if disk_free < 5 * 1024**3:
                    abort = abort or "disk_below_5gib"
                if time.monotonic() - started > args.timeout:
                    abort = abort or "timeout"
                sample = {"time": time.time(), "available_ram_bytes": available,
                          "disk_free_bytes": disk_free, "abort": abort}
                if args.telemetry_gpu:
                    try:
                        gpu = subprocess.run(["nvidia-smi", "--id=0",
                            "--query-gpu=memory.total,memory.used,temperature.gpu,utilization.gpu,clocks.current.sm,power.draw,pstate",
                            "--format=csv,noheader,nounits"], capture_output=True, text=True,
                            timeout=3, creationflags=subprocess.CREATE_NO_WINDOW)
                        if gpu.returncode != 0:
                            raise RuntimeError(gpu.stderr.strip())
                        values = gpu.stdout.strip().split(", ")
                        sample["gpu_raw"] = gpu.stdout
                        sample["gpu"] = dict(zip(["total_mib", "used_mib", "temperature_c", "utilization_percent", "sm_mhz", "power_w", "pstate"], values))
                        float(sample["gpu"]["used_mib"])
                    except Exception as error:
                        abort = abort or "gpu_health_query_failed"
                        sample.update(abort=abort, gpu_error=str(error))
                samples.write(json.dumps(sample) + "\n")
                samples.flush()
                write_json(directory / "heartbeat.json", sample)
                if child is None:
                    if abort:
                        break
                    child = subprocess.Popen([
                        "wsl.exe", "-d", DISTRO, "-u", "root", "--exec", "python3",
                        wsl_path(Path(__file__)), "--guest", wsl_path(directory),
                    ], stdout=log, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
                if child.poll() is not None:
                    break
                time.sleep(1)
        finally:
            if child is not None and child.poll() is None:
                write_json(directory / "heartbeat.json", {"time": time.time(), "abort": "host_guard_exit"})
                # The guest polls every 0.2 s and escalates TERM to KILL after 3 s.
                child.wait(timeout=15)
        code = child.returncode if child is not None else None
    result = {"exit_code": code, "abort": abort, "elapsed_seconds": time.monotonic() - started}
    write_json(directory / "host-result.json", result)
    print(json.dumps(result))
    return 124 if abort else (code if code is not None else 1)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--label")
    parser.add_argument("--timeout", type=float, default=600)
    parser.add_argument("--telemetry-gpu", action="store_true")
    parser.add_argument("--guest", type=Path)
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    if args.guest:
        command = json.loads((args.guest / "command.json").read_text())["command"]
        return guest(args.guest, command)
    command = args.command[1:] if args.command[:1] == ["--"] else args.command
    if not command:
        parser.error("command required after --")
    return host(args, command)


if __name__ == "__main__":
    raise SystemExit(main())
