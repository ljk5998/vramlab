#!/usr/bin/env python3
"""One guarded 2048/all reader trial using the exact fresh reproduction build.

Install alongside the package scripts. Run through guard_rtx.py with GPU
telemetry; no path, mode, or measurement overrides are accepted. This driver
does not build, install, change inputs, or contribute to the primary sample.
"""
import argparse
import json
import os
from pathlib import Path
import signal

import rtx_measure as measure
import snapshot_rtx_reader as reader_snapshot
import validate_rtx_trial as validator

PACKAGE = Path(__file__).resolve().parents[1]
DATA = PACKAGE / 'data/rtx'
REPRO = DATA / 'reproduction-20261007'
BUILD = REPRO / 'build'
OUT = REPRO / 'reader'
RECEIPT = REPRO / 'reader-receipt.json'
SERVER = BUILD / 'bin/llama-server'
DRIVER = PACKAGE / 'scripts/run_rtx_reader.py'


class ReaderInterrupted(BaseException):
    def __init__(self, signum):
        self.signum = signum
        super().__init__('Guard-owned reader interrupted by signal ' + str(signum))


def write_receipt(state):
    temporary = RECEIPT.with_name(RECEIPT.name + '.tmp')
    # Keep a signal handler from re-entering this short atomic write. Exclusive
    # creation also refuses a dangling temporary symlink without following it.
    previous_mask = signal.pthread_sigmask(signal.SIG_BLOCK, {signal.SIGTERM, signal.SIGINT})
    try:
        if RECEIPT.is_symlink() or temporary.is_symlink() or REPRO.is_symlink():
            raise ValueError('Reader receipt paths may not be symbolic links')
        with temporary.open('x', encoding='utf-8') as stream:
            stream.write(json.dumps(state, ensure_ascii=False, indent=2) + '\n')
        temporary.replace(RECEIPT)
    finally:
        signal.pthread_sigmask(signal.SIG_SETMASK, previous_mask)


def require_layout():
    if os.environ.get('WSL_DISTRO_NAME') != 'VRAMLab-RTX-Context' or measure.fcntl is None:
        raise RuntimeError('Exact experiment guest and Linux measurement locking required')
    if (Path(__file__).is_symlink() or Path(__file__).resolve() != DRIVER
            or not (PACKAGE / 'inputs.lock.json').is_file()):
        raise ValueError('Install the driver in the existing locked package scripts directory')
    for module, filename in ((measure, 'rtx_measure.py'), (reader_snapshot, 'snapshot_rtx_reader.py'),
                             (validator, 'validate_rtx_trial.py')):
        if Path(module.__file__).resolve() != (PACKAGE / 'scripts' / filename):
            raise ValueError('Reader dependencies must resolve inside this package')
    if (measure.PACKAGE.resolve() != PACKAGE or reader_snapshot.PACKAGE.resolve() != PACKAGE
            or reader_snapshot.BUILD != BUILD):
        raise ValueError('Reader dependency package/build binding differs')
    for path in (REPRO, BUILD, BUILD / 'bin', SERVER):
        if path.is_symlink() or not path.resolve().is_relative_to(DATA.resolve()):
            raise ValueError('Reader build must stay inside its exact reproduction directory')
    if not BUILD.is_dir() or not SERVER.is_file():
        raise FileNotFoundError('Complete the exact fresh reader build first')
    guard = os.environ.get('VRAMLAB_GUARD_DIRECTORY')
    if not guard or not Path(guard).resolve().is_relative_to((DATA / 'guards').resolve()):
        raise RuntimeError('The package Windows host guard is required')
    # host_health requires fresh GPU telemetry and the existing RAM/disk cutoffs.
    measure.host_health()


def capture_snapshot(path):
    """Keep a FAIL sidecar even when the helper's initial guard check aborts."""
    try:
        return reader_snapshot.capture(path, BUILD, guard_callback=measure.host_health)
    except Exception as error:
        sidecar = measure.verification_path(path)
        if not sidecar.exists():
            reader_snapshot.write_new(sidecar, {'status': 'FAIL', 'scope': 'reader_only',
                'failure_class': 'instrumentation_invalid', 'finished_utc': measure.utc(),
                'error': f'{type(error).__name__}: {error}'})
        raise


def supplementary_identity(runtime):
    return {name: runtime[name] for name in ('reader_scripts_sha256', 'loader_environment',
            'source_tree', 'model_actual', 'checked_cmake_flags', 'reader_build_directory')}


def run_reader():
    # Layout and telemetry checks precede reserving any measurement evidence.
    require_layout()
    with (DATA / 'measurement.lock').open('a') as measurement_lock:
        measure.fcntl.flock(measurement_lock, measure.fcntl.LOCK_EX | measure.fcntl.LOCK_NB)
        if OUT.exists() or OUT.is_symlink() or RECEIPT.exists() or RECEIPT.is_symlink():
            raise FileExistsError('Reader attempt already exists; preserve the original evidence')
        temporary = RECEIPT.with_name(RECEIPT.name + '.tmp')
        if temporary.exists() or temporary.is_symlink():
            raise FileExistsError('Earlier reader receipt temporary file exists; preserve it')
        if (REPRO / 'reader-validation.json').exists() or (REPRO / 'reader-validation.json').is_symlink():
            raise FileExistsError('Earlier reader validation exists; preserve it')
        OUT.mkdir(exist_ok=False)
        state = {'schema_version': 1, 'phase': 'reader', 'primary_eligible': False,
            'context': 2048, 'gpu_layers': 'all', 'attempt_limit': 1, 'started_utc': measure.utc(),
            'status': 'verifying_inputs', 'success': False, 'driver_exit_code': None,
            'exit_code_scope': 'Driver return code; the host/guest guard records observed OS exit',
            'raw_validation_status': 'NOT_RUN',
            'driver_sha256_before': measure.sha(DRIVER), 'server_path': str(SERVER),
            'trial_directory': str(OUT), 'runtime_binding_scope': 'trial',
            'supervision_scope': 'Inherits the host guard process group; no detached child session',
            'external_kill_limit': 'SIGKILL cannot run Python cleanup; inspect the guard result too'}
        write_receipt(state)
        before = after = result = None
        error = None
        interrupted = None
        bindings_verified = False
        validation_attempted = False

        def interrupt(signum, frame):
            state.update(status='guard_signal_received', success=False, signal=signum,
                         driver_exit_code=128 + signum, finished_utc=measure.utc())
            write_receipt(state)
            raise ReaderInterrupted(signum)

        previous_handlers = {sig: signal.signal(sig, interrupt) for sig in (signal.SIGTERM, signal.SIGINT)}
        try:
            before = capture_snapshot(OUT / 'runtime-before.json')
            state.update(status='running', input_verification_status='PASS',
                         runtime_before_sha256=measure.sha(OUT / 'runtime-before.json'),
                         input_binding_fingerprint=measure.binding_fingerprint(before))
            write_receipt(state)
            result = measure.trial(OUT, 2048, 'all', 'reader', runtime=before,
                                   prepared=True, server_override=SERVER)
            state.update(status='trial_done_post_pending', trial_status=result['status'],
                         server_exit_code=result.get('exit_code'),
                         failure_class=result.get('failure_class'))
            write_receipt(state)
        except (Exception, ReaderInterrupted) as caught:
            error = caught
            if isinstance(caught, ReaderInterrupted):
                interrupted = caught.signum
            state.update(status='stopped_on_failure', error=f'{type(caught).__name__}: {caught}',
                         failure_class='resource_or_budget_stop' if interrupted else measure.classify_failure(caught))
        finally:
            try:
                after = capture_snapshot(OUT / 'runtime-after.json')
                if (before is None or measure.binding_identity(before) != measure.binding_identity(after)
                        or supplementary_identity(before) != supplementary_identity(after)):
                    raise measure.BindingError('Reader pre/post inputs, closure, helper or environment changed')
                state['driver_sha256_after'] = measure.sha(DRIVER)
                if state['driver_sha256_before'] != state['driver_sha256_after']:
                    raise measure.BindingError('Reader driver changed during attempt')
                bindings_verified = True
                state.update(runtime_unchanged=True, input_verification_status='PASS',
                             runtime_after_sha256=measure.sha(OUT / 'runtime-after.json'))
                if not (OUT / 'result.json').exists():
                    raise measure.BindingError('Reader trial result missing')
                result = measure.finish_trial_binding(OUT, before, after, 'trial')
                state.update(trial_status=result['status'], server_exit_code=result.get('exit_code'),
                             result_sha256=measure.sha(OUT / 'result.json'))
                if error is None and result['status'] == 'completed_pending_validation':
                    validation_attempted = True
                    validation = validator.validate(OUT, package_root=PACKAGE)
                    if validation['status'] != 'raw_checks_passed':
                        raise measure.BindingError('Reader requires final independent raw checks')
                    reader_snapshot.write_new(REPRO / 'reader-validation.json', validation)
                    state.update(status='validated_reader_only', raw_validation_status=validation['status'],
                                 metrics=validation['metrics'], success=True, driver_exit_code=0)
                elif error is None:
                    state.update(status=result.get('failure_class', 'instrumentation_invalid'),
                                 error=result.get('error'), failure_class=result.get('failure_class'))
            except (Exception, ReaderInterrupted) as caught:
                error = caught
                if isinstance(caught, ReaderInterrupted):
                    interrupted = caught.signum
                state.update(status='instrumentation_invalid', success=False, runtime_unchanged=bindings_verified,
                             input_verification_status='PASS' if bindings_verified else 'FAIL',
                             raw_validation_status='FAIL' if validation_attempted else 'NOT_RUN',
                             failure_class='instrumentation_invalid',
                             finalization_error=f'{type(caught).__name__}: {caught}')
                if (OUT / 'result.json').exists():
                    result = measure.read(OUT / 'result.json')
                    result.update(status='failed', primary_eligible=False, failure_class='instrumentation_invalid',
                                  input_verification_status='PASS' if bindings_verified else 'FAIL',
                                  finalization_error=state['finalization_error'])
                    measure.save(OUT / 'result.json', result)
                    state.update(server_exit_code=result.get('exit_code'), result_sha256=measure.sha(OUT / 'result.json'))
            if 'driver_sha256_after' not in state:
                try:
                    state['driver_sha256_after'] = measure.sha(DRIVER)
                except Exception as caught:
                    state.update(driver_sha256_after=None, success=False, status='instrumentation_invalid',
                                 failure_class='instrumentation_invalid', driver_hash_error=str(caught))
            if not state['success']:
                state['driver_exit_code'] = 128 + interrupted if interrupted else 1
            state['finished_utc'] = measure.utc()
            write_receipt(state)
            for signum, previous in previous_handlers.items():
                signal.signal(signum, previous)
        return state


def main():
    argparse.ArgumentParser(description=__doc__).parse_args()  # No path/condition override interface.
    try:
        state = run_reader()
    except Exception as error:
        print(json.dumps({'status': 'reader_preflight_or_receipt_failure', 'success': False,
                          'driver_exit_code': 1, 'error': f'{type(error).__name__}: {error}'}), flush=True)
        return 1
    print(json.dumps({'status': state['status'], 'success': state['success'],
                      'driver_exit_code': state['driver_exit_code'], 'receipt': str(RECEIPT)}), flush=True)
    return state['driver_exit_code']


if __name__ == '__main__':
    raise SystemExit(main())
