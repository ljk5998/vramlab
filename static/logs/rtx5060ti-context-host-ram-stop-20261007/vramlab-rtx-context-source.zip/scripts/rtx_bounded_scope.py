#!/usr/bin/env python3
"""Prospective bounded-v1 bridge; the six pinned engine files stay unchanged.

Install as package/scripts/rtx_bounded_scope.py. Invoke only through the pinned
Windows GPU-telemetry guard: ``python3 DRIVER freeze`` (600 seconds), then
``python3 DRIVER primary`` (15480 seconds). No path/condition/retry overrides.
This narrows the in-process CONTEXTS for the unchanged freeze/check/run methods
and wraps trial only with separately recorded full-model hashing and pre-trial
idle observation. The SHA deadline is checked before/after each chunk; a single
blocking read remains supervised by the outer host guard.
The historical eight-condition design is NOT_MET; incomplete 16K is no capacity
result. SIGKILL can prevent terminal Python receipts; observed guard results
remain required by the independent final audit.
"""
import argparse
from contextlib import contextmanager
import hashlib
import json
import math
import os
from pathlib import Path
import signal
import statistics
import time

import rtx_measure as core
import validate_rtx_trial as validator

PACKAGE = Path(__file__).resolve().parents[1]
DATA = PACKAGE / 'data/rtx'
RUN = DATA / 'article-20261007'
SCOUTS = RUN / 'scouts-v4'
BASE = RUN / 'bounded-v1'
DRIVER = PACKAGE / 'scripts/rtx_bounded_scope.py'
DERIVED = BASE / 'protocol-derived.json'
PROTOCOL = BASE / 'protocol.json'
PRIMARY = BASE / 'primary'
SETTLING = BASE / 'settling'
CONTEXTS = (2048, 4096, 8192)
ORIGINAL_CONTEXTS = (2048, 4096, 8192, 16384)
CONDITIONS = [[c, l] for c in CONTEXTS for l in ('all', '18')]
CORE_SHA256 = {
    'rtx_measure.py': '10474eaed594ad8da56b9f0d503cec3360c4aa3d647cc0ee052b8f07a5c2f816',
    'validate_rtx_trial.py': 'c72614072ecc8a3553202cb1af4a734db499cdff670b68f571e4dfa215117087',
    'guard_rtx.py': '28f9d6e6293e4e31d93eff233ca83bc62714aef68f271f8d11d7bf5d1335d642',
    'prepare_rtx.py': '75346d42aa611fd12a91a1daf0abfa7aa9279e8e81ed82951b74bfea001bf2c6',
    'snapshot_rtx_runtime.py': '027fc3c79b64f276293fe793e2ca24bfabaf7f92a29f54e0438e6f260a1a2843',
    'check_package.py': '779e1c900867bf637c2f1033693b90f0b1e230149060b094f08d589747c8a7ae',
}
SETTLE_POLICY = {
    'window_seconds': 30, 'max_windows': 10, 'max_elapsed_seconds': 300,
    'min_samples': 25, 'max_sample_gap_seconds': 3,
    'max_effective_gpu_gap_seconds': 8, 'sample_cadence_seconds': 1,
    'host_ram_range_mib': 512, 'vram_range_mib': 128,
    'gpu_util_median_max': 10, 'host_ram_floor_bytes': 2 * 1024**3,
    'disk_floor_bytes': 5 * 1024**3, 'only_threshold_failure_may_wait': True,
}
MODEL_HASH_POLICY = {'before_each_actual_trial': True, 'full_file_read': True,
    'max_elapsed_seconds': 120, 'chunk_bytes': 8 * 1024**2,
    'cache_scope': 'Full read warms OS file cache; does not guarantee host RAM stability. No cache purge.',
    'measurement_scope': 'Outside original baseline/request/TTFT and applied uniformly to all 18 trials'}
SCOPE = {
    'schema_version': 1, 'id': 'bounded-v1', 'contexts': list(CONTEXTS),
    'offloads': ['all', '18'], 'historical_eight_condition_contract': 'NOT_MET',
    'reuse_policy': 'Six complete same-v4 scouts; no promotion of incomplete 16K',
    'core_context_override': list(CONTEXTS),
    'core_trial_wrapper': 'pretrial_model_hash_then_settling_only',
    'performance_scope': 'Near-filled 2K/4K/8K contexts only; no 16K capacity claim',
}


class ScopeError(ValueError):
    """A supplemental provenance/supervision failure, never workload capacity."""


class ScopeInterrupted(BaseException):
    def __init__(self, signum):
        self.signum = signum
        super().__init__('Guard-owned bounded scope interrupted by signal ' + str(signum))


def require(condition, message):
    if not condition:
        raise ScopeError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def canonical_sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def safe_path(path, root=None, existing=False):
    """Reject symlink parents, dangling links and escapes before any write."""
    path, root = Path(path), Path(DATA if root is None else root)
    require(path.is_absolute() and root.is_absolute(), 'Absolute package paths required')
    require(path != root and path.is_relative_to(root), 'Path is outside the exact package data root')
    # Walk from the trusted root without resolving away a link first.
    current = root
    require(not root.is_symlink() and root.resolve() == root, 'Data root is linked or noncanonical')
    for component in path.relative_to(root).parts:
        current = current / component
        require(not current.is_symlink(), 'Linked evidence path is forbidden')
        if current != path and current.exists():
            require(current.is_dir(), 'Evidence parent is not a directory')
    require(path.resolve() == path, 'Evidence path is noncanonical')
    if existing:
        require(path.exists(), 'Required evidence is missing')
    return path


def fresh(path):
    safe_path(path)
    require(not path.exists() and not path.is_symlink(), 'Earlier evidence exists; preserve it')


def write_new(path, value):
    safe_path(path)
    with Path(path).open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def atomic_receipt(path, value):
    safe_path(path)
    temporary = Path(str(path) + '.tmp')
    fresh(temporary)
    old_mask = None
    if hasattr(signal, 'pthread_sigmask'):
        old_mask = signal.pthread_sigmask(signal.SIG_BLOCK, {signal.SIGTERM, signal.SIGINT})
    try:
        write_new(temporary, value)
        temporary.replace(path)
    finally:
        if old_mask is not None:
            signal.pthread_sigmask(signal.SIG_SETMASK, old_mask)


def current_core_hashes():
    actual = {name: sha(PACKAGE / 'scripts' / name) for name in CORE_SHA256}
    require(actual == CORE_SHA256, 'Frozen six engine files changed')
    return actual


def require_layout(mode):
    require(mode in ('freeze', 'primary'), 'Unsupported mode')
    require(os.environ.get('WSL_DISTRO_NAME') == 'VRAMLab-RTX-Context' and core.fcntl is not None,
            'Exact experiment guest and Linux locking required')
    require(not Path(__file__).is_symlink() and Path(__file__).resolve() == DRIVER,
            'Install this ancillary driver in the existing locked package scripts directory')
    require(core.PACKAGE.resolve() == PACKAGE and core.DATA.resolve() == DATA,
            'Core package/data binding differs')
    require(Path(core.__file__).resolve() == PACKAGE / 'scripts/rtx_measure.py'
            and Path(validator.__file__).resolve() == PACKAGE / 'scripts/validate_rtx_trial.py',
            'Imported engine dependencies must belong to the same package')
    require(core.CONTEXTS == ORIGINAL_CONTEXTS, 'Original engine context globals were already changed')
    safe_path(RUN, existing=True)
    safe_path(SCOUTS, existing=True)
    safe_path(DATA / 'measurement.lock')
    current_core_hashes()
    core.host_health()
    guard = Path(os.environ.get('VRAMLAB_GUARD_DIRECTORY', ''))
    safe_path(guard, DATA / 'guards', existing=True)
    command = read(guard / 'command.json')
    expected_budget = 600 if mode == 'freeze' else 810 * 18 + 900
    require(command.get('command') == ['python3', str(DRIVER), mode], 'Guard argv must bind this exact mode and driver')
    require(command.get('timeout') == expected_budget, 'Actual outer guard budget differs')
    require(command.get('min_host_ram_bytes') == 2 * 1024**3
            and command.get('min_disk_bytes') == 5 * 1024**3, 'Hard safety floors changed')
    for name in ('host-result.json', 'guest-result.json'):
        require(not (guard / name).exists(), 'Guard is already terminal')
    return guard, command


def guard_elapsed(guard, budget):
    with (guard / 'host-memory.jsonl').open(encoding='utf-8') as stream:
        first = json.loads(stream.readline())
    start = finite(first.get('time'), 'guard start epoch')
    elapsed = time.time() - start
    require(0 <= elapsed <= budget, 'Actual host guard elapsed budget exhausted')
    return start, elapsed


@contextmanager
def bounded_core(trial_wrapper=None):
    """Only these two disclosed process-local substitutions are allowed."""
    original_contexts, original_trial = core.CONTEXTS, core.trial
    require(original_contexts == ORIGINAL_CONTEXTS, 'Unexpected engine context globals')
    core.CONTEXTS = CONTEXTS
    if trial_wrapper is not None:
        core.trial = trial_wrapper
    try:
        yield original_trial
    finally:
        core.trial = original_trial
        core.CONTEXTS = original_contexts


def scout_guard(source, successful):
    result = read(source / 'result.json')
    guard = Path(result['host_guard_directory'])
    safe_path(guard, DATA / 'guards', existing=True)
    command = read(guard / 'command.json')
    expected = ['python3', str(PACKAGE / 'scripts/rtx_measure.py'), 'scout', '--out', str(source),
                '--context', str(result['context']), '--layers', result['gpu_layers']]
    require(command.get('command') == expected and command.get('timeout') == 600,
            'Scout guard command does not bind its exact raw attempt')
    host, guest = read(guard / 'host-result.json'), read(guard / 'guest-result.json')
    if successful:
        require(host.get('exit_code') == guest.get('exit_code') == 0
                and host.get('abort') is None and guest.get('abort') is None
                and guest.get('child_group_cleanup_attempted') is True, 'Scout guard did not complete cleanly')
    return {'source': str(guard), 'command_sha256': sha(guard / 'command.json'),
            'host_result_sha256': sha(guard / 'host-result.json'),
            'guest_result_sha256': sha(guard / 'guest-result.json'),
            'host_exit_code': host.get('exit_code'), 'guest_exit_code': guest.get('exit_code'),
            'host_abort': host.get('abort'), 'guest_abort': guest.get('abort')}


def validate_scouts():
    rows, fingerprint = [], None
    for context, layers in CONDITIONS:
        source = SCOUTS / f'scout-ctx-{context}-layers-{layers}'
        safe_path(source, existing=True)
        runtime, result = core.verify_scout(source)
        require(result.get('status') == 'completed_pending_validation', 'Narrowed scope requires six completed scouts')
        receipt = validator.validate(source, package_root=PACKAGE)
        saved_path = SCOUTS / (source.name + '.validation.json')
        saved, batch = read(saved_path), read(SCOUTS / (source.name + '.batch.json'))
        require(receipt['status'] == saved.get('status') == 'raw_checks_passed'
                and saved.get('result_sha256') == sha(source / 'result.json')
                and batch.get('status') == 'scout_validated' and batch.get('input_verification_status') == 'PASS',
                'Actual scout raw validation/batch evidence differs')
        actual = core.binding_fingerprint(runtime)
        require(fingerprint is None or fingerprint == actual, 'Six scouts have different verified runtime bindings')
        fingerprint = actual
        rows.append({'context': context, 'gpu_layers': layers, 'source': str(source),
                     'result_sha256': sha(source / 'result.json'), 'input_binding_fingerprint': actual,
                     'validation_sha256': sha(saved_path), 'guard': scout_guard(source, True)})
    return rows


def historical_scope():
    source = SCOUTS / 'scout-ctx-16384-layers-18'
    safe_path(source, existing=True)
    result = read(source / 'result.json')
    guard = scout_guard(source, False)
    require(guard['host_abort'] == 'host_ram_below_2gib' and guard['host_exit_code'] == 124,
            'Historical 16K guard abort evidence differs')
    require(result.get('status') == 'started' and result.get('runtime_after_sha256') is None
            and not (source / 'runtime-after.json').exists()
            and not (source / 'runtime-after.json.verification.json').exists(),
            'Historical partial 16K must remain binding-incomplete')
    absent = SCOUTS / 'scout-ctx-16384-layers-all'
    require(not absent.exists() and not absent.is_symlink()
            and not (SCOUTS / (absent.name + '.batch.json')).exists(), '16K/all historical NOT_RUN changed')
    return {'original_conditions': [[c, l] for c in ORIGINAL_CONTEXTS for l in ('all', '18')],
            'original_eight_contract': 'NOT_MET',
            '16384_18': {'status': 'instrumentation_incomplete', 'source': str(source),
                'result_sha256': sha(source / 'result.json'), 'original_result_status': result['status'],
                'runtime_after_present': False, 'guard_abort': guard['host_abort'], 'guard': guard,
                'interpretation': 'Safety diagnostic only; no workload/capacity PASS or validated exclusion'},
            '16384_all': {'status': 'NOT_RUN', 'source': str(absent)}}


def history_inventory():
    inventory = {}
    for name in ('scouts', 'scouts-v2', 'scouts-v3', 'scouts-v4'):
        folder = RUN / name
        safe_path(folder, existing=True)
        inventory[str(folder)] = {str(p.relative_to(folder)): sha(p)
                                 for p in sorted(folder.rglob('*')) if p.is_file() and not p.is_symlink()}
        for p in folder.rglob('*'):
            require(not p.is_symlink(), 'Historical evidence contains a link')
    for guard in sorted((DATA / 'guards').iterdir()):
        if not guard.is_dir() or not (guard / 'command.json').is_file():
            continue
        command = read(guard / 'command.json').get('command', [])
        if '--out' not in command:
            continue
        index = command.index('--out') + 1
        if index < len(command) and Path(command[index]).parent in {RUN / n for n in ('scouts', 'scouts-v2', 'scouts-v3', 'scouts-v4')}:
            safe_path(guard, DATA / 'guards', existing=True)
            require((guard / 'host-result.json').is_file() and (guard / 'guest-result.json').is_file(),
                    'Historical guard is not terminal')
            inventory[str(guard)] = {str(p.relative_to(guard)): sha(p) for p in sorted(guard.rglob('*')) if p.is_file()}
    return inventory


def expected_order():
    retained = [tuple(row) for row in CONDITIONS]
    sequence = []
    for rep, order in enumerate((retained, list(reversed(retained)), retained[3:] + retained[:3]), 1):
        for context, layers in order:
            sequence.append({'id': f'trial-{len(sequence)+1:02d}-ctx-{context}-layers-{layers}-rep-{rep}',
                             'context': context, 'gpu_layers': layers, 'repetition': rep})
    return sequence


def extend_protocol(derived, scouts, history, inventory):
    require(derived['original_conditions'] == CONDITIONS and [list(v) for v in derived['retained']] == CONDITIONS
            and derived['excluded'] == [] and derived['order'] == expected_order(),
            'Derived six-condition protocol is incomplete or has changed order')
    return {**derived, 'scope_contract': SCOPE, 'outer_guard_budget_seconds': 810 * len(derived['order']) + 900,
            'auxiliary_settling': SETTLE_POLICY,
            'per_trial_model_hash': MODEL_HASH_POLICY,
            'ancillary_driver': {'path': str(DRIVER), 'sha256': sha(DRIVER)},
            'derived_protocol': {'path': str(DERIVED), 'sha256': sha(DERIVED)},
            'supplemental_scout_evidence': scouts, 'historical_scope': history,
            'historical_inventory': inventory, 'historical_inventory_sha256': canonical_sha(inventory),
            'scope_declared_utc': core.utc(),
            'scope_change_reason': 'Prospective narrower primary after original 16K hard-guard binding interruption; historical eight-condition contract NOT_MET'}


def check_scope_protocol():
    safe_path(PROTOCOL, existing=True)
    safe_path(DERIVED, existing=True)
    protocol = core.check_protocol(PROTOCOL)
    derived = read(DERIVED)
    require(all(protocol.get(key) == value for key, value in derived.items()), 'An original derived core field changed')
    require(protocol.get('scope_contract') == SCOPE and protocol.get('auxiliary_settling') == SETTLE_POLICY
            and protocol.get('per_trial_model_hash') == MODEL_HASH_POLICY,
            'Frozen supplemental scope/settling contract changed')
    require(protocol.get('original_conditions') == CONDITIONS and [list(v) for v in protocol['retained']] == CONDITIONS
            and protocol['excluded'] == [] and protocol['order'] == expected_order(), 'Scope/order is not exact six by three')
    require(protocol.get('guard_budget_seconds') == 390 * 18 + 900
            and protocol.get('outer_guard_budget_seconds') == 810 * 18 + 900, 'Internal/outer budgets changed')
    require(protocol.get('ancillary_driver') == {'path': str(DRIVER), 'sha256': sha(DRIVER)}
            and protocol.get('derived_protocol') == {'path': str(DERIVED), 'sha256': sha(DERIVED)}, 'Driver/derived protocol binding differs')
    require(protocol.get('supplemental_scout_evidence') == validate_scouts(), 'Six actual scout evidence bindings changed')
    require(protocol.get('historical_scope') == historical_scope(), 'Historical failure/NOT_RUN evidence changed')
    inventory = history_inventory()
    require(protocol.get('historical_inventory') == inventory
            and protocol.get('historical_inventory_sha256') == canonical_sha(inventory), 'Immutable historical evidence changed')
    return protocol


def check_freeze_receipt(protocol):
    frozen = read(BASE / 'freeze-driver-receipt.json')
    require(frozen.get('phase') == 'freeze' and frozen.get('status') == 'frozen_bounded_scope' and frozen.get('success') is True
            and frozen.get('driver_exit_code') == 0 and frozen.get('scope_id') == 'bounded-v1'
            and frozen.get('actual_trial_calls') == 0 and frozen.get('immutable_history') is True,
            'Supplemental freeze receipt is incomplete')
    require(frozen.get('driver_sha256_before') == frozen.get('driver_sha256_after') == sha(DRIVER)
            and frozen.get('core_scripts_sha256_before') == frozen.get('core_scripts_sha256_after') == CORE_SHA256
            and frozen.get('protocol_sha256') == sha(PROTOCOL) and frozen.get('derived_protocol_sha256') == sha(DERIVED)
            and frozen.get('historical_inventory_before_sha256') == frozen.get('historical_inventory_after_sha256')
                == protocol['historical_inventory_sha256'], 'Freeze receipt provenance changed')
    guard = safe_path(Path(frozen['guard_directory']), DATA / 'guards', existing=True)
    command, host, guest = read(guard / 'command.json'), read(guard / 'host-result.json'), read(guard / 'guest-result.json')
    require(sha(guard / 'command.json') == frozen['guard_command_sha256']
            and command.get('command') == ['python3', str(DRIVER), 'freeze'] and command.get('timeout') == 600
            and host.get('exit_code') == guest.get('exit_code') == 0
            and host.get('abort') is None and guest.get('abort') is None
            and guest.get('child_group_cleanup_attempted') is True, 'Freeze outer guard did not complete cleanly')


def finite(value, field):
    require(not isinstance(value, bool) and isinstance(value, (int, float, str)), 'Invalid numeric ' + field)
    try:
        number = float(value)
    except (TypeError, ValueError) as error:
        raise ScopeError('Invalid numeric ' + field) from error
    require(math.isfinite(number) and number >= 0, 'Nonfinite/negative ' + field)
    return number


def check_sample(sample):
    require(isinstance(sample, dict) and isinstance(sample.get('host'), dict), 'Malformed memory sample')
    host = sample['host']
    require(host.get('abort') is None, 'Host guard abort: ' + str(host.get('abort')))
    require(isinstance(host.get('gpu'), dict), 'Host GPU telemetry missing')
    for name in ('monotonic', 'epoch', 'guest_available_bytes', 'guest_swap_used_bytes', 'sample_duration_s'):
        finite(sample.get(name), name)
    require(isinstance(sample.get('meminfo_raw'), str) and bool(sample['meminfo_raw'].strip()), 'Full meminfo raw missing')
    require(sample.get('process_status_raw') is None and sample.get('process_rss_bytes') is None
            and sample.get('process_hwm_bytes') is None, 'Auxiliary window must have no model PID')
    counters = sample.get('guest_swap_counters_pages')
    require(isinstance(counters, dict) and set(counters) == {'pswpin', 'pswpout'}, 'Swap counter evidence missing')
    for key, value in counters.items():
        finite(value, key)
    for name in ('time', 'available_ram_bytes', 'disk_free_bytes'):
        finite(host.get(name), name)
    for name in ('total_mib', 'used_mib', 'utilization_percent'):
        finite(host['gpu'].get(name), name)
    require(0 <= float(sample['epoch']) - float(host['time']) <= 8, 'Stale/future host GPU heartbeat')
    require(float(host['available_ram_bytes']) >= SETTLE_POLICY['host_ram_floor_bytes']
            and float(host['disk_free_bytes']) >= SETTLE_POLICY['disk_floor_bytes'], 'Hard RAM/disk floor reached')
    require(float(host['gpu']['used_mib']) <= float(host['gpu']['total_mib'])
            and float(host['gpu']['utilization_percent']) <= 100, 'GPU field exceeds physical range')


def summarize_window(samples):
    require(len(samples) >= SETTLE_POLICY['min_samples'], 'Too few auxiliary observations')
    for sample in samples:
        check_sample(sample)
    times = [float(s['monotonic']) for s in samples]
    gaps = [b - a for a, b in zip(times, times[1:])]
    require(all(0 < gap <= 3 for gap in gaps), 'Auxiliary sample cadence gap/order invalid')
    require(times[-1] - times[0] >= 24, 'Auxiliary samples do not cover a genuine window')
    unique = []
    for sample in samples:
        host = sample['host']
        if unique and host['time'] == unique[-1]['time']:
            require(host == unique[-1], 'One heartbeat timestamp changed its raw values')
        else:
            require(not unique or float(host['time']) > float(unique[-1]['time']), 'Heartbeat timestamps went backwards')
            unique.append(host)
    require(len(unique) >= 2, 'No independent host GPU observations')
    host_gaps = [float(b['time']) - float(a['time']) for a, b in zip(unique, unique[1:])]
    require(max(host_gaps, default=0) <= 8, 'Effective host GPU gap exceeds freshness budget')
    ram = [float(s['host']['available_ram_bytes']) for s in samples]
    gpu = [float(s['host']['gpu']['used_mib']) for s in samples]
    util = [float(s['host']['gpu']['utilization_percent']) for s in samples]
    summary = {'host_ram_range_mib': (max(ram) - min(ram)) / 1024**2,
               'global_vram_range_mib': max(gpu) - min(gpu),
               'gpu_utilization_median_percent': statistics.median(util),
               'max_sample_gap_seconds': max(gaps, default=0),
               'max_effective_gpu_gap_seconds': max(host_gaps, default=0),
               'unique_host_queries': len(unique)}
    failures = [name for name, bad in (
        ('host_ram_spread', summary['host_ram_range_mib'] > 512),
        ('global_vram_spread', summary['global_vram_range_mib'] > 128),
        ('gpu_utilization', summary['gpu_utilization_median_percent'] > 10)) if bad]
    return summary, failures


def collect_window(folder, index, deadline, sample_fn=None, monotonic=None, sleep=None):
    sample_fn, monotonic, sleep = sample_fn or core.memory_sample, monotonic or time.monotonic, sleep or time.sleep
    fresh(folder)
    folder.mkdir(exist_ok=False)
    started = monotonic()
    end = started + SETTLE_POLICY['window_seconds']
    state = {'schema_version': 1, 'window_index': index, 'status': 'FAIL',
             'started_monotonic': started, 'sample_count': 0, 'threshold_failures': []}
    samples, error = [], None
    try:
        require(end <= deadline, 'Not enough remaining elapsed budget for a full 30-second window')
        with (folder / 'memory.jsonl').open('x', encoding='utf-8') as stream:
            while monotonic() < end:
                require(monotonic() < deadline, 'Auxiliary settling elapsed budget exhausted')
                observed_at = monotonic()
                sample = sample_fn()
                sample['phase'] = 'auxiliary_pretrial_settling'
                stream.write(json.dumps(sample) + '\n')
                stream.flush()
                samples.append(sample)
                check_sample(sample)
                require(monotonic() <= deadline, 'Auxiliary sampling overran elapsed budget')
                sleep(max(0, min(1 - (monotonic() - observed_at), end - monotonic(), deadline - monotonic())))
        require(monotonic() <= deadline, 'Auxiliary window overran elapsed budget')
        summary, failures = summarize_window(samples)
        state.update(status='THRESHOLD_WAIT' if failures else 'PASS', summary=summary, threshold_failures=failures)
    except (Exception, ScopeInterrupted) as caught:
        error = caught
        state['error'] = f'{type(caught).__name__}: {caught}'
    finally:
        finished = monotonic()
        state.update(finished_monotonic=finished, elapsed_seconds=finished - started, sample_count=len(samples),
                     memory_sha256=sha(folder / 'memory.jsonl') if (folder / 'memory.jsonl').exists() else None)
        write_new(folder / 'window.json', state)
    if error is not None:
        raise error
    return state


def hash_model_before_trial(receipt_path, monotonic=None, health=None):
    """Actual full model read, bounded independently of idle observation time."""
    monotonic, health = monotonic or time.monotonic, health or core.host_health
    lock = read(PACKAGE / 'inputs.lock.json')
    expected = lock['model']
    model = DATA / 'models' / expected['filename']
    safe_path(model, existing=True)
    started = monotonic()
    state = {'schema_version': 1, 'status': 'FAIL', 'started_utc': core.utc(),
             'started_monotonic': started, 'model_path': str(model),
             'expected_bytes': expected['bytes'], 'expected_sha256': expected['sha256'],
             'bytes_read': 0, 'host_health_checks': 0, 'health_observations': [],
             'guard_directory': os.environ.get('VRAMLAB_GUARD_DIRECTORY'), 'cache_scope': MODEL_HASH_POLICY['cache_scope']}
    error = None
    def observe_health():
        host = health()
        require(isinstance(host, dict) and host.get('abort') is None, 'Model hash host guard unhealthy')
        epoch = time.time()
        host_time = finite(host.get('time'), 'model hash host time')
        require(0 <= epoch - host_time <= 8, 'Model hash host heartbeat stale/future')
        state['health_observations'].append({'monotonic': monotonic(), 'epoch': epoch,
            'host_time': host_time, 'host_sha256': canonical_sha(host)})
        state['host_health_checks'] += 1
    try:
        initial = model.stat()
        state['actual_bytes_before'] = initial.st_size
        require(initial.st_size == expected['bytes'], 'Per-trial model size differs from pinned lock')
        digest = hashlib.sha256()
        with model.open('rb') as stream:
            while True:
                observe_health()
                require(monotonic() - started < 120, 'Per-trial model hash elapsed budget exhausted')
                block = stream.read(MODEL_HASH_POLICY['chunk_bytes'])
                require(monotonic() - started <= 120, 'Per-trial model read overran elapsed budget')
                if not block:
                    break
                digest.update(block)
                state['bytes_read'] += len(block)
                require(state['bytes_read'] <= expected['bytes'], 'Per-trial model grew while hashing')
        observe_health()
        after = model.stat()
        state.update(actual_bytes_after=after.st_size, actual_sha256=digest.hexdigest())
        require((initial.st_size, initial.st_mtime_ns, initial.st_ino) == (after.st_size, after.st_mtime_ns, after.st_ino),
                'Per-trial model changed while hashing')
        require(state['bytes_read'] == expected['bytes'] and state['actual_sha256'] == expected['sha256'],
                'Per-trial actual model hash differs from pinned lock')
        expected_checks = math.ceil(expected['bytes'] / MODEL_HASH_POLICY['chunk_bytes']) + 2
        require(state['host_health_checks'] == expected_checks, 'Model hash did not observe health for every full read')
        require(monotonic() - started <= 120, 'Per-trial hash finalization overran elapsed budget')
        state['status'] = 'PASS'
    except (Exception, ScopeInterrupted) as caught:
        error = caught
        state['error'] = f'{type(caught).__name__}: {caught}'
    finally:
        finished = monotonic()
        state.update(finished_utc=core.utc(), finished_monotonic=finished, elapsed_seconds=finished - started)
        write_new(receipt_path, state)
    if error is not None:
        raise error
    return state


def settle_before_trial(item, index, protocol_sha, driver_sha, sample_fn=None, monotonic=None, sleep=None, hash_fn=None):
    monotonic = monotonic or time.monotonic
    folder = SETTLING / item['id']
    fresh(folder)
    folder.mkdir(exist_ok=False)
    state = {'schema_version': 1, 'scope_id': 'bounded-v1', 'trial_id': item['id'], 'order_index': index,
             'context': item['context'], 'gpu_layers': item['gpu_layers'], 'repetition': item['repetition'],
             'status': 'STOPPED', 'preparation_started_monotonic': monotonic(), 'started_monotonic': None,
             'windows': [], 'original_trial_called': False, 'server_started': False,
             'protocol_sha256': protocol_sha, 'driver_sha256': driver_sha}
    error = None
    try:
        hash_receipt = folder / 'model-hash.json'
        (hash_fn or hash_model_before_trial)(hash_receipt)
        state['model_hash_sha256'] = sha(hash_receipt)
        started = monotonic()
        state['started_monotonic'] = started
        deadline = started + SETTLE_POLICY['max_elapsed_seconds']
        for window_index in range(1, SETTLE_POLICY['max_windows'] + 1):
            window = folder / f'window-{window_index:02d}'
            try:
                result = collect_window(window, window_index, deadline, sample_fn, monotonic, sleep)
            finally:
                if (window / 'window.json').exists():
                    recorded = read(window / 'window.json')
                    state['windows'].append({'source': str(window), 'sha256': sha(window / 'window.json'),
                                             'memory_sha256': recorded.get('memory_sha256'), 'status': recorded['status']})
            require(monotonic() - started <= 300, 'Auxiliary settling elapsed budget exceeded')
            if result['status'] == 'PASS':
                state['status'] = 'PASS'
                break
            require(result['status'] == 'THRESHOLD_WAIT', 'Only threshold failure permits another idle window')
        require(state['status'] == 'PASS', 'No stable host window within max10/300 seconds; no model launched')
    except (Exception, ScopeInterrupted) as caught:
        error = caught
        state['error'] = f'{type(caught).__name__}: {caught}'
    finally:
        finished = monotonic()
        state.update(finished_monotonic=finished,
                     elapsed_seconds=finished - state['started_monotonic'] if state['started_monotonic'] is not None else None,
                     preparation_elapsed_seconds=finished - state['preparation_started_monotonic'])
        if (folder / 'model-hash.json').exists():
            state['model_hash_sha256'] = sha(folder / 'model-hash.json')
        atomic_receipt(folder / 'settling.json', state)
    if error is not None:
        raise error
    return state


def make_trial_wrapper(original, protocol, state, receipt_path):
    """One settling invocation, then at most one exact original call per order row."""
    def wrapped(out, context, layers, phase, protocol_path=None, reference=None, runtime=None, prepared=False, server_override=None):
        require(not state.get('actual_trial_failed'), 'Original model trial failed; no subsequent attempt permitted')
        index = state['actual_trial_calls']
        require(index < len(protocol['order']), 'Unexpected extra model attempt')
        item = protocol['order'][index]
        require(Path(out) == PRIMARY / item['id'] and context == item['context'] and layers == item['gpu_layers']
                and phase == 'primary' and Path(protocol_path) == PROTOCOL
                and prepared is False and server_override is None, 'Trial callable differs from frozen order/signature')
        require(runtime is not None and core.binding_identity(runtime) == core.binding_identity(protocol['runtime_reference']),
                'Original batch runtime argument changed')
        require(sha(DRIVER) == state['driver_sha256_before'] and current_core_hashes() == state['core_scripts_sha256_before'],
                'Executable inputs changed before a model attempt')
        core.host_health()
        guard_elapsed(Path(state['guard_directory']), state['outer_guard_budget_seconds'])
        require(time.monotonic() - state['started_monotonic'] <= state['outer_guard_budget_seconds'], 'Outer elapsed budget exhausted')
        path = SETTLING / item['id'] / 'settling.json'
        try:
            settling = settle_before_trial(item, index, state['protocol_sha256'], state['driver_sha256_before'])
        finally:
            if path.exists():
                recorded = read(path)
                record = {'trial_id': item['id'], 'source': str(path), 'sha256': sha(path),
                          'status': recorded['status'], 'original_trial_called': False, 'server_started': False,
                          'model_hash_sha256': recorded.get('model_hash_sha256')}
                state['settling_records'].append(record)
                atomic_receipt(receipt_path, state)
        # The original trial receives the exact original reference/runtime. Its
        # independent 30s baseline, drift gate and failure handling remain intact.
        core.host_health()
        guard_elapsed(Path(state['guard_directory']), state['outer_guard_budget_seconds'])
        require(time.monotonic() - state['started_monotonic'] < state['outer_guard_budget_seconds'], 'Outer elapsed budget exhausted')
        require(sha(DRIVER) == state['driver_sha256_before'] and sha(PROTOCOL) == state['protocol_sha256'],
                'Driver/protocol changed while settling')
        state['actual_trial_calls'] += 1
        settling['original_trial_called'] = record['original_trial_called'] = True
        settling['original_trial_called_monotonic'] = time.monotonic()
        atomic_receipt(path, settling)
        record['sha256'] = sha(path)
        state['status'] = 'running_original_trial'
        atomic_receipt(receipt_path, state)
        try:
            result = original(out, context, layers, phase, protocol_path, reference, runtime=runtime,
                              prepared=prepared, server_override=server_override)
        finally:
            result_path = Path(out) / 'result.json'
            observed = read(result_path) if result_path.is_file() else None
            settling['server_started'] = record['server_started'] = (
                bool(observed.get('server_pid')) if observed is not None else None)
            settling['original_trial_finished_monotonic'] = time.monotonic()
            atomic_receipt(path, settling)
            record['sha256'] = sha(path)
            atomic_receipt(receipt_path, state)
        if result.get('status') != 'completed_pending_validation':
            state['actual_trial_failed'] = True
        return result
    return wrapped


def final_primary_evidence(protocol):
    batch = read(PRIMARY / 'batch.json')
    require(batch.get('status') == 'all_retained_primary_trials_validated'
            and batch.get('input_verification_status') == 'PASS' and batch.get('runtime_unchanged') is True
            and batch.get('raw_validation_status') == 'raw_checks_passed', 'Core batch did not complete with final post binding')
    require(len(batch['trials']) == 18 and [row['id'] for row in batch['trials']] == [row['id'] for row in protocol['order']],
            'Core batch order/count differs')
    rows = []
    for item in protocol['order']:
        folder = PRIMARY / item['id']
        receipt = validator.validate(folder, PROTOCOL, package_root=PACKAGE)
        saved_path = PRIMARY / (item['id'] + '.validation.json')
        saved = read(saved_path)
        require(receipt['status'] == saved.get('status') == 'raw_checks_passed'
                and saved.get('result_sha256') == sha(folder / 'result.json'), 'Final independent validation receipt differs')
        rows.append({'id': item['id'], 'result_sha256': sha(folder / 'result.json'), 'validation_sha256': sha(saved_path)})
    return rows


def execute(mode):
    guard, command = require_layout(mode)
    receipt_path = BASE / (mode + '-driver-receipt.json')
    with (DATA / 'measurement.lock').open('a') as lock:
        core.fcntl.flock(lock, core.fcntl.LOCK_EX | core.fcntl.LOCK_NB)
        if mode == 'freeze':
            fresh(BASE)
            BASE.mkdir(exist_ok=False)
        else:
            safe_path(BASE, existing=True)
            require(read(BASE / 'freeze-driver-receipt.json').get('success') is True, 'Supplemental freeze did not complete')
            fresh(PRIMARY)
            fresh(SETTLING)
            SETTLING.mkdir(exist_ok=False)
        fresh(receipt_path)
        fresh(Path(str(receipt_path) + '.tmp'))
        before_inventory = history_inventory()
        guard_started_epoch, _ = guard_elapsed(guard, command['timeout'])
        state = {'schema_version': 1, 'phase': mode, 'scope_id': 'bounded-v1', 'status': 'preparing',
                 'success': False, 'driver_exit_code': None, 'started_utc': core.utc(), 'started_monotonic': time.monotonic(),
                 'driver_sha256_before': sha(DRIVER), 'core_scripts_sha256_before': current_core_hashes(),
                 'guard_directory': str(guard), 'guard_command_sha256': sha(guard / 'command.json'),
                 'guard_started_epoch': guard_started_epoch,
                 'outer_guard_budget_seconds': command['timeout'], 'actual_trial_calls': 0, 'settling_records': [],
                 'actual_trial_calls_scope': 'Original trial callable invocations; server_started separately requires actual result.server_pid',
                 'historical_eight_condition_contract': 'NOT_MET',
                 'historical_inventory_before_sha256': canonical_sha(before_inventory),
                 'external_kill_limit': 'SIGKILL can leave partial receipts; observed host/guest exit and final audit are required',
                 'exit_code_scope': 'Driver return code; observed OS exit remains in host/guest guard receipts'}
        atomic_receipt(receipt_path, state)
        interrupted = None

        def on_signal(signum, frame):
            state.update(status='guard_signal_received', success=False, signal=signum,
                         driver_exit_code=128 + signum, finished_utc=core.utc())
            atomic_receipt(receipt_path, state)
            raise ScopeInterrupted(signum)

        previous = {sig: signal.signal(sig, on_signal) for sig in (signal.SIGTERM, signal.SIGINT)}
        try:
            with bounded_core() as original_trial:
                if mode == 'freeze':
                    scouts = validate_scouts()
                    history = historical_scope()
                    fresh(DERIVED)
                    core.freeze(DERIVED, SCOUTS)
                    derived = core.check_protocol(DERIVED)
                    protocol = extend_protocol(derived, scouts, history, before_inventory)
                    write_new(PROTOCOL, protocol)
                    check_scope_protocol()
                    state.update(status='frozen_bounded_scope', protocol_sha256=sha(PROTOCOL),
                                 derived_protocol_sha256=sha(DERIVED), primary_trials_planned=18)
                else:
                    protocol = check_scope_protocol()
                    check_freeze_receipt(protocol)
                    state.update(status='running_primary', protocol_sha256=sha(PROTOCOL),
                                 derived_protocol_sha256=sha(DERIVED), primary_trials_planned=18)
                    atomic_receipt(receipt_path, state)
                    core.trial = make_trial_wrapper(original_trial, protocol, state, receipt_path)
                    # No copied primary engine and no altered primary flags, runtime,
                    # first-trial reference, baseline or result/finalization methods.
                    core.run_primary(PRIMARY, PROTOCOL)
                    state['final_trials'] = final_primary_evidence(protocol)
                    require(state['actual_trial_calls'] == 18 and len(state['settling_records']) == 18
                            and all(r['status'] == 'PASS' and r['original_trial_called'] and r['server_started'] is True
                                    for r in state['settling_records']),
                            'Supplemental trial/settling count differs')
                    state['status'] = 'completed_primary'
            core.host_health()
            state['success'] = True
            state['driver_exit_code'] = 0
        except (Exception, ScopeInterrupted) as caught:
            if isinstance(caught, ScopeInterrupted):
                interrupted = caught.signum
            state.update(status='supplemental_scope_failed', success=False,
                         error=f'{type(caught).__name__}: {caught}',
                         failure_class='instrumentation_invalid' if isinstance(caught, ScopeError) else core.classify_failure(caught))
        finally:
            try:
                after_inventory = history_inventory()
                state.update(historical_inventory_after_sha256=canonical_sha(after_inventory), immutable_history=after_inventory == before_inventory,
                             driver_sha256_after=sha(DRIVER), core_scripts_sha256_after=current_core_hashes())
                require(state['immutable_history'] and state['driver_sha256_after'] == state['driver_sha256_before']
                        and state['core_scripts_sha256_after'] == state['core_scripts_sha256_before'],
                        'Ancillary/core/original evidence changed during supplemental operation')
                if 'protocol_sha256' in state:
                    require(sha(PROTOCOL) == state['protocol_sha256'] and sha(DERIVED) == state['derived_protocol_sha256'],
                            'Frozen protocol changed during operation')
                require(sha(guard / 'command.json') == state['guard_command_sha256'], 'Guard command changed during operation')
                require(time.monotonic() - state['started_monotonic'] <= state['outer_guard_budget_seconds'], 'Outer operation overran elapsed budget')
                _, state['elapsed_in_guard_seconds'] = guard_elapsed(guard, state['outer_guard_budget_seconds'])
            except Exception as caught:
                state.update(status='supplemental_scope_failed', success=False, failure_class='instrumentation_invalid',
                             finalization_error=f'{type(caught).__name__}: {caught}')
            if (PRIMARY / 'batch.json').is_file():
                state['primary_batch_sha256'] = sha(PRIMARY / 'batch.json')
                state['primary_batch_status'] = read(PRIMARY / 'batch.json').get('status')
            if not state['success']:
                state['driver_exit_code'] = 128 + interrupted if interrupted else 1
            state.update(finished_utc=core.utc(), finished_monotonic=time.monotonic())
            state['elapsed_seconds'] = state['finished_monotonic'] - state['started_monotonic']
            atomic_receipt(receipt_path, state)
            for signum, handler in previous.items():
                signal.signal(signum, handler)
        return state


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('freeze', 'primary'))
    args = parser.parse_args()
    try:
        state = execute(args.mode)
    except Exception as error:
        print(json.dumps({'status': 'supplemental_preflight_or_receipt_failure', 'success': False,
                          'driver_exit_code': 1, 'error': f'{type(error).__name__}: {error}'}), flush=True)
        return 1
    print(json.dumps({'status': state['status'], 'success': state['success'], 'driver_exit_code': state['driver_exit_code'],
                      'receipt': str(BASE / (args.mode + '-driver-receipt.json'))}), flush=True)
    return state['driver_exit_code']


if __name__ == '__main__':
    raise SystemExit(main())
