#!/usr/bin/env bash
# Fresh build/cache only. Existing dedicated guest, locked source and toolchain.
# Run after primary through guard_rtx.py; never run against the production guest.
set -euo pipefail
[[ ${WSL_DISTRO_NAME:-} == VRAMLab-RTX-Context ]] || { echo 'Wrong WSL distribution' >&2; exit 2; }
[[ -n ${VRAMLAB_GUARD_DIRECTORY:-} ]] || { echo 'Windows host guard required' >&2; exit 2; }
[[ $# == 0 ]] || { echo 'No path/flag overrides accepted' >&2; exit 2; }
pkg=$(cd "$(dirname "$0")/.." && pwd -P)
src=$pkg/data/rtx/llama.cpp
out=$pkg/data/rtx/reproduction-20261007
build=$out/build
helper=$pkg/scripts/snapshot_rtx_reader.py
[[ -f $pkg/inputs.lock.json && -d $src && -f $helper ]]
[[ -x /usr/local/cuda-13.2/bin/nvcc && -x /usr/bin/g++ ]]
[[ ! -e $out && ! -L $out ]] || { echo 'Reader directory already exists; preserve it' >&2; exit 2; }
python3 "$helper" --check-guard
mkdir "$out"
trap 'rc=$?; printf "%s\n" "$rc" > "$out/build-exit-code.txt"' EXIT
trap 'exit 143' TERM
trap 'exit 130' INT
exec > >(tee "$out/build.log") 2>&1
printf '%s\n' 'Reader setup only: fresh build/cache, reused guest/source/toolchain; primary 0.'
python3 "$helper" --inputs-only "$out/build-inputs-before.json"
check_guard() { python3 "$helper" --check-guard; }
# Reject inherited compile/cache control rather than silently using old caches.
[[ -z ${CC:-} && -z ${CXX:-} && -z ${CUDAHOSTCXX:-} && -z ${CUDACXX:-} ]]
[[ -z ${CFLAGS:-} && -z ${CXXFLAGS:-} && -z ${LDFLAGS:-} && -z ${CUDAFLAGS:-} ]]
[[ -z ${CMAKE_TOOLCHAIN_FILE:-} && -z ${CMAKE_PREFIX_PATH:-} && -z ${CMAKE_GENERATOR:-} ]]
[[ -z ${CCACHE_DIR:-} && -z ${SCCACHE_DIR:-} ]]
# A clean process environment is used for CMake/Ninja and excludes loader/CUDA
# overrides. No apt, download, source clone, OS restart, or cache purge occurs.
task_env=(env -i PATH=/usr/local/cuda-13.2/bin:/usr/lib/wsl/lib:/usr/bin:/bin
  LANG=C.UTF-8 LD_LIBRARY_PATH=/usr/local/cuda-13.2/lib64:/usr/lib/wsl/lib
  CUDA_VISIBLE_DEVICES=0 OMP_NUM_THREADS=4)
check_guard
"${task_env[@]}" /usr/local/cuda-13.2/bin/nvcc --version > "$out/nvcc-version.txt"
"${task_env[@]}" cmake --version > "$out/cmake-version.txt"
"${task_env[@]}" /usr/bin/g++ --version > "$out/gcc-version.txt"
"${task_env[@]}" cmake -S "$src" -B "$build" -G Ninja \
  -DGGML_CUDA=ON -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_C_COMPILER=/usr/bin/gcc -DCMAKE_CXX_COMPILER=/usr/bin/g++ \
  -DCMAKE_CUDA_COMPILER=/usr/local/cuda-13.2/bin/nvcc \
  -DCMAKE_CUDA_HOST_COMPILER=/usr/bin/g++ \
  -DCMAKE_CUDA_ARCHITECTURES=120-real -DGGML_CUDA_FA_QUANTS=f16-f16 \
  -DCMAKE_C_COMPILER_LAUNCHER= -DCMAKE_CXX_COMPILER_LAUNCHER= -DCMAKE_CUDA_COMPILER_LAUNCHER= \
  -DLLAMA_OPENSSL=OFF -DLLAMA_BUILD_TESTS=OFF
check_guard
"${task_env[@]}" cmake --build "$build" --target llama-server --parallel 2
check_guard
"${task_env[@]}" "$build/bin/llama-server" --version > "$out/server-version.txt" 2>&1
"${task_env[@]}" "$build/bin/llama-server" --help > "$out/server-help.txt" 2>&1
check_guard
python3 "$helper" "$out/build-runtime-after.json" --build-directory "$build"
check_guard
printf '%s\n' 'READER BUILD COMPLETE. No completion request or primary trial was run.'
