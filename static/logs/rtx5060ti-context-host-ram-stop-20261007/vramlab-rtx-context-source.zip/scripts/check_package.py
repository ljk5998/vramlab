#!/usr/bin/env python3
"""Offline handoff integrity checks. Optional read-only model verification."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import sys

PACKAGE = Path(__file__).resolve().parents[1]
ROOT = PACKAGE.parents[1]


def verify_file(path, expected_size, expected_sha):
    path = Path(path)
    if path.stat().st_size != expected_size:
        raise ValueError("Model byte count differs from the locked input")
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(4 * 1024 * 1024), b""):
            digest.update(chunk)
    if digest.hexdigest() != expected_sha:
        raise ValueError("Model SHA-256 differs from the locked input")
    return digest.hexdigest()


def check_package():
    lock = json.loads((PACKAGE / "inputs.lock.json").read_text(encoding="utf-8"))
    assert lock["schema_version"] == 1
    assert lock["status"] == "prepared_not_measured"
    model = lock["model"]
    assert re.fullmatch(r"[0-9a-f]{40}", lock["llama_cpp"]["commit"])
    assert re.fullmatch(r"[0-9a-f]{40}", model["revision"])
    assert re.fullmatch(r"[0-9a-f]{64}", model["sha256"])
    assert model["bytes"] == 5027783488
    assert model["url"] == (
        f'https://huggingface.co/{model["repository"]}/resolve/'
        f'{model["revision"]}/{model["filename"]}'
    )
    assert lock["protocol"]["contexts"] == [2048, 4096, 8192, 16384]
    assert lock["protocol"]["fit"] == "off"
    assert lock["protocol"]["parallel_slots"] == 1
    required = [
        ROOT / "HANDOFF_VRAMLAB.md", ROOT / "HANDOFF_MAC_M4.md",
        ROOT / "NEXT_EXPERIMENTS.md", ROOT / "RESUME_VRAMLAB_MAC.txt",
        ROOT / "RESUME_VRAMLAB_5060TI.txt", PACKAGE / "README.md",
        PACKAGE / "PLAN_5060TI.md", PACKAGE / "PLAN_MAC_M4.md",
        PACKAGE / "PACKAGE_QA.md",
    ]
    for path in required:
        content = path.read_text(encoding="utf-8")
        assert content.strip(), f"Empty handoff: {path.name}"
        # Only Markdown destinations; ignore remote links and inline-code paths.
        for target in re.findall(r"\]\(([^)]+)\)", content):
            if "://" in target or target.startswith("#"):
                continue
            target = target.split("#", 1)[0]
            assert (path.parent / target).exists(), f"Broken link in {path.name}: {target}"
    shell = PACKAGE / "scripts/preflight_macos.sh"
    assert b"\r" not in shell.read_bytes(), "Mac shell script must use LF"
    mac = (ROOT / "HANDOFF_MAC_M4.md").read_text(encoding="utf-8")
    for value in (lock["llama_cpp"]["commit"], model["url"]):
        assert value in mac, "Mac commands drifted from inputs.lock.json"
    return lock


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, help="existing GGUF (or .part) to verify; no download")
    args = parser.parse_args()
    try:
        lock = check_package()
        if args.model:
            digest = verify_file(args.model, lock["model"]["bytes"], lock["model"]["sha256"])
            print(f"MODEL PASS: {digest}")
        print("PACKAGE PASS: handoff links, input lock and Mac commands; no hardware test performed.")
    except (AssertionError, OSError, ValueError, KeyError) as error:
        print(f"FAIL: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
