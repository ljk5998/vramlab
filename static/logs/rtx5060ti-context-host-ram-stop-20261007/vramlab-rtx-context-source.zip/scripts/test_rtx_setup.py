#!/usr/bin/env python3
"""No-GPU failure-path tests for the setup SSE reader and raw-data validator."""
import contextlib
import http.server
import json
from pathlib import Path
import tempfile
import threading
import time
import unittest

from prepare_rtx import stream_completion


@contextlib.contextmanager
def endpoint(mode):
    class Handler(http.server.BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def do_POST(self):
            self.rfile.read(int(self.headers["Content-Length"]))
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.end_headers()
            try:
                if mode == "timeout":
                    time.sleep(0.3)
                    return
                if mode == "malformed":
                    self.wfile.write(b"data: [broken\n\n")
                    return
                records = [{"content": "", "tokens": [], "stop": False},
                           {"content": "A", "tokens": [42], "stop": False},
                           {"content": "", "tokens": [], "stop": True}]
                for item in records:
                    self.wfile.write(("data: " + json.dumps(item) + "\n\n").encode())
                    self.wfile.flush()
                    time.sleep(0.01)
            except (BrokenPipeError, ConnectionResetError):
                pass

    server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    worker = threading.Thread(target=server.serve_forever, daemon=True)
    worker.start()
    try:
        yield "http://127.0.0.1:" + str(server.server_port)
    finally:
        server.shutdown()
        server.server_close()
        worker.join()


class SetupTests(unittest.TestCase):
    def test_ttft_ignores_metadata_and_preserves_raw(self):
        with tempfile.TemporaryDirectory() as temporary, endpoint("normal") as base:
            result = stream_completion(base, {}, Path(temporary), 1, 2)
            records = [json.loads(line) for line in (Path(temporary) / "events.jsonl").read_text().splitlines()]
            self.assertEqual(result["first_content_monotonic"], records[1]["received_monotonic"])
            self.assertEqual(result["stream_token_count"], 1)
            self.assertIn(b'"content": "A"', (Path(temporary) / "response.sse").read_bytes())

    def test_malformed_response_rejected_and_preserved(self):
        with tempfile.TemporaryDirectory() as temporary, endpoint("malformed") as base:
            with self.assertRaises(ValueError):
                stream_completion(base, {}, Path(temporary), 1, 2)
            self.assertIn(b"[broken", (Path(temporary) / "response.sse").read_bytes())

    def test_first_content_timeout(self):
        with tempfile.TemporaryDirectory() as temporary, endpoint("timeout") as base:
            with self.assertRaises(TimeoutError):
                stream_completion(base, {}, Path(temporary), 0.1, 0.2)

if __name__ == "__main__":
    unittest.main()
