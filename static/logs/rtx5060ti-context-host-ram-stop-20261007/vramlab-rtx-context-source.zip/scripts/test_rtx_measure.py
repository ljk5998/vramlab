#!/usr/bin/env python3
"""No-GPU stream, deadline, effective-setting and baseline failure controls."""
import json
import os
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

# Staging controls may import unchanged dependencies from a read-only directory.
if os.environ.get('VRAMLAB_TEST_IMPORT_DIRECTORY'):
    sys.path.append(os.environ['VRAMLAB_TEST_IMPORT_DIRECTORY'])

from test_rtx_setup import endpoint
from rtx_measure import stream, startup_check, baseline_check
import rtx_measure as measure



def control_directory():
    directory = os.environ.get('VRAMLAB_TEST_TEMP_DIRECTORY')
    if directory and not Path(directory).resolve().is_dir():
        raise ValueError('Explicit test temporary root must exist')
    return tempfile.TemporaryDirectory(dir=directory)

class MeasureTests(unittest.TestCase):
    def test_content_timestamp_excludes_empty_event(self):
        with control_directory() as folder, endpoint('normal') as base:
            result=stream(base,{},Path(folder),lambda:None,1,2)
            events=[json.loads(line) for line in (Path(folder)/'events.jsonl').read_text().splitlines()]
            self.assertEqual(result['first_content_monotonic'],events[1]['received_monotonic'])
            self.assertEqual(result['final_monotonic'],events[-1]['received_monotonic'])

    def test_invalid_stream_is_saved_and_rejected(self):
        with control_directory() as folder, endpoint('malformed') as base:
            with self.assertRaises(ValueError):
                stream(base,{},Path(folder),lambda:None,1,2)
            self.assertIn('[broken',(Path(folder)/'response.sse').read_text())

    def test_first_content_deadline(self):
        with control_directory() as folder, endpoint('timeout') as base:
            with self.assertRaisesRegex(TimeoutError,'first_content_timeout'):
                stream(base,{},Path(folder),lambda:None,.1,.2)

    def test_total_deadline_after_first_content(self):
        with control_directory() as folder:
            queue = measure.queue.Queue()
            started = measure.time.monotonic()
            queue.put((started, {'content':'first'}))
            with self.assertRaisesRegex(TimeoutError,'total_request_timeout'):
                measure._consume_stream(queue,Path(folder),lambda:None,started,1,.05)
            self.assertIn('first',(Path(folder)/'events.jsonl').read_text())

    def test_completed_reader_has_closed_raw_output(self):
        with control_directory() as folder, endpoint('normal') as base:
            out=Path(folder)
            stream(base,{},out,lambda:None,1,2)
            self.assertTrue(measure.finish_stream_reader(out))
            self.assertNotIn(out.resolve(),measure.STREAM_READERS)

    def test_collector_failure_stops_request(self):
        def failure():
            raise RuntimeError('collector_stale')
        with control_directory() as folder, endpoint('timeout') as base:
            with self.assertRaisesRegex(RuntimeError,'collector_stale'):
                stream(base,{},Path(folder),failure,1,2)

    def test_cpu_fallback_rejected(self):
        with self.assertRaises(ValueError):
            startup_check('offloaded 0/37 layers to GPU\nn_ctx_seq = 2048',2048,'all')

    def test_busy_baseline_rejected(self):
        samples=[{'host':{'available_ram_bytes':5*1024**3,'gpu':{'used_mib':'1000','utilization_percent':'99'}}} for _ in range(30)]
        with self.assertRaisesRegex(ValueError,'utilization'):
            baseline_check(samples)

    def test_cross_trial_drift_rejected(self):
        samples=[{'host':{'available_ram_bytes':5*1024**3,'gpu':{'used_mib':'1000','utilization_percent':'0'}}} for _ in range(30)]
        with self.assertRaisesRegex(ValueError,'Cross-trial'):
            baseline_check(samples,{'host_available_bytes':5*1024**3,'gpu_used_mib':500})


class BindingControls(unittest.TestCase):
    """Tiny actual byte hashes plus mocked runtime/validator; no Git/WSL/GPU."""
    def setUp(self):
        self.temp=control_directory()
        self.addCleanup(self.temp.cleanup)
        self.package=Path(self.temp.name)
        self.data=self.package/'data/rtx'
        for name in ('scripts','fixtures','data/rtx/models','data/rtx/build/bin'):
            (self.package/name).mkdir(parents=True)
        for name in measure.SCRIPT_NAMES:
            (self.package/'scripts'/name).write_text('# synthetic control\n')
        for context in measure.CONTEXTS:
            (self.package/'fixtures'/f'rtx-tokens-{context}.json').write_text('[1,2,3]')
        self.model=self.data/'models/tiny.gguf'
        self.model.write_bytes(b'not a real model')
        self.binary=self.data/'build/bin/llama-server'
        self.binary.write_bytes(b'not executable')
        self.lock={'llama_cpp':{'commit':'a'*40},'model':{'filename':'tiny.gguf',
             'bytes':self.model.stat().st_size,'sha256':measure.sha(self.model),'revision':'b'*40}}
        measure.save(self.package/'inputs.lock.json',self.lock)
        self.enter(patch.object(measure,'PACKAGE',self.package))
        self.enter(patch.object(measure,'DATA',self.data))
        self.enter(patch.object(measure,'capture',self.capture))
        self.validator=types.SimpleNamespace(validate=lambda *a,**k:{
            'status':'trial_checks_passed_batch_post_pending' if k.get('allow_pending_batch_post') else 'raw_checks_passed',
            'metrics':{'control':True}})
        self.enter(patch.dict(sys.modules,{'validate_rtx_trial':self.validator}))

    def enter(self,context):
        value=context.__enter__()
        self.addCleanup(context.__exit__,None,None,None)
        return value

    def capture(self,path,dirty=''):
        measure.save(path,{'source_commit':self.lock['llama_cpp']['commit'],'source_status':dirty,
            'files':{str(self.binary):{'resolved':str(self.binary),'bytes':self.binary.stat().st_size,
                                     'sha256':measure.sha(self.binary)}},'time':measure.time.time()})

    def fake_trial(self,out,context,layers,phase,protocol=None,reference=None,runtime=None,prepared=False):
        if not prepared:
            out.mkdir(parents=True,exist_ok=False)
        (out/'server.log').write_text('synthetic; no server ran')
        before_path=out.parent/'runtime-before.json' if phase=='primary' else out/'runtime-before.json'
        result={'phase':phase,'primary_eligible':phase=='primary','context':context,'gpu_layers':layers,
            'status':'completed_pending_validation','model_sha256':self.lock['model']['sha256'],
            'source_commit':self.lock['llama_cpp']['commit'],'runtime_before_sha256':measure.sha(before_path),
            'input_binding_fingerprint':measure.binding_fingerprint(runtime),
            'input_verification_status':'PASS','runtime_binding_scope':'batch' if phase=='primary' else 'trial',
            'raw_stability':'PASS','baseline':{'host_available_bytes':5*1024**3,'gpu_used_mib':1000}}
        measure.save(out/'result.json',result)
        return result

    def make_scouts(self):
        root=self.data/'scouts'
        self.enter(patch.object(measure,'trial',self.fake_trial))
        for context in measure.CONTEXTS:
            for layers in ('all','18'):
                measure.run_scout(root/f'scout-ctx-{context}-layers-{layers}',context,layers)
        return root

    def make_protocol(self):
        scouts=self.make_scouts()
        path=self.data/'protocol.json'
        measure.freeze(path,scouts)
        return path,scouts

    def test_actual_model_hash_failure_preserves_receipt(self):
        self.model.write_bytes(b'wrong bytes')
        out=self.data/'before.json'
        with self.assertRaises(measure.BindingError):
            measure.verify_inputs(out)
        self.assertEqual(measure.read(measure.verification_path(out))['status'],'FAIL')
        self.assertFalse(out.exists())

    def test_dirty_source_is_not_a_workload_failure(self):
        self.enter(patch.object(measure,'capture',lambda path:self.capture(path,dirty=' M file')))
        out=self.data/'before.json'
        with self.assertRaises(measure.BindingError):
            measure.verify_inputs(out)
        receipt=measure.read(measure.verification_path(out))
        self.assertEqual(receipt['failure_class'],'instrumentation_invalid')

    def test_existing_verification_evidence_is_preserved(self):
        out=self.data/'before.json'
        measure.verify_inputs(out)
        digest=measure.sha(out)
        with self.assertRaises(FileExistsError):
            measure.verify_inputs(out)
        self.assertEqual(measure.sha(out),digest)

    def test_scout_post_binding_failure_is_terminal(self):
        self.enter(patch.object(measure,'trial',self.fake_trial))
        original=self.capture
        calls=[]
        def changed(path):
            calls.append(path)
            if len(calls)==2:
                self.binary.write_bytes(b'changed executable')
            original(path)
        self.enter(patch.object(measure,'capture',changed))
        out=self.data/'scout'
        with self.assertRaises(RuntimeError):
            measure.run_scout(out,2048,'all')
        self.assertEqual(measure.read(out.with_suffix('.batch.json'))['status'],'instrumentation_invalid')
        self.assertEqual(measure.read(out/'result.json')['input_verification_status'],'FAIL')

    def test_scout_raw_failure_preserves_actual_input_pass(self):
        self.enter(patch.object(measure,'trial',self.fake_trial))
        def invalid_raw(*args,**kwargs):
            raise ValueError('synthetic raw timing mismatch')
        self.validator.validate=invalid_raw
        out=self.data/'scout'
        with self.assertRaises(RuntimeError):
            measure.run_scout(out,2048,'all')
        state=measure.read(out.with_suffix('.batch.json'))
        result=measure.read(out/'result.json')
        self.assertEqual(state['status'],'instrumentation_invalid')
        self.assertEqual(state['raw_validation_status'],'FAIL')
        self.assertTrue(state['runtime_unchanged'])
        self.assertEqual(state['input_verification_status'],'PASS')
        self.assertEqual(result['input_verification_status'],'PASS')
        self.assertEqual(result['raw_validation_status'],'FAIL')
        self.assertEqual(result['status'],'failed')
        before=measure.read(measure.verification_path(out/'runtime-before.json'))
        after=measure.read(measure.verification_path(out/'runtime-after.json'))
        self.assertEqual(before['input_binding_fingerprint'],after['input_binding_fingerprint'])

    def test_freeze_rejects_raw_tampering(self):
        scouts=self.make_scouts()
        (scouts/'scout-ctx-2048-layers-all/server.log').write_text('changed evidence')
        with self.assertRaisesRegex(measure.BindingError,'raw files changed'):
            measure.freeze(self.data/'protocol.json',scouts)
        self.assertFalse((self.data/'protocol.json').exists())

    def test_freeze_cannot_exclude_instrumentation_failure(self):
        scouts=self.make_scouts()
        folder=scouts/'scout-ctx-2048-layers-all'
        result=measure.read(folder/'result.json')
        result.update(status='failed',failure_class='instrumentation_invalid')
        measure.save(folder/'result.json',result)
        with self.assertRaisesRegex(measure.BindingError,'cannot become'):
            measure.freeze(self.data/'protocol.json',scouts)

    def test_freeze_keeps_verified_workload_failure(self):
        scouts=self.make_scouts()
        folder=scouts/'scout-ctx-2048-layers-all'
        result=measure.read(folder/'result.json')
        result.update(status='failed',failure_class='workload_failure',error='Server exited during startup')
        measure.save(folder/'result.json',result)
        path=self.data/'protocol.json'
        measure.freeze(path,scouts)
        protocol=measure.check_protocol(path)
        self.assertEqual(len(protocol['order']),21)
        self.assertEqual(len(protocol['excluded']),1)

    def test_primary_lock_change_stops_before_any_trial(self):
        path,_=self.make_protocol()
        self.lock['model']['revision']='c'*40
        measure.save(self.package/'inputs.lock.json',self.lock)
        out=self.data/'primary'
        with self.assertRaises(RuntimeError):
            measure.run_primary(out,path)
        state=measure.read(out/'batch.json')
        self.assertEqual(state['status'],'instrumentation_invalid')
        self.assertEqual(state['trials'],[])
        self.assertIn('finished_utc',state)

    def test_order_hash_is_not_sufficient_for_changed_matrix(self):
        path,_=self.make_protocol()
        protocol=measure.read(path)
        protocol['order'][0]['repetition']=99
        protocol['order_sha256']=measure.json_sha(protocol['order'])
        measure.save(path,protocol)
        with self.assertRaisesRegex(measure.BindingError,'order/condition'):
            measure.check_protocol(path)

    def test_primary_post_failure_cannot_leave_exit_success_state(self):
        path,_=self.make_protocol()
        original=self.capture
        calls=[]
        def post_failure(destination):
            calls.append(destination)
            if len(calls)==2:
                raise RuntimeError('synthetic unresolved library')
            original(destination)
        self.enter(patch.object(measure,'capture',post_failure))
        out=self.data/'primary'
        with self.assertRaises(RuntimeError):
            measure.run_primary(out,path)
        state=measure.read(out/'batch.json')
        self.assertEqual(state['status'],'instrumentation_invalid')
        self.assertFalse(state['runtime_unchanged'])
        self.assertEqual(len(state['trials']),24)
        self.assertTrue(all(row['batch_invalid'] for row in state['trials']))
        for row in state['trials']:
            result=measure.read(out/row['id']/'result.json')
            self.assertFalse(result['primary_eligible'])
            self.assertEqual(result['input_verification_status'],'FAIL')
            self.assertEqual(row['result_sha256'],measure.sha(out/row['id']/'result.json'))
        self.assertEqual(measure.read(measure.verification_path(out/'runtime-after.json'))['status'],'FAIL')

    def test_primary_missing_protocol_preserves_terminal_receipt(self):
        out=self.data/'primary'
        with self.assertRaises(RuntimeError):
            measure.run_primary(out,self.data/'missing.json')
        state=measure.read(out/'batch.json')
        self.assertEqual(state['status'],'instrumentation_invalid')
        self.assertEqual(state['trials'],[])
        self.assertIn('finished_utc',state)

    def test_primary_raw_failure_keeps_binding_pass_and_invalidates_batch(self):
        path,_=self.make_protocol()
        def invalid_final(*args,**kwargs):
            if kwargs.get('allow_pending_batch_post'):
                return {'status':'trial_checks_passed_batch_post_pending','metrics':{'control':True}}
            raise ValueError('synthetic final raw timing mismatch')
        self.validator.validate=invalid_final
        out=self.data/'primary'
        with self.assertRaises(RuntimeError):
            measure.run_primary(out,path)
        state=measure.read(out/'batch.json')
        self.assertEqual(state['status'],'instrumentation_invalid')
        self.assertEqual(state['input_verification_status'],'PASS')
        self.assertEqual(state['raw_validation_status'],'FAIL')
        self.assertTrue(state['runtime_unchanged'])
        self.assertEqual(len(state['trials']),24)
        for row in state['trials']:
            self.assertTrue(row['batch_invalid'])
            result=measure.read(out/row['id']/'result.json')
            self.assertFalse(result['primary_eligible'])
            self.assertEqual(result['input_verification_status'],'PASS')
            self.assertFalse(result['batch_post_pending'])
            self.assertEqual(result['runtime_after_sha256'],measure.sha(out/'runtime-after.json'))

    def test_primary_provisional_failure_cannot_be_rescued_by_final_validation(self):
        path,_=self.make_protocol()
        def invalid_provisional(*args,**kwargs):
            if kwargs.get('allow_pending_batch_post'):
                raise ValueError('synthetic provisional raw mismatch')
            return {'status':'raw_checks_passed','metrics':{'control':True}}
        self.validator.validate=invalid_provisional
        out=self.data/'primary'
        with self.assertRaises(RuntimeError):
            measure.run_primary(out,path)
        state=measure.read(out/'batch.json')
        self.assertEqual(state['status'],'instrumentation_invalid')
        self.assertEqual(state['input_verification_status'],'PASS')
        self.assertEqual(state['raw_validation_status'],'FAIL')
        self.assertEqual(len(state['trials']),1)
        self.assertEqual(state['trials'][0]['prevalidation_status'],'FAIL')
        self.assertTrue(state['trials'][0]['batch_invalid'])

    def test_primary_changed_closure_is_input_failure_not_raw_failure(self):
        path,_=self.make_protocol()
        original=self.capture
        calls=[]
        def changed(destination):
            calls.append(destination)
            if len(calls)==2:
                self.binary.write_bytes(b'changed runtime executable')
            original(destination)
        self.enter(patch.object(measure,'capture',changed))
        out=self.data/'primary'
        with self.assertRaises(RuntimeError):
            measure.run_primary(out,path)
        state=measure.read(out/'batch.json')
        self.assertEqual(state['input_verification_status'],'FAIL')
        self.assertFalse(state['runtime_unchanged'])
        self.assertEqual(state['raw_validation_status'],'NOT_RUN')
        self.assertTrue(all(row['batch_invalid'] for row in state['trials']))

    def test_primary_final_validation_and_reexecution_preservation(self):
        path,_=self.make_protocol()
        out=self.data/'primary'
        state=measure.run_primary(out,path)
        self.assertEqual(state['status'],'all_retained_primary_trials_validated')
        self.assertTrue(state['runtime_unchanged'])
        self.assertTrue(all(row['status']=='validated' for row in state['trials']))
        self.assertEqual(len(list(out.glob('*.prevalidation.json'))),24)
        self.assertEqual(len(list(out.glob('*.validation.json'))),24)
        digest=measure.sha(out/'batch.json')
        with self.assertRaises(FileExistsError):
            measure.run_primary(out,path)
        self.assertEqual(measure.sha(out/'batch.json'),digest)

    def test_failure_classes_are_separate(self):
        self.assertEqual(measure.classify_failure(TimeoutError('request')),'resource_or_budget_stop')
        self.assertEqual(measure.classify_failure(RuntimeError('Server exited during startup'),'startup'),'workload_failure')
        self.assertEqual(measure.classify_failure(ValueError('wrong output count'),'request'),'instrumentation_invalid')

    def reader_runtime(self):
        server=self.data/'reproduction-20261007/build/bin/llama-server'
        server.parent.mkdir(parents=True)
        server.write_bytes(b'fresh isolated executable control')
        runtime={'files':{str(server):{'resolved':str(server),'bytes':server.stat().st_size,
                                    'sha256':measure.sha(server)}}}
        return server,runtime

    def test_reader_override_binds_actual_isolated_binary(self):
        server,runtime=self.reader_runtime()
        self.assertEqual(measure.select_server('reader',2048,'all',server,runtime),server.resolve())

    def test_reader_override_cannot_change_primary_or_condition(self):
        server,runtime=self.reader_runtime()
        for phase,context,layers in (('primary',2048,'all'),('scout',2048,'all'),
                                     ('reader',4096,'all'),('reader',2048,'18')):
            with self.subTest(phase=phase,context=context,layers=layers):
                with self.assertRaises(measure.BindingError):
                    measure.select_server(phase,context,layers,server,runtime)

    def test_reader_cannot_use_original_or_changed_binary(self):
        server,runtime=self.reader_runtime()
        with self.assertRaises(measure.BindingError):
            measure.select_server('reader',2048,'all',self.binary,runtime)
        with self.assertRaises(measure.BindingError):
            measure.select_server('reader',2048,'all',None,runtime)
        server.write_bytes(b'changed')
        with self.assertRaisesRegex(measure.BindingError,'differs'):
            measure.select_server('reader',2048,'all',server,runtime)


if __name__=='__main__':
    unittest.main()
