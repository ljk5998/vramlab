#!/usr/bin/env python3
"""Hash the actual binary, resolved libraries, source state and CUDA settings."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

PACKAGE = Path(__file__).resolve().parents[1]
DATA = PACKAGE / "data/rtx"


def capture(destination):
    if os.environ.get("WSL_DISTRO_NAME") != "VRAMLab-RTX-Context":
        raise RuntimeError("Wrong guest")
    if destination.exists():
        raise FileExistsError(destination)
    env = dict(os.environ, LD_LIBRARY_PATH="/usr/local/cuda-13.2/lib64:/usr/lib/wsl/lib")

    def run(argv):
        return subprocess.check_output(argv, text=True, stderr=subprocess.STDOUT, env=env)

    source = DATA / "llama.cpp"
    actual = run(["git", "-C", str(source), "rev-parse", "HEAD"]).strip()
    dirty = run(["git", "-C", str(source), "-c", "core.filemode=false", "status", "--porcelain"])
    lock = json.loads((PACKAGE / "inputs.lock.json").read_text())
    if actual != lock["llama_cpp"]["commit"] or dirty:
        raise ValueError("Source changed")
    paths = {DATA / "build/bin/llama-server", DATA / "build/CMakeCache.txt"}
    paths.update((DATA / "build/bin").glob("*.so*"))
    library_outputs = {}
    for name in ("llama-server", "libggml-cuda.so"):
        result = run(["ldd", str(DATA / "build/bin" / name)])
        if "not found" in result:
            raise RuntimeError("Unresolved runtime library")
        library_outputs[name] = result
        for line in result.splitlines():
            match = re.search(r"=> (/.+?) \(", line) or re.search(r"^\s*(/.+?) \(", line)
            if match:
                paths.add(Path(match[1]))
    hashes = {}
    for path in sorted(paths):
        resolved = path.resolve()
        with resolved.open("rb") as source_file:
            hashes[str(path)] = {"resolved": str(resolved), "bytes": resolved.stat().st_size,
                                 "sha256": hashlib.file_digest(source_file, "sha256").hexdigest()}
    result = {"time": time.time(), "source_commit": actual, "source_status": dirty,
              "files": hashes, "ldd": library_outputs,
              "gpu": run(["/usr/lib/wsl/lib/nvidia-smi"]),
              "devices": run([str(DATA / "build/bin/llama-server"), "--list-devices"])}
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(result, indent=2) + "\n")
    print(f"Verified source and hashed {len(hashes)} binary/library/cache paths")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("destination", type=Path)
    capture(parser.parse_args().destination)
