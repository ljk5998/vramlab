#!/usr/bin/env python3
"""Independent RTX full-trial audit. Reads files only; never runs a backend.

The negative-control tests use SYNTHETIC evidence, not GPU observations.
Primary prevalidation may defer the batch post-binding only when explicitly
requested. Such a receipt cannot stand in for the strict final validation.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import re
import statistics


CONTEXTS = (2048, 4096, 8192, 16384)
LAYERS = ("all", "18")
SCRIPT_NAMES = {"rtx_measure.py", "validate_rtx_trial.py", "guard_rtx.py", "prepare_rtx.py", "snapshot_rtx_runtime.py", "check_package.py"}
FIXTURE_NAMES = {"rtx-notebook.txt", "rtx-tokenizer.json", *(f"rtx-tokens-{capacity}.json" for capacity in CONTEXTS)}
QWEN3_BLOCKS = 36
QWEN3_KV_HEADS = 8
QWEN3_HEAD_K = 128
QWEN3_HEAD_V = 128
F16_BYTES = 2
COMMON_FLAGS = [
    "--fit", "off", "--parallel", "1", "--cache-type-k", "f16",
    "--cache-type-v", "f16", "--flash-attn", "on", "--batch-size", "512",
    "--ubatch-size", "128", "--threads", "4", "--threads-batch", "4",
    "--no-cache-prompt", "--cache-ram", "0", "--no-cache-idle-slots",
    "--no-context-shift", "--perf", "--warmup", "--offline", "--host", "127.0.0.1",
    "--load-mode", "none", "--lazy-mode", "off", "--verbosity", "4",
    "--cors-origins", "http://127.0.0.1", "--ctx-checkpoints", "0",
]
REQUIRED_RAW = {
    "command.json", "request.json", "environment.json", "server.log",
    "response.sse", "events.jsonl", "request-clock.json", "post-health.json",
    "memory.jsonl", "gpu-process-accounting.json",
}
SHA256_RE = re.compile(r"[0-9a-f]{64}\Z")


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def canonical_hash(value):
    data = json.dumps(value, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def number(value, name, minimum=0):
    require(type(value) in (int, float) and math.isfinite(value), name + " is not a finite number")
    require(value >= minimum, name + " is below its minimum")
    return value


def raw_number(value, name):
    try:
        converted = float(value)
    except (TypeError, ValueError) as error:
        raise ValueError(name + " is unavailable or malformed") from error
    require(math.isfinite(converted) and converted >= 0, name + " is not finite/nonnegative")
    return converted


def hash_map(value, name):
    require(isinstance(value, dict) and value, name + " is missing")
    for key, expected in value.items():
        require(isinstance(key, str) and isinstance(expected, str) and SHA256_RE.fullmatch(expected),
                name + " contains an invalid digest")


def checked_file(root, name):
    require(isinstance(name, str) and name and Path(name).name == name, "Unsafe evidence filename")
    path = root / name
    require(path.is_file() and not path.is_symlink(), "Missing/linked raw evidence: " + name)
    return path


def binding_maps_checks(value, package):
    require(set(value["scripts_sha256"]) == SCRIPT_NAMES, "Executable/validator script binding coverage mismatch")
    fixtures = {p.name for p in (package / "fixtures").glob("rtx-*") if p.is_file()}
    require(FIXTURE_NAMES.issubset(fixtures) and set(value["fixtures_sha256"]) == fixtures,
            "Fixture binding coverage mismatch")
    for folder, field in (("scripts", "scripts_sha256"), ("fixtures", "fixtures_sha256")):
        hash_map(value[field], field)
        for name, expected in value[field].items():
            require(digest(checked_file(package / folder, name)) == expected, "Current bound " + folder + " changed: " + name)


def assert_flags(argv, context, layers, model_filename):
    require(isinstance(argv, list) and all(isinstance(v, str) for v in argv), "Invalid command vector")
    # Remove the executable and four condition/path arguments; compare the exact
    # ordered remaining flags to an independently declared contract.
    remaining = argv[1:]
    dynamic = {"--model": None, "--ctx-size": str(context), "--gpu-layers": layers, "--port": None}
    for flag, expected in dynamic.items():
        require(remaining.count(flag) == 1, "Missing/duplicate argument: " + flag)
        index = remaining.index(flag)
        require(index + 1 < len(remaining), "Missing argument value: " + flag)
        actual = remaining[index + 1]
        if expected is not None:
            require(actual == expected, "Server setting mismatch: " + flag)
        else:
            require(actual != "", "Empty argument value: " + flag)
        if flag == "--port":
            require(actual.isdecimal() and 1 <= int(actual) <= 65535, "Invalid loopback port")
        if flag == "--model":
            model = PurePosixPath(actual)
            require(model.is_absolute() and ".." not in model.parts and model.parts[-4:] == ("data", "rtx", "models", model_filename),
                    "Executed model path differs from locked RTX model")
        remaining = remaining[:index] + remaining[index + 2:]
    require(remaining == COMMON_FLAGS, "Common flags differ from frozen measurement contract")


def expected_kv_allocation(context, layers):
    """Locked Qwen3 geometry + pinned source placement, never observed sizes.

    e5a8d439 llama-model.cpp:1494 uses start=max(blocks+1-ngl,0),
    :1514 assigns repeating indices 0..35 and :1519 assigns output36.
    llama-kv-cache.cpp:165,217,233-234 create K/V only for repeating
    blocks and follow model.dev_layer. Thus ngl18 is 17 CUDA/19 CPU
    KV blocks; its CUDA output consumes one offload slot and has no KV.
    Do not infer the repeating count from the human offload summary line.
    """
    gpu_layers = QWEN3_BLOCKS + 1 if layers == "all" else int(layers)
    gpu_start = max(QWEN3_BLOCKS + 1 - gpu_layers, 0)
    gpu_blocks = max(QWEN3_BLOCKS - gpu_start, 0)
    cpu_blocks = QWEN3_BLOCKS - gpu_blocks
    per_block = context * QWEN3_KV_HEADS * (QWEN3_HEAD_K + QWEN3_HEAD_V) * F16_BYTES / 1024**2
    return {"cuda_mib": gpu_blocks * per_block, "cpu_mib": cpu_blocks * per_block,
            "cuda_repeating_blocks": gpu_blocks, "cpu_repeating_blocks": cpu_blocks}


def log_checks(log, context, layers):
    offload = 37 if layers == "all" else 18
    matches = re.findall(r"offloaded\s+(\d+)/(\d+)\s+layers to GPU", log)
    require(matches and all(tuple(map(int, m)) == (offload, 37) for m in matches), "Incorrect GPU offload")
    contexts = re.findall(r"n_ctx_seq\s*=\s*(\d+)\b", log)
    require(contexts and all(int(v) == context for v in contexts), "Effective context mismatch")
    flash = re.findall(r"flash_attn\s*=\s*(\w+)", log)
    require(flash and all(v == "enabled" for v in flash), "Flash Attention not enabled")
    require("context checkpoints enabled" not in log, "Checkpoint unexpectedly enabled")
    require("fitting params to device memory" not in log, "Automatic fitting was unexpectedly active")
    if layers == "all":
        require(not re.search(r"layer \d+ is assigned to device CUDA\d+ but the Flash Attention tensor is assigned to device CPU", log),
                "Unexpected attention CPU fallback")
    kv_types = re.findall(r"\b([KV]) \(([^)]+)\)", log)
    require({kind for kind, _ in kv_types} == {"K", "V"} and all(value == "f16" for _, value in kv_types),
            "Effective F16 KV types missing/mixed")
    buffers = []
    for backend, kind, amount in re.findall(
            r"\b(CUDA0|CUDA_Host|CPU|CPU_Mapped)\s+(model|KV|compute|output) buffer size\s*=\s*([\d.]+) MiB", log):
        row = {"backend": backend, "kind": kind, "mib": raw_number(amount, "buffer size")}
        if row not in buffers:
            buffers.append(row)
    require(any(b["backend"] == "CUDA0" and b["kind"] == "model" and b["mib"] > 0 for b in buffers),
            "CUDA weights missing")
    if layers == "18":
        require(any(b["backend"] in ("CPU", "CPU_Mapped", "CUDA_Host") and b["kind"] == "model" and b["mib"] > 0 for b in buffers),
                "CPU weights missing for partial offload")
    expected = expected_kv_allocation(context, layers)
    gpu_kv = [b["mib"] for b in buffers if b["backend"] == "CUDA0" and b["kind"] == "KV"]
    require(gpu_kv == [expected["cuda_mib"]], "CUDA KV allocation mismatch")
    host_kv = [b["mib"] for b in buffers if b["backend"] in ("CPU", "CUDA_Host", "CPU_Mapped") and b["kind"] == "KV"]
    if layers == "18":
        require(host_kv == [expected["cpu_mib"]], "CPU KV allocation mismatch")
    else:
        require(not host_kv or all(value == 0 for value in host_kv), "Unexpected host KV for all layers")
    return offload, buffers


def sse_checks(out, result, context):
    raw = []
    for line in (out / "response.sse").read_bytes().splitlines():
        if line.startswith(b"data:") and line[5:].strip() != b"[DONE]":
            raw.append(json.loads(line[5:]))
    events = [json.loads(line) for line in (out / "events.jsonl").read_text().splitlines()]
    require(raw and all(isinstance(e, dict) for e in raw), "Malformed/missing SSE")
    require(raw == [e["event"] for e in events], "Raw SSE differs from timestamped events")
    finals = [e for e in raw if e.get("stop") is True]
    require(len(finals) == 1 and raw[-1] == finals[0], "Missing/duplicate/nonterminal final event")
    final = finals[0]
    require(final == result["completion"]["final"], "Reported final differs from raw")
    require(type(final["tokens_evaluated"]) is int and final["tokens_evaluated"] == context - 256, "Evaluated input mismatch")
    require(type(final["tokens_predicted"]) is int and final["tokens_predicted"] == 128, "Output count mismatch")
    require(all(isinstance(e.get("tokens", []), list) and all(type(t) is int and t >= 0 for t in e.get("tokens", [])) for e in raw),
            "Malformed returned token list")
    require(sum(len(e.get("tokens", [])) for e in raw) == 128, "Stream tokens mismatch")
    require(final["truncated"] is False and final["stop_type"] == "limit", "Unexpected completion boundary")
    timings = final["timings"]
    require(timings["cache_n"] == 0 and timings["prompt_n"] == context - 256 and timings["predicted_n"] == 128,
            "Timing token counts mismatch")
    for name in ("prompt_ms", "predicted_ms", "predicted_per_second"):
        number(timings[name], "timing " + name, minimum=1e-12)
    # Pinned server-common.h:409-427 counts n_gen-1 decode steps: the
    # first generated token comes from the last prompt batch's logits.
    # server-common.cpp:77-79 still exposes predicted_n as all128 tokens.
    decode_steps = timings["predicted_n"] - 1
    require(math.isclose(timings["predicted_per_second"], decode_steps * 1000 / timings["predicted_ms"], rel_tol=0.001, abs_tol=0.001),
            "Decode timing/throughput arithmetic mismatch")
    stamps = [number(e["received_monotonic"], "SSE timestamp") for e in events]
    require(stamps == sorted(stamps), "Nonmonotonic events")
    start = number(read(out / "request-clock.json")["monotonic"], "Request start")
    contents = [e for e in events if isinstance(e["event"].get("content"), str) and e["event"]["content"]]
    require(contents, "No generated content")
    first = contents[0]["received_monotonic"]
    ttft, complete = first - start, stamps[-1] - start
    require(0 < ttft <= 120 and ttft <= complete <= 180, "Request exceeded budgets")
    completion = result["completion"]
    for name, actual in (("request_start_monotonic", start), ("first_content_monotonic", first),
                         ("final_monotonic", stamps[-1]), ("ttft_s", ttft), ("completion_s", complete)):
        require(abs(number(completion[name], name) - actual) < 1e-8, "Request clock/latency arithmetic mismatch: " + name)
    return timings, ttft, complete, start, stamps[-1]


def telemetry_checks(out, result, request_start, request_end):
    samples = [json.loads(line) for line in (out / "memory.jsonl").read_text().splitlines()]
    require(samples, "No memory samples")
    phases = {"baseline", "startup", "request", "shutdown", "recovery"}
    unique_host = []
    for sample in samples:
        require(sample["phase"] in phases, "Unknown telemetry phase")
        mono = number(sample["monotonic"], "Memory timestamp")
        epoch = number(sample["epoch"], "Memory epoch")
        number(sample["sample_duration_s"], "Sample duration")
        host = sample["host"]
        require(host["abort"] is None, "Host guard aborted")
        require(abs(epoch - number(host["time"], "Host sample timestamp")) <= 8, "Stale host telemetry")
        if unique_host:
            previous = unique_host[-1]
            require(host["time"] >= previous["time"], "Host heartbeat time regressed")
            if host["time"] == previous["time"]:
                require(host == previous, "Same host heartbeat timestamp has conflicting observations")
            else:
                unique_host.append(host)
        else:
            unique_host.append(host)
        require(number(host["available_ram_bytes"], "Host available RAM") >= 2 * 1024**3, "Host RAM safety cutoff violated")
        require(number(host["disk_free_bytes"], "Work disk free") >= 5 * 1024**3, "Work disk safety cutoff violated")
        gpu = host["gpu"]
        total = raw_number(gpu["total_mib"], "Global VRAM total")
        used = raw_number(gpu["used_mib"], "Global VRAM used")
        require(0 < total and used <= total, "Global GPU memory accounting impossible")
        require(raw_number(gpu["utilization_percent"], "GPU utilization") <= 100, "GPU utilization outside range")
        for name in ("temperature_c", "sm_mhz", "power_w"):
            raw_number(gpu[name], "GPU " + name)
        require(isinstance(gpu["pstate"], str) and re.fullmatch(r"P\d+", gpu["pstate"]), "Malformed GPU pstate")
        gpu_raw = host["gpu_raw"].strip().split(", ")
        require(len(gpu_raw) == 7 and gpu_raw == [str(gpu[k]) for k in
                ("total_mib", "used_mib", "temperature_c", "utilization_percent", "sm_mhz", "power_w", "pstate")],
                "Raw GPU telemetry differs from parsed fields")
        mem = {k: int(v) * 1024 for k, v in re.findall(r"^(\w+):\s+(\d+) kB", sample["meminfo_raw"], re.M)}
        require(mem["MemAvailable"] == sample["guest_available_bytes"], "Raw guest available RAM mismatch")
        require(mem["SwapTotal"] - mem["SwapFree"] == sample["guest_swap_used_bytes"], "Raw guest swap mismatch")
        number(sample["guest_available_bytes"], "Guest available RAM")
        number(sample["guest_swap_used_bytes"], "Guest swap use")
        status = sample["process_status_raw"]
        if sample["process_rss_bytes"] is not None:
            require(isinstance(status, str), "Missing raw process RSS status")
            observed = {k: int(v) * 1024 for k, v in re.findall(r"^(VmRSS|VmHWM):\s+(\d+) kB", status, re.M)}
            require(observed.get("VmRSS") == sample["process_rss_bytes"] and observed.get("VmHWM") == sample["process_hwm_bytes"],
                    "Raw process RSS/HWM mismatch")
            pid = re.search(r"^Pid:\s*(\d+)$", status, re.M)
            require(pid and int(pid.group(1)) == result["server_pid"], "Process RSS PID mismatch")
            require(sample["process_hwm_bytes"] >= sample["process_rss_bytes"] >= 0, "Process RSS/HWM impossible")
        else:
            require(sample["process_hwm_bytes"] is None, "Process memory availability inconsistent")
            if status is not None:
                require(isinstance(status, str), "Process memory availability inconsistent")
                pid = re.search(r"^Pid:\s*(\d+)$", status, re.M)
                state = re.search(r"^State:\s*([A-Z])\b", status, re.M)
                # /proc/PID/status remains readable briefly after exit, while
                # zombies/dead tasks legitimately have no VmRSS/VmHWM. This
                # observation is unavailable memory, never a zero reading.
                require(pid and int(pid.group(1)) == result["server_pid"] and state and state.group(1) in ("Z", "X") and
                        not re.search(r"^(VmRSS|VmHWM):", status, re.M), "Process memory availability inconsistent")
    gaps = [b["monotonic"] - a["monotonic"] for a, b in zip(samples, samples[1:])]
    require(gaps and all(0 < gap <= 3 for gap in gaps), "Telemetry cadence/gap exceeds contract")
    gpu_gaps = [b["time"] - a["time"] for a, b in zip(unique_host, unique_host[1:])]
    require(gpu_gaps and max(gpu_gaps) <= 8, "Effective GPU heartbeat gap exceeds freshness contract")
    baseline = [s for s in samples if s["phase"] == "baseline"]
    active = [s for s in samples if s["phase"] in ("startup", "request", "shutdown")]
    recovery = [s for s in samples if s["phase"] == "recovery"]
    request = [s for s in samples if s["phase"] == "request"]
    require(len(baseline) >= 25 and len(recovery) >= 25 and active and request and
            any(s["phase"] == "startup" for s in samples), "Telemetry phase coverage missing")
    order = {name: index for index, name in enumerate(("baseline", "startup", "request", "shutdown", "recovery"))}
    require([order[s["phase"]] for s in samples] == sorted(order[s["phase"]] for s in samples), "Telemetry phases regress")
    require(baseline[-1]["monotonic"] < request_start and recovery[0]["monotonic"] >= request_end,
            "Baseline/recovery overlap measured request")
    rss = [s["process_rss_bytes"] for s in active if s["process_rss_bytes"] is not None]
    hwm = [s["process_hwm_bytes"] for s in active if s["process_hwm_bytes"] is not None]
    require(rss, "No process RSS observations")
    ram = [s["host"]["available_ram_bytes"] for s in baseline]
    vram = [float(s["host"]["gpu"]["used_mib"]) for s in baseline]
    require(max(ram) - min(ram) <= 512 * 1024**2 and max(vram) - min(vram) <= 128, "Baseline unstable")
    require(statistics.median(float(s["host"]["gpu"]["utilization_percent"]) for s in baseline) <= 10, "Baseline GPU busy")
    base_ram, base_vram = statistics.median(ram), statistics.median(vram)
    require(result["baseline"] == {"host_available_bytes": base_ram, "gpu_used_mib": base_vram}, "Baseline summary mismatch")
    startup = number(result["startup_s"], "Startup duration", minimum=1e-12)
    require(startup <= 120, "Startup exceeded budget")
    startup_start = number(result["startup_start_monotonic"], "Startup start")
    require(startup_start >= baseline[-1]["monotonic"] and request_start >= startup_start + startup - 1e-6,
            "Startup/request clock ordering mismatch")
    require(read(out / "post-health.json") == {"status": "ok"}, "Post-request health failed")
    accounting = read(out / "gpu-process-accounting.json")
    require(type(accounting["exit_code"]) is int and isinstance(accounting["stdout"], str) and
            isinstance(accounting["stderr"], str) and isinstance(accounting["scope"], str), "Missing process accounting observation")
    peak = max(float(s["host"]["gpu"]["used_mib"]) for s in active)
    return {
        "global_vram_baseline_mib": base_vram,
        "global_vram_sampled_peak_mib": peak,
        "global_vram_peak_minus_baseline_mib": peak - base_vram,
        "global_vram_scope": "Device-wide WDDM observation; baseline difference is not process VRAM",
        "process_gpu_memory_scope": "One startup NVML query only; N/A/unmatched PID remains unavailable; no process GPU peak",
        "process_rss_sampled_peak_bytes": max(rss), "process_hwm_sampled_peak_bytes": max(hwm) if hwm else None,
        "host_available_baseline_bytes": base_ram,
        "host_available_min_bytes": min(s["host"]["available_ram_bytes"] for s in active),
        "guest_available_min_bytes": min(s["guest_available_bytes"] for s in active),
        "guest_swap_baseline_bytes": statistics.median(s["guest_swap_used_bytes"] for s in baseline),
        "guest_swap_peak_bytes": max(s["guest_swap_used_bytes"] for s in active),
        "temperature_peak_c": max(float(s["host"]["gpu"]["temperature_c"]) for s in active),
        "telemetry_samples": len(samples), "max_sample_gap_s": max(gaps),
        "unique_host_heartbeat_queries": len(unique_host), "max_effective_gpu_gap_s": max(gpu_gaps),
        "gpu_sampling_scope": "Repeated reads of one host heartbeat are one GPU observation; sampled peak can miss shorter spikes",
    }


def cross_trial_baseline_checks(out, protocol, metrics):
    """Recompute first-trial reference from raw samples, never its summary alone."""
    order = protocol["order"]
    require(isinstance(order, list) and order, "Frozen trial order missing")
    first_id = order[0]["id"]
    require(isinstance(first_id, str) and first_id and Path(first_id).name == first_id, "Unsafe first trial identifier")
    first = out.parent / first_id
    if first == out:
        reference_ram = metrics["host_available_baseline_bytes"]
        reference_vram = metrics["global_vram_baseline_mib"]
    else:
        result = read(first / "result.json")
        require(result["status"] == "completed_pending_validation" and result["phase"] == "primary" and
                result["protocol_sha256"] == read(out / "result.json")["protocol_sha256"], "First primary trial is not a valid baseline reference")
        # Independently audit its raw request clocks and telemetry, rather than
        # trusting result.baseline even if that JSON has a fresh hash.
        _, _, _, start, end = sse_checks(first, result, result["context"])
        first_metrics = telemetry_checks(first, result, start, end)
        require(result["files_sha256"].get("memory.jsonl") == digest(first / "memory.jsonl"), "First primary raw baseline hash mismatch")
        reference_ram = first_metrics["host_available_baseline_bytes"]
        reference_vram = first_metrics["global_vram_baseline_mib"]
    ram_delta = metrics["host_available_baseline_bytes"] - reference_ram
    vram_delta = metrics["global_vram_baseline_mib"] - reference_vram
    require(abs(ram_delta) <= 1024**3 and abs(vram_delta) <= 256, "Cross-trial baseline drift exceeds contract")
    metrics.update(first_primary_baseline_trial=first_id, baseline_ram_difference_from_first_bytes=ram_delta,
                   baseline_vram_difference_from_first_mib=vram_delta)


def snapshot_checks(path, package, lock, protocol=None):
    runtime = read(path)
    require(runtime["source_commit"] == lock["llama_cpp"]["commit"] and runtime["source_status"] == "", "Runtime source binding mismatch")
    files = runtime["files"]
    require(isinstance(files, dict) and files, "Runtime closure missing")
    require(any(k.endswith("/llama-server") for k in files) and any(k.endswith("/libggml-cuda.so") for k in files),
            "Runtime closure lacks executable/CUDA implementation")
    for name, record in files.items():
        require(isinstance(name, str) and isinstance(record["resolved"], str), "Malformed resolved runtime path")
        require(type(record["bytes"]) is int and record["bytes"] > 0 and SHA256_RE.fullmatch(record["sha256"]), "Malformed runtime file binding")
    binding = runtime["input_verification"]
    require(binding["status"] == "PASS", "Input verification did not pass")
    require(binding["inputs_lock_sha256"] == digest(package / "inputs.lock.json"), "Input lock binding mismatch")
    require(binding["model"] == {key: lock["model"][key] for key in ("filename", "bytes", "sha256", "revision")}, "Model binding mismatch")
    binding_maps_checks(binding, package)
    require(binding["flags_sha256"] == canonical_hash(COMMON_FLAGS), "Bound flags changed")
    identity = {key: runtime[key] for key in ("source_commit", "source_status", "files", "input_verification")}
    fingerprint = canonical_hash(identity)
    sidecar = read(path.with_name(path.name + ".verification.json"))
    require(sidecar["status"] == "PASS" and sidecar["runtime_sha256"] == digest(path) and
            sidecar["input_binding_fingerprint"] == fingerprint, "Runtime verification sidecar mismatch")
    if protocol is not None:
        reference = protocol["runtime_reference"]
        require(files == reference["files"], "Frozen runtime closure changed")
        require(canonical_hash({key: reference[key] for key in ("source_commit", "source_status", "files", "input_verification")}) == fingerprint,
                "Frozen input/runtime identity changed")
    return runtime, fingerprint


def validate(out, protocol_path=None, package_root=None, allow_pending_batch_post=False):
    out = Path(out)
    package = Path(package_root) if package_root is not None else Path(__file__).resolve().parents[1]
    result = read(out / "result.json")
    lock = read(package / "inputs.lock.json")
    context, layers = result["context"], result["gpu_layers"]
    require(type(context) is int and context in CONTEXTS and layers in LAYERS, "Unknown condition")
    require(result["status"] == "completed_pending_validation", "Incomplete trial")
    require(type(result["exit_code"]) is int and result["exit_code"] == 0 and not result.get("shutdown_escalated"), "Unclean server exit")
    require(result["collector_error"] is None and result.get("failure_class") is None, "Collector/failure classification is not clean")
    require(result.get("raw_stability") == "PASS", "Raw writers did not establish stable closure")
    require(type(result["server_pid"]) is int and result["server_pid"] > 0, "Invalid server PID")
    require(result["phase"] in ("scout", "primary", "reader"), "Invalid phase")
    require(result["primary_eligible"] is (result["phase"] == "primary"), "Primary classification mismatch")
    if result["phase"] == "reader":
        require(context == 2048 and layers == "all", "Reader replay requires 2K/all")
    require(result["source_commit"] == lock["llama_cpp"]["commit"] and result["model_sha256"] == lock["model"]["sha256"], "Result input lock mismatch")
    require(result["binary_before_sha256"] == result["binary_after_sha256"], "Binary changed")
    for name in REQUIRED_RAW:
        checked_file(out, name)
    request = read(out / "request.json")
    fixture = package / f"fixtures/rtx-tokens-{context}.json"
    tokens = read(fixture)
    require(request["prompt"] == tokens and len(tokens) == context - 256 and all(type(t) is int and t >= 0 for t in tokens), "Input fixture/count/type mismatch")
    for key, expected in {"stream": True, "cache_prompt": False, "n_predict": 128, "temperature": 0,
                          "seed": 20260910, "ignore_eos": True, "return_tokens": True}.items():
        require(key in request and request[key] == expected and type(request[key]) is type(expected), "Request setting mismatch: " + key)
    argv = read(out / "command.json")
    assert_flags(argv, context, layers, lock["model"]["filename"])
    server_path = result["server_path"]
    require(isinstance(server_path, str) and argv[0] == server_path, "Declared server path differs from executed argv")
    if result["phase"] == "reader":
        server = PurePosixPath(server_path)
        require(server.is_absolute() and ".." not in server.parts and server.parts[-3:] == ("build", "bin", "llama-server") and
                len(server.parts) >= 6 and server.parts[-6:-4] == ("data", "rtx") and server.parts[-4].startswith("reproduction-") and
                len(server.parts[-4]) > len("reproduction-"), "Reader server is not a fresh reproduction build path")
    environment = read(out / "environment.json")
    require(environment["CUDA_VISIBLE_DEVICES"] == "0" and environment["GGML_CUDA_ENABLE_UNIFIED_MEMORY"] is None,
            "Unexpected CUDA environment")
    require(environment.get("LD_LIBRARY_PATH") == "/usr/local/cuda-13.2/lib64:/usr/lib/wsl/lib" and
            environment.get("OMP_NUM_THREADS") == "4", "Loader/thread environment differs from measurement contract")
    offload, buffers = log_checks((out / "server.log").read_text(errors="replace"), context, layers)
    timings, ttft, complete, request_start, request_end = sse_checks(out, result, context)
    metrics = telemetry_checks(out, result, request_start, request_end)
    metrics.update(ttft_s=ttft, completion_s=complete, startup_s=result["startup_s"], prompt_ms=timings["prompt_ms"],
                   decode_ms=timings["predicted_ms"], decode_tokens_s=timings["predicted_per_second"], buffers=buffers)
    protocol = read(protocol_path) if protocol_path is not None else None
    if result["phase"] == "primary":
        require(protocol is not None, "Primary requires frozen protocol")
    if protocol is not None:
        require(protocol["status"] == "frozen_before_primary", "Protocol is not frozen")
        require(result["protocol_sha256"] == digest(protocol_path), "Protocol hash mismatch")
        require([context, layers] in protocol["retained"], "Condition not retained")
        require(protocol["inputs_lock_sha256"] == digest(package / "inputs.lock.json"), "Frozen input lock changed")
        require(protocol["flags"] == COMMON_FLAGS, "Frozen common flags mismatch")
        for field, expected in (("startup_budget_seconds", 120), ("first_content_budget_seconds", 120), ("request_budget_seconds", 180),
                                ("baseline_seconds", 30), ("recovery_seconds", 30), ("sample_cadence_seconds", 1),
                                ("baseline_vram_range_mib", 128), ("baseline_host_ram_range_mib", 512),
                                ("baseline_gpu_util_median_max", 10), ("cross_trial_vram_drift_mib", 256),
                                ("cross_trial_host_ram_drift_mib", 1024)):
            require(protocol[field] == expected, "Frozen bound mismatch: " + field)
        for folder, field in (("scripts", "scripts_sha256"), ("fixtures", "fixtures_sha256")):
            hash_map(protocol[field], field)
            for name, expected in protocol[field].items():
                require(digest(checked_file(package / folder, name)) == expected, "Frozen " + folder + " changed: " + name)
        binding_maps_checks(protocol, package)
        if result["phase"] == "primary":
            matches = [item for item in protocol["order"] if item["id"] == out.name]
            require(len(matches) == 1 and matches[0]["context"] == context and matches[0]["gpu_layers"] == layers, "Trial not in frozen order")
            cross_trial_baseline_checks(out, protocol, metrics)
    scope = result["runtime_binding_scope"]
    require(scope == ("batch" if result["phase"] == "primary" else "trial"), "Runtime binding scope mismatch")
    runtime_root = out.parent if scope == "batch" else out
    before_path, after_path = runtime_root / "runtime-before.json", runtime_root / "runtime-after.json"
    before, fingerprint = snapshot_checks(before_path, package, lock, protocol)
    require(result["runtime_before_sha256"] == digest(before_path) and result["input_binding_fingerprint"] == fingerprint and
            result["input_verification_status"] == "PASS", "Result runtime/input binding mismatch")
    require(server_path in before["files"] and before["files"][server_path]["sha256"] == result["binary_before_sha256"], "Executed binary not runtime-bound")
    pending = not after_path.is_file()
    require(result.get("batch_post_pending") is pending, "Batch post-binding pending state mismatch")
    if pending:
        require(scope == "batch" and allow_pending_batch_post, "Post-runtime binding missing")
        require(result.get("runtime_after_sha256") is None, "Pending batch unexpectedly claims a post-runtime hash")
    else:
        after, after_fingerprint = snapshot_checks(after_path, package, lock, protocol)
        require(after_fingerprint == fingerprint and before["files"] == after["files"], "Runtime/input closure changed during execution")
        require(result["runtime_after_sha256"] == digest(after_path), "Result post-runtime hash mismatch")
    # File integrity is checked after semantic validation. The negative controls
    # therefore demonstrate rejection even with a freshly recomputed ledger.
    manifest = result["files_sha256"]
    hash_map(manifest, "Raw evidence manifest")
    require(REQUIRED_RAW.issubset(manifest), "Required raw evidence omitted from hash manifest")
    require(digest(fixture) == result["fixture_sha256"], "Fixture hash mismatch")
    for name, expected in manifest.items():
        require(digest(checked_file(out, name)) == expected, "Raw file hash mismatch: " + name)
    return {
        "status": "trial_checks_passed_batch_post_pending" if pending else "raw_checks_passed",
        "runtime_post_check": "pending_final_batch_audit" if pending else "pre_post_binding_verified",
        "phase": result["phase"], "context": context, "gpu_layers": layers,
        "input_tokens": context - 256, "output_tokens": 128, "offloaded_layers": offload,
        "metrics": metrics, "input_binding_fingerprint": fingerprint, "result_sha256": digest(out / "result.json"),
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--protocol", type=Path)
    parser.add_argument("--allow-pending-batch-post", action="store_true")
    args = parser.parse_args()
    print(json.dumps(validate(args.directory, args.protocol, allow_pending_batch_post=args.allow_pending_batch_post), indent=2))
