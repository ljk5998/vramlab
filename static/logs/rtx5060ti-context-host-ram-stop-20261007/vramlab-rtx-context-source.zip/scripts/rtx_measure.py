#!/usr/bin/env python3
"""Bounded CUDA context trials. Run through the Windows host guard only."""
import argparse
try:
    import fcntl
except ImportError:  # Windows can run no-GPU controls; real trials require WSL.
    fcntl = None
import hashlib
import json
import math
import os
from pathlib import Path
import queue
import re
import socket
import statistics
import subprocess
import threading
import time
import urllib.request

from prepare_rtx import COMMON_FLAGS, sha, save
from snapshot_rtx_runtime import capture

PACKAGE = Path(__file__).resolve().parents[1]
DATA = PACKAGE / 'data/rtx'
FLAGS = [*COMMON_FLAGS, '--ctx-checkpoints', '0']
CONTEXTS = (2048, 4096, 8192, 16384)
SCRIPT_NAMES = ('rtx_measure.py', 'validate_rtx_trial.py', 'guard_rtx.py',
                'prepare_rtx.py', 'snapshot_rtx_runtime.py', 'check_package.py')
STREAM_READERS = {}


class BindingError(ValueError):
    """Instrumentation/input provenance failure, never an excluded workload."""


def json_sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def input_manifest():
    lock = read(PACKAGE / 'inputs.lock.json')
    return {'status': 'PASS', 'inputs_lock_sha256': sha(PACKAGE / 'inputs.lock.json'),
            'model': {k: lock['model'][k] for k in ('filename', 'bytes', 'sha256', 'revision')},
            'scripts_sha256': {n: sha(PACKAGE / 'scripts' / n) for n in SCRIPT_NAMES},
            'fixtures_sha256': {p.name: sha(p) for p in sorted((PACKAGE / 'fixtures').glob('rtx-*'))},
            'flags_sha256': json_sha(FLAGS)}


def binding_identity(runtime):
    return {k: runtime[k] for k in ('source_commit', 'source_status', 'files', 'input_verification')}


def binding_fingerprint(runtime):
    return json_sha(binding_identity(runtime))


def verification_path(runtime_path):
    return runtime_path.with_name(runtime_path.name + '.verification.json')


def verified_runtime(path):
    runtime, receipt = read(path), read(verification_path(path))
    if (receipt.get('status') != 'PASS' or receipt.get('runtime_sha256') != sha(path)
            or receipt.get('input_binding_fingerprint') != binding_fingerprint(runtime)
            or runtime['input_verification'].get('status') != 'PASS'
            or runtime['source_status'] or not runtime['files']):
        raise BindingError('Missing or changed verified runtime receipt')
    lock = read(PACKAGE / 'inputs.lock.json')
    if (runtime['source_commit'] != lock['llama_cpp']['commit']
            or runtime['input_verification'] != input_manifest()):
        raise BindingError('Verified inputs differ from current lock/scripts/fixtures/flags')
    return runtime


def classify_failure(error, stage=''):
    text = str(error)
    if isinstance(error, BindingError):
        return 'instrumentation_invalid'
    if isinstance(error, TimeoutError) or any(s in text for s in
            ('host_ram_below_2gib', 'disk_below_5gib', 'Baseline spread',
             'Baseline median GPU', 'Cross-trial baseline drift')):
        return 'resource_or_budget_stop'
    if stage in ('startup', 'request') and text.startswith('Server exited during'):
        return 'workload_failure'
    return 'instrumentation_invalid'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def utc():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())


def host_health():
    directory = os.environ.get('VRAMLAB_GUARD_DIRECTORY')
    if not directory:
        raise RuntimeError('Windows host guard required')
    sample = read(Path(directory) / 'heartbeat.json')
    if time.time() - sample['time'] > 8 or sample['abort']:
        raise RuntimeError('host_guard_unhealthy: ' + str(sample.get('abort')))
    if 'gpu' not in sample:
        raise RuntimeError('Host guard needs --telemetry-gpu')
    for value in (sample['time'], sample['available_ram_bytes'], sample['disk_free_bytes'],
                  sample['gpu']['total_mib'], sample['gpu']['used_mib'],
                  sample['gpu']['utilization_percent']):
        if isinstance(value, bool) or not math.isfinite(float(value)) or float(value) < 0:
            raise BindingError('Invalid required host telemetry numeric field')
    if sample['available_ram_bytes'] < 2 * 1024**3 or sample['disk_free_bytes'] < 5 * 1024**3:
        raise RuntimeError('host_ram_below_2gib or disk_below_5gib')
    return sample


def memory_sample(pid=None):
    start = time.monotonic()
    host = host_health()
    raw = Path('/proc/meminfo').read_text()
    mem = {k: int(v)*1024 for k, v in re.findall(r'^(\w+):\s+(\d+) kB', raw, re.M)}
    status = None
    rss = hwm = None
    if pid is not None:
        try:
            status = Path(f'/proc/{pid}/status').read_text()
            values = {k: int(v)*1024 for k, v in re.findall(r'^(VmRSS|VmHWM):\s+(\d+) kB', status, re.M)}
            rss, hwm = values.get('VmRSS'), values.get('VmHWM')
        except FileNotFoundError:
            pass
    vm = Path('/proc/vmstat').read_text()
    swaps = {k: int(v) for k, v in re.findall(r'^(pswpin|pswpout) (\d+)', vm, re.M)}
    return {'monotonic': start, 'epoch': time.time(), 'host': host,
            'guest_available_bytes': mem['MemAvailable'],
            'guest_swap_used_bytes': mem['SwapTotal']-mem['SwapFree'],
            'process_rss_bytes': rss, 'process_hwm_bytes': hwm,
            'meminfo_raw': raw, 'process_status_raw': status,
            'guest_swap_counters_pages': swaps, 'sample_duration_s': time.monotonic()-start}


class Collector:
    def __init__(self, out):
        self.out, self.pid, self.phase = out, None, 'baseline'
        self.samples, self.error = [], None
        self.stop = threading.Event()
        self.thread = threading.Thread(target=self.collect, daemon=True)

    def collect(self):
        with (self.out / 'memory.jsonl').open('w') as log:
            while not self.stop.is_set():
                start = time.monotonic()
                try:
                    sample = memory_sample(self.pid)
                    sample['phase'] = self.phase
                    self.samples.append(sample)
                    log.write(json.dumps(sample) + '\n')
                    log.flush()
                except Exception as error:
                    self.error = f'{type(error).__name__}: {error}'
                    break
                self.stop.wait(max(0, 1-(time.monotonic()-start)))

    def check(self):
        if self.error:
            raise RuntimeError('collector_failed: '+self.error)
        if not self.thread.is_alive():
            raise RuntimeError('collector_stopped')
        if self.samples and time.monotonic()-self.samples[-1]['monotonic'] > 8:
            raise RuntimeError('collector_stale')
        host_health()

    def wait(self, seconds):
        end = time.monotonic()+seconds
        while time.monotonic() < end:
            self.check()
            time.sleep(min(.2, max(0, end-time.monotonic())))


def stream(base, payload, out, check, first_budget=120, total_budget=180):
    events = queue.Queue()
    cancel = threading.Event()
    started = time.monotonic()
    save(out / 'request-clock.json', {'monotonic': started, 'utc': utc(), 'epoch': time.time()})
    def reader():
        try:
            request = urllib.request.Request(base+'/completion', json.dumps(payload).encode(), {'Content-Type':'application/json'})
            with urllib.request.urlopen(request, timeout=total_budget) as response, (out/'response.sse').open('wb') as log:
                for line in response:
                    if cancel.is_set():
                        break
                    timestamp = time.monotonic()
                    log.write(line)
                    log.flush()
                    if line.startswith(b'data:') and line[5:].strip() != b'[DONE]':
                        parsed = json.loads(line[5:])
                        events.put((timestamp, parsed))
                        if isinstance(parsed, dict) and parsed.get('stop') is True:
                            break
            events.put((time.monotonic(), None))
        except Exception as error:
            events.put((time.monotonic(), error))
    worker = threading.Thread(target=reader, daemon=True)
    STREAM_READERS[out.resolve()] = (worker, cancel)
    worker.start()
    first = None
    try:
        return _consume_stream(events, out, check, started, first_budget, total_budget)
    finally:
        cancel.set()
        worker.join(timeout=1)
        if not worker.is_alive():
            STREAM_READERS.pop(out.resolve(), None)


def finish_stream_reader(out):
    pending = STREAM_READERS.get(out.resolve())
    if pending is None:
        return True
    worker, cancel = pending
    cancel.set()
    worker.join(timeout=3)  # Server cleanup has already closed its side of HTTP.
    if worker.is_alive():
        return False
    STREAM_READERS.pop(out.resolve(), None)
    return True


def _consume_stream(events, out, check, started, first_budget, total_budget):
    first = None
    with (out/'events.jsonl').open('w') as log:
        while True:
            check()
            if time.monotonic()-started >= total_budget:
                raise TimeoutError('total_request_timeout')
            if first is None and time.monotonic()-started >= first_budget:
                raise TimeoutError('first_content_timeout')
            try:
                timestamp, event = events.get(timeout=.05)
            except queue.Empty:
                continue
            if isinstance(event, Exception):
                raise event
            if event is None:
                raise ValueError('Missing final SSE event')
            if not isinstance(event, dict):
                raise ValueError('Malformed SSE object')
            log.write(json.dumps({'received_monotonic':timestamp, 'event':event})+'\n')
            log.flush()
            if first is None and isinstance(event.get('content'), str) and event['content']:
                first = timestamp
            if event.get('stop') is True:
                if first is None:
                    raise ValueError('No generated content')
                return {'request_start_monotonic':started, 'first_content_monotonic':first,
                        'final_monotonic':timestamp, 'ttft_s':first-started,
                        'completion_s':timestamp-started, 'final':event}


def startup_check(log, context, layers):
    expected = 37 if layers == 'all' else 18
    required = [rf'offloaded {expected}/37 layers to GPU', rf'n_ctx_seq\s*=\s*{context}\b',
                r'flash_attn\s*=\s*enabled', r'CUDA0 model buffer size', r'CUDA0 KV buffer size']
    if any(not re.search(pattern, log) for pattern in required):
        raise ValueError('Effective startup settings missing or incorrect')
    if 'context checkpoints enabled' in log:
        raise ValueError('Context checkpoints unexpectedly enabled')


def baseline_check(samples, reference=None):
    if len(samples) < 25:
        raise ValueError('Fewer than 25 baseline observations')
    ram = [s['host']['available_ram_bytes'] for s in samples]
    gpu = [float(s['host']['gpu']['used_mib']) for s in samples]
    util = [float(s['host']['gpu']['utilization_percent']) for s in samples]
    if max(ram)-min(ram) > 512*1024**2 or max(gpu)-min(gpu) > 128:
        raise ValueError('Baseline spread exceeds 512 MiB host RAM or 128 MiB global VRAM')
    if statistics.median(util) > 10:
        raise ValueError('Baseline median GPU utilization exceeds 10 percent')
    current = {'host_available_bytes':statistics.median(ram), 'gpu_used_mib':statistics.median(gpu)}
    if reference and (abs(current['gpu_used_mib']-reference['gpu_used_mib']) > 256 or
                      abs(current['host_available_bytes']-reference['host_available_bytes']) > 1024**3):
        raise ValueError('Cross-trial baseline drift exceeds 256 MiB VRAM or 1 GiB host RAM')
    return current


def select_server(phase, context, layers, server_override, runtime):
    """Bind the actual executable; alternate builds belong only to reader trials."""
    server = DATA / 'build/bin/llama-server'
    if server_override is not None:
        if phase != 'reader' or context != 2048 or layers != 'all':
            raise BindingError('Server override requires reader 2048/all')
        requested = Path(server_override)
        if not requested.is_absolute():
            raise BindingError('Reader server override must be absolute')
        server = requested.resolve()
        relative = server.relative_to(DATA.resolve()) if server.is_relative_to(DATA.resolve()) else None
        if (relative is None or len(relative.parts) != 4
                or not relative.parts[0].startswith('reproduction-')
                or relative.parts[1:] != ('build', 'bin', 'llama-server')):
            raise BindingError('Reader server must use its isolated reproduction build')
    elif phase == 'reader':
        raise BindingError('Reader trial requires an explicit isolated server')
    server = server.resolve()
    if not server.is_file():
        raise BindingError('Verified server executable is missing')
    matches = [entry for key, entry in runtime['files'].items()
               if Path(entry.get('resolved', key)).resolve() == server]
    if (len(matches) != 1 or matches[0].get('bytes') != server.stat().st_size
            or matches[0].get('sha256') != sha(server)):
        raise BindingError('Actual server differs from verified runtime closure')
    return server


def trial(out, context, layers, phase, protocol=None, reference=None, runtime=None, prepared=False,
          server_override=None):
    if not prepared:
        out.mkdir(parents=True, exist_ok=False)
    elif not out.is_dir() or (out / 'result.json').exists():
        raise FileExistsError('Trial output is not a newly reserved directory')
    if runtime is None or runtime['input_verification'] != input_manifest():
        raise BindingError('Trial requires actual verified input binding')
    model = DATA / 'models/Qwen3-8B-Q4_K_M.gguf'
    server = select_server(phase, context, layers, server_override, runtime)
    fixture = PACKAGE / f'fixtures/rtx-tokens-{context}.json'
    payload = {'prompt':read(fixture), 'stream':True, 'cache_prompt':False, 'n_predict':128,
               'temperature':0, 'seed':20260910, 'ignore_eos':True, 'return_tokens':True}
    if len(payload['prompt']) != context-256 or not all(type(t) is int and t >= 0 for t in payload['prompt']):
        raise ValueError('Fixture length mismatch')
    with socket.socket() as probe:
        probe.bind(('127.0.0.1',0))
        port = probe.getsockname()[1]
    argv = [str(server), '--model', str(model), *FLAGS, '--ctx-size', str(context),
            '--gpu-layers', layers, '--port', str(port)]
    env = {k:v for k,v in os.environ.items() if not k.startswith(('LLAMA_ARG_', 'GGML_', 'CUDA_', 'LD_'))}
    env.update(LD_LIBRARY_PATH='/usr/local/cuda-13.2/lib64:/usr/lib/wsl/lib', CUDA_VISIBLE_DEVICES='0', OMP_NUM_THREADS='4')
    result = {'schema_version':1, 'phase':phase, 'primary_eligible':phase=='primary', 'context':context,
              'gpu_layers':layers, 'started_utc':utc(), 'status':'started',
              'model_sha256':read(PACKAGE/'inputs.lock.json')['model']['sha256'],
              'source_commit':read(PACKAGE/'inputs.lock.json')['llama_cpp']['commit'],
              'server_path':str(server),
              'binary_before_sha256':sha(server), 'fixture_sha256':sha(fixture),
              'protocol_sha256':sha(protocol) if protocol else None,
              'runtime_binding_scope':'batch' if phase=='primary' else 'trial',
              'input_verification_status':'PASS', 'runtime_after_sha256':None,
              'batch_post_pending':phase=='primary',
              'runtime_before_sha256':sha(out.parent/'runtime-before.json' if phase=='primary' else out/'runtime-before.json'),
              'input_binding_fingerprint':binding_fingerprint(runtime),
              'host_guard_directory':os.environ['VRAMLAB_GUARD_DIRECTORY']}
    save(out/'command.json', argv)
    save(out/'request.json', payload)
    save(out/'environment.json', {k:env.get(k) for k in ('LD_LIBRARY_PATH','CUDA_VISIBLE_DEVICES','OMP_NUM_THREADS','GGML_CUDA_ENABLE_UNIFIED_MEMORY')})
    save(out/'result.json', result)
    collector = Collector(out)
    collector.thread.start()
    child = None
    stage = 'baseline'
    try:
        collector.wait(30)
        baseline = [s for s in collector.samples if s['phase']=='baseline']
        result['baseline'] = baseline_check(baseline, reference)
        collector.phase = 'startup'
        stage = 'startup'
        with (out/'server.log').open('wb') as log:
            start = time.monotonic()
            child = subprocess.Popen(argv, env=env, stdout=log, stderr=subprocess.STDOUT)
            collector.pid = child.pid
            result.update(server_pid=child.pid, startup_start_monotonic=start)
            save(out/'result.json', result)
            base = f'http://127.0.0.1:{port}'
            while True:
                collector.check()
                if child.poll() is not None:
                    raise RuntimeError('Server exited during startup')
                if time.monotonic()-start > 120:
                    raise TimeoutError('startup_timeout')
                try:
                    with urllib.request.urlopen(base+'/health', timeout=.5) as response:
                        if json.load(response).get('status') == 'ok':
                            break
                except OSError:
                    time.sleep(.1)
            result['startup_s'] = time.monotonic()-start
            startup_check((out/'server.log').read_text(errors='replace'), context, layers)
            processes = subprocess.run(['/usr/lib/wsl/lib/nvidia-smi', '--query-compute-apps=pid,used_memory',
                                        '--format=csv,noheader,nounits'], capture_output=True, text=True, timeout=3)
            save(out/'gpu-process-accounting.json', {'exit_code':processes.returncode, 'stdout':processes.stdout,
                 'stderr':processes.stderr, 'scope':'WSL NVML process query; N/A or unmatched PID remains unavailable'})
            collector.phase = 'request'
            stage = 'request'
            def alive():
                collector.check()
                if child.poll() is not None:
                    raise RuntimeError('Server exited during request')
            result['completion'] = stream(base, payload, out, alive)
            with urllib.request.urlopen(base+'/health', timeout=2) as response:
                save(out/'post-health.json', json.load(response))
            result['status'] = 'completed_pending_validation'
    except Exception as error:
        result['status'], result['error'] = 'failed', f'{type(error).__name__}: {error}'
        result['failure_class'] = classify_failure(error, stage)
    finally:
        collector.phase = 'shutdown'
        try:
            if child is not None and child.poll() is None:
                child.terminate()
                try:
                    child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    child.kill()
                    child.wait(timeout=3)
                    result['shutdown_escalated'] = True
        except Exception as error:
            result.update(status='failed', failure_class='instrumentation_invalid', cleanup_error=str(error))
        result['exit_code'] = child.returncode if child else None
        collector.pid, collector.phase = None, 'recovery'
        try:
            collector.wait(30)
        except Exception as error:
            result.update(status='failed', failure_class=classify_failure(error), recovery_error=str(error))
        collector.stop.set()
        collector.thread.join(timeout=5)
        if collector.thread.is_alive():
            result.update(status='failed', failure_class='instrumentation_invalid', cleanup_error='Collector did not join')
        result['collector_error'] = collector.error
        stable = finish_stream_reader(out) and not collector.thread.is_alive()
        result['raw_stability'] = 'PASS' if stable else 'FAIL'
        if not stable:
            result.update(status='failed',failure_class='instrumentation_invalid',cleanup_error='Raw writer did not join; evidence hashes not finalized')
        try:
            result['binary_after_sha256'] = sha(server)
            if result['binary_after_sha256'] != result['binary_before_sha256']:
                raise BindingError('Binary changed during trial')
        except Exception as error:
            result.update(status='failed', failure_class='instrumentation_invalid', binding_error=str(error))
        result['finished_utc'] = utc()
        if stable:
            result['files_sha256'] = {p.name:sha(p) for p in sorted(out.iterdir()) if p.is_file() and p.name!='result.json'}
        save(out/'result.json', result)
    return result


def verify_inputs(out):
    from check_package import verify_file
    sidecar = verification_path(out)
    if out.exists() or sidecar.exists():
        raise FileExistsError('Verification evidence already exists')
    receipt = {'status': 'started', 'started_utc': utc()}
    try:
        expected = input_manifest()
        lock = read(PACKAGE/'inputs.lock.json')
        actual = verify_file(DATA/'models'/lock['model']['filename'], lock['model']['bytes'], lock['model']['sha256'])
        if actual != expected['model']['sha256']:
            raise BindingError('Actual full model hash differs from lock')
        capture(out)  # Independently reads clean source and hashes resolved libraries.
        runtime = read(out)
        if (runtime['source_commit'] != lock['llama_cpp']['commit'] or runtime['source_status']
                or not runtime['files'] or input_manifest() != expected):
            raise BindingError('Input/source changed during verification')
        runtime['input_verification'] = expected
        save(out, runtime)
        receipt.update(status='PASS', runtime_sha256=sha(out),
                       input_binding_fingerprint=binding_fingerprint(runtime))
        return runtime
    except Exception as error:
        receipt.update(status='FAIL', failure_class='instrumentation_invalid', error=f'{type(error).__name__}: {error}')
        raise BindingError(receipt['error']) from error
    finally:
        receipt['finished_utc'] = utc()
        save(sidecar, receipt)


def finish_trial_binding(folder, before, after, scope):
    result = read(folder/'result.json')
    if binding_identity(before) != binding_identity(after):
        result.update(status='failed', failure_class='instrumentation_invalid', binding_error='Pre/post runtime or input binding changed')
    result.update(runtime_binding_scope=scope, input_verification_status='PASS' if binding_identity(before)==binding_identity(after) else 'FAIL',
                  batch_post_pending=False,
                  runtime_after_sha256=sha(folder/'runtime-after.json' if scope=='trial' else folder.parent/'runtime-after.json'))
    if result.get('raw_stability') != 'FAIL':
        result['files_sha256'] = {p.name:sha(p) for p in sorted(folder.iterdir()) if p.is_file() and p.name!='result.json'}
    save(folder/'result.json', result)
    return result


def run_scout(out, context, layers):
    from validate_rtx_trial import validate
    out.mkdir(parents=True, exist_ok=False)
    state = {'phase':'scout', 'status':'verifying_inputs', 'started_utc':utc(),
             'context':context, 'gpu_layers':layers, 'raw_validation_status':'NOT_RUN'}
    save(out.with_suffix('.batch.json'), state)
    before = None
    error = None
    post_binding_verified = False
    validation_attempted = False
    validation_completed = False
    try:
        before = verify_inputs(out/'runtime-before.json')
        result = trial(out,context,layers,'scout',runtime=before,prepared=True)
        state.update(trial_status=result['status'], failure_class=result.get('failure_class'))
    except Exception as caught:
        error = caught
        state.update(status='instrumentation_invalid', error=f'{type(caught).__name__}: {caught}')
    finally:
        try:
            after = verify_inputs(out/'runtime-after.json')
            if before is None or binding_identity(before) != binding_identity(after):
                raise BindingError('Scout pre/post binding unavailable or changed')
            post_binding_verified = True
            state.update(input_verification_status='PASS',runtime_unchanged=True)
            if (out/'result.json').exists():
                result = finish_trial_binding(out,before,after,'trial')
                if result['status']=='completed_pending_validation':
                    validation_attempted = True
                    receipt = validate(out)
                    validation_completed = True
                    state['raw_validation_status'] = receipt['status']
                    save(out.with_suffix('.validation.json'), receipt)
                    state['status']='scout_validated'
                else:
                    state.update(status=result.get('failure_class','instrumentation_invalid'), error=result.get('error'))
            elif error is None:
                raise BindingError('Scout result missing')
        except Exception as caught:
            error = caught
            raw_status = 'FAIL' if validation_attempted and not validation_completed else state['raw_validation_status']
            state.update(status='instrumentation_invalid', error=f'{type(caught).__name__}: {caught}',
                         input_verification_status='PASS' if post_binding_verified else 'FAIL',
                         runtime_unchanged=post_binding_verified, raw_validation_status=raw_status)
            if (out/'result.json').exists():
                result = read(out/'result.json')
                result.update(status='failed',failure_class='instrumentation_invalid',
                              input_verification_status='PASS' if post_binding_verified else 'FAIL',
                              raw_validation_status=raw_status,finalization_error=state['error'])
                save(out/'result.json',result)
        state['finished_utc']=utc()
        save(out.with_suffix('.batch.json'),state)
        if (out/'result.json').exists() and read(out/'result.json').get('raw_stability') != 'FAIL':
            result = read(out/'result.json')
            result['files_sha256']={p.name:sha(p) for p in sorted(out.iterdir()) if p.is_file() and p.name!='result.json'}
            save(out/'result.json',result)
    if error is not None or state['status']!='scout_validated':
        raise RuntimeError('Scout stopped: '+str(state.get('error',state['status']))) from error
    return state


def verify_scout(folder):
    before, after = verified_runtime(folder/'runtime-before.json'), verified_runtime(folder/'runtime-after.json')
    if binding_identity(before) != binding_identity(after):
        raise BindingError('Scout verified closure changed')
    result = read(folder/'result.json')
    if (result.get('input_verification_status')!='PASS'
            or result.get('input_binding_fingerprint')!=binding_fingerprint(before)
            or result.get('runtime_binding_scope')!='trial'
            or result.get('runtime_before_sha256')!=sha(folder/'runtime-before.json')
            or result.get('runtime_after_sha256')!=sha(folder/'runtime-after.json')):
        raise BindingError('Scout result fingerprints do not bind verified evidence')
    expected = {p.name:sha(p) for p in sorted(folder.iterdir()) if p.is_file() and p.name!='result.json'}
    if result.get('files_sha256') != expected:
        raise BindingError('Scout raw files changed')
    if (result['context'] not in CONTEXTS or result['gpu_layers'] not in ('all','18')
            or result['phase']!='scout' or result.get('primary_eligible') is not False
            or result['model_sha256']!=before['input_verification']['model']['sha256']
            or result['source_commit']!=before['source_commit']):
        raise BindingError('Scout trial identity differs from verified inputs')
    return before, result


def freeze(path, scouts):
    if path.exists():
        raise FileExistsError(path)
    from validate_rtx_trial import validate
    retained, excluded, summaries, bindings = [], [], [], []
    for ctx in CONTEXTS:
        for layers in ('all','18'):
            matches = sorted(scouts.glob(f'scout-ctx-{ctx}-layers-{layers}'))
            if len(matches)!=1:
                raise ValueError(f'Missing unique scout {ctx}/{layers}')
            source = matches[0]
            runtime, result = verify_scout(source)
            if result['context'] != ctx or result['gpu_layers'] != layers:
                raise BindingError('Scout directory and trial identity differ')
            if bindings and binding_identity(runtime) != binding_identity(bindings[0]):
                raise BindingError('Scouts used different verified inputs/closures')
            bindings.append(runtime)
            if result['status']=='completed_pending_validation':
                summaries.append(validate(source))
                retained.append((ctx,layers))
            else:
                if result.get('failure_class') not in ('workload_failure','resource_or_budget_stop'):
                    raise BindingError('Instrumentation failure cannot become an excluded condition')
                excluded.append({'context':ctx,'gpu_layers':layers,'result_sha256':sha(source/'result.json'),
                                 'reason':result.get('error'), 'source':str(source)})
    if not retained:
        raise ValueError('No retained conditions')
    orders = [retained, list(reversed(retained)), retained[len(retained)//2:]+retained[:len(retained)//2]]
    sequence = []
    for rep, order in enumerate(orders,1):
        for ctx,layers in order:
            sequence.append({'id':f'trial-{len(sequence)+1:02d}-ctx-{ctx}-layers-{layers}-rep-{rep}',
                             'context':ctx,'gpu_layers':layers,'repetition':rep})
    protocol = {'schema_version':1, 'status':'frozen_before_primary', 'frozen_utc':utc(),
       'original_conditions':[[c,l] for c in CONTEXTS for l in ('all','18')],
       'retained':retained,'excluded':excluded,'scout_summaries':summaries,'order':sequence,
       'order_sha256':json_sha(sequence),
       'scout_bindings':[{'context':c,'gpu_layers':l,'source':str(scouts/f'scout-ctx-{c}-layers-{l}'),
          'result_sha256':sha(scouts/f'scout-ctx-{c}-layers-{l}'/'result.json'),
          'input_binding_fingerprint':binding_fingerprint(bindings[0])} for c in CONTEXTS for l in ('all','18')],
       'guard_budget_seconds':390*len(sequence)+900,'scout_guard_budget_seconds':600,
       'flags':FLAGS,'baseline_seconds':30,'recovery_seconds':30,'sample_cadence_seconds':1,
       'startup_budget_seconds':120,'first_content_budget_seconds':120,'request_budget_seconds':180,
       'baseline_vram_range_mib':128,'baseline_host_ram_range_mib':512,'baseline_gpu_util_median_max':10,
       'cross_trial_vram_drift_mib':256,'cross_trial_host_ram_drift_mib':1024,
       'baseline_failure_policy':'Stop and preserve attempted trials; no silent replacement',
       'warmup':'Fresh server, built-in startup warmup, no additional request, no OS cache purge',
       'model_hash_policy':'Full model and resolved runtime closure verified before and after each batch; binary verified each trial',
       'background_policy':'Existing ordinary apps retained; no browser QA, site builds or other benchmarks during primary; lightweight text and file work allowed',
       'scope':'Near-filled-context sweep. Capacity AND input length change. No answer-quality or cross-device benchmark claim.',
       'scripts_sha256':input_manifest()['scripts_sha256'],
       'fixtures_sha256':{p.name:sha(p) for p in sorted((PACKAGE/'fixtures').glob('rtx-*'))},
       'inputs_lock_sha256':sha(PACKAGE/'inputs.lock.json'),
       'runtime_reference':bindings[0]}
    save(path,protocol)
    print(json.dumps({'protocol':str(path),'sha256':sha(path),'primary_trials':len(sequence)}),flush=True)


def check_protocol(path):
    protocol=read(path)
    if (protocol.get('status')!='frozen_before_primary'
            or protocol.get('inputs_lock_sha256')!=sha(PACKAGE/'inputs.lock.json')
            or protocol.get('order_sha256')!=json_sha(protocol['order'])
            or protocol.get('flags')!=FLAGS):
        raise BindingError('Frozen lock/order/flags changed')
    current=input_manifest()
    if (protocol['scripts_sha256']!=current['scripts_sha256']
            or protocol['fixtures_sha256']!=current['fixtures_sha256']
            or protocol['runtime_reference']['input_verification']!=current):
        raise BindingError('Frozen scripts/fixtures/input binding changed')
    expected=[]
    retained=[tuple(row) for row in protocol['retained']]
    original=[(c,l) for c in CONTEXTS for l in ('all','18')]
    if not retained or len(set(retained))!=len(retained) or any(row not in original for row in retained):
        raise BindingError('Invalid retained condition set')
    for rep,order in enumerate((retained,list(reversed(retained)),retained[len(retained)//2:]+retained[:len(retained)//2]),1):
        for ctx,layers in order:
            expected.append({'id':f'trial-{len(expected)+1:02d}-ctx-{ctx}-layers-{layers}-rep-{rep}',
                             'context':ctx,'gpu_layers':layers,'repetition':rep})
    if (protocol['order']!=expected or protocol['guard_budget_seconds']!=390*len(expected)+900
            or protocol['original_conditions']!=[list(row) for row in original]):
        raise BindingError('Frozen order/condition/budget contract changed')
    return protocol


def run_primary(out, protocol_path):
    from validate_rtx_trial import validate
    out.mkdir(parents=True,exist_ok=False)
    state={'phase':'primary','started_utc':utc(),'status':'verifying_inputs',
           'protocol_sha256':None,'trials':[],'raw_validation_status':'NOT_RUN'}
    save(out/'batch.json',state)
    before=None
    failure=None
    protocol=None
    post_binding_verified=False
    raw_validation_failed=False
    try:
        state['protocol_sha256']=sha(protocol_path)
        protocol=check_protocol(protocol_path)
        before=verify_inputs(out/'runtime-before.json')
        if binding_identity(before)!=binding_identity(protocol['runtime_reference']):
            raise BindingError('Frozen verified runtime closure changed')
        state.update(status='running',guard_budget_seconds=protocol['guard_budget_seconds'])
        save(out/'batch.json',state)
        reference=None
        for item in protocol['order']:
            folder=out/item['id']
            row={**item,'status':'started'}
            state['trials'].append(row)
            save(out/'batch.json',state)
            result=trial(folder,item['context'],item['gpu_layers'],'primary',protocol_path,reference,runtime=before)
            row.update(status=result['status'],result_sha256=sha(folder/'result.json'),failure_class=result.get('failure_class'))
            save(out/'batch.json',state)
            if result['status']!='completed_pending_validation':
                raise RuntimeError(str(result.get('error',result.get('failure_class'))))
            try:
                receipt=validate(folder,protocol_path,allow_pending_batch_post=True)
            except Exception:
                raw_validation_failed=True
                row.update(raw_validation_status='FAIL',prevalidation_status='FAIL')
                raise
            save(out/(item['id']+'.prevalidation.json'),receipt)
            reference=reference or result['baseline']
            row.update(status='trial_checks_passed_batch_post_pending',raw_validation_status=receipt['status'],
                       prevalidation_status=receipt['status'])
            save(out/'batch.json',state)
        state['status']='trials_done_batch_post_pending'
    except Exception as error:
        failure=error
        category = state['trials'][-1].get('failure_class') if state['trials'] else None
        state.update(status='stopped_on_failure',failure_class=category or classify_failure(error),error=f'{type(error).__name__}: {error}')
        if state['trials'] and state['trials'][-1]['status']=='started':
            state['trials'][-1].update(status='instrumentation_invalid',failure_class='instrumentation_invalid',error=state['error'])
    finally:
        try:
            after=verify_inputs(out/'runtime-after.json')
            if before is None or binding_identity(before)!=binding_identity(after):
                raise BindingError('Batch pre/post verification unavailable or changed')
            post_binding_verified=True
            state['runtime_unchanged']=True
            state['input_verification_status']='PASS'
            for row in state['trials']:
                folder=out/row['id']
                if not (folder/'result.json').exists():
                    row.update(status='instrumentation_invalid',failure_class='instrumentation_invalid')
                    continue
                result=finish_trial_binding(folder,before,after,'batch')
                row['result_sha256']=sha(folder/'result.json')
                if result['status']=='completed_pending_validation':
                    try:
                        receipt=validate(folder,protocol_path)
                    except Exception:
                        raw_validation_failed=True
                        row['raw_validation_status']='FAIL'
                        raise
                    save(out/(row['id']+'.validation.json'),receipt)
                    row.update(status='validated',metrics=receipt['metrics'],raw_validation_status=receipt['status'])
            if failure is None:
                state['status']='all_retained_primary_trials_validated'
        except Exception as error:
            failure=error
            state.update(status='instrumentation_invalid',
                         input_verification_status='PASS' if post_binding_verified else 'FAIL',
                         runtime_unchanged=post_binding_verified,
                         failure_class='instrumentation_invalid',post_verification_error=f'{type(error).__name__}: {error}')
        completed=sum(row.get('raw_validation_status')=='raw_checks_passed' for row in state['trials'])
        state['raw_validation_status']=('FAIL' if raw_validation_failed else 'raw_checks_passed'
            if failure is None and completed==len(state['trials']) and completed else 'PARTIAL' if completed else 'NOT_RUN')
        if failure is not None and state.get('failure_class')=='instrumentation_invalid':
            state.update(status='instrumentation_invalid',
                         input_verification_status='PASS' if post_binding_verified else 'FAIL',
                         runtime_unchanged=post_binding_verified)
            for row in state['trials']:
                row['primary_eligible']=False
                row['batch_invalid']=True
                row.update(status='instrumentation_invalid',failure_class='instrumentation_invalid')
                folder=out/row['id']
                if (folder/'result.json').exists():
                    result=(finish_trial_binding(folder,before,after,'batch') if post_binding_verified
                            else read(folder/'result.json'))
                    result.update(status='failed',primary_eligible=False,batch_invalid=True,
                                  input_verification_status='PASS' if post_binding_verified else 'FAIL',
                                  raw_validation_status=row.get('raw_validation_status','NOT_RUN'),
                                  failure_class='instrumentation_invalid',
                                  finalization_error=state.get('post_verification_error',state.get('error')))
                    save(folder/'result.json',result)
                    row['result_sha256']=sha(folder/'result.json')
        state['finished_utc']=utc()
        save(out/'batch.json',state)
    if failure is not None:
        raise RuntimeError('Primary stopped; terminal batch receipt preserved') from failure
    return state


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode',choices=('scout','freeze','primary'))
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--context',type=int,choices=CONTEXTS)
    parser.add_argument('--layers',choices=('all','18'))
    parser.add_argument('--protocol',type=Path)
    parser.add_argument('--scouts',type=Path)
    args=parser.parse_args()
    if os.environ.get('WSL_DISTRO_NAME')!='VRAMLab-RTX-Context' or fcntl is None:
        raise RuntimeError('Wrong experiment guest or missing Linux locking')
    host_health()
    if not args.out.resolve().is_relative_to(DATA.resolve()) or args.out.resolve()==DATA.resolve():
        raise ValueError('Output must be a fresh directory under data/rtx')
    if args.mode in ('freeze','primary'):
        if args.protocol is None or not args.protocol.resolve().is_relative_to(DATA.resolve()):
            parser.error('freeze/primary require a protocol under data/rtx')
    if args.mode=='freeze' and (args.scouts is None or not args.scouts.resolve().is_relative_to(DATA.resolve())):
        parser.error('freeze requires scouts under data/rtx')
    with (DATA/'measurement.lock').open('a') as lock_file:
        fcntl.flock(lock_file,fcntl.LOCK_EX|fcntl.LOCK_NB)
        if args.mode=='freeze':
            freeze(args.protocol,args.scouts)
        elif args.mode=='scout':
            if args.context is None or args.layers is None:
                parser.error('scout requires context and layers')
            print(json.dumps(run_scout(args.out,args.context,args.layers)),flush=True)
        else:
            print(json.dumps(run_primary(args.out,args.protocol)),flush=True)


if __name__=='__main__':
    main()
