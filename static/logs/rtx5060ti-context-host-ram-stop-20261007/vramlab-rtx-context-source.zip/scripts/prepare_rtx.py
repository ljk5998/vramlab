#!/usr/bin/env python3
"""Prepare exact tokenizer inputs and run ONE excluded 2K CUDA setup check.

Use guard_rtx.py on Windows to supervise this in the experiment guest. This is
not the scout matrix or the primary collector. Never mixes setup with results.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import queue
import re
import socket
import struct
import subprocess
import threading
import time
import urllib.error
import urllib.request

from check_package import check_package, verify_file

PACKAGE = Path(__file__).resolve().parents[1]
DATA = PACKAGE / "data/rtx"
CONTEXTS = [2048, 4096, 8192, 16384]
COMMON_FLAGS = [
    "--fit", "off", "--parallel", "1", "--cache-type-k", "f16",
    "--cache-type-v", "f16", "--flash-attn", "on", "--batch-size", "512",
    "--ubatch-size", "128", "--threads", "4", "--threads-batch", "4",
    "--no-cache-prompt", "--cache-ram", "0", "--no-cache-idle-slots",
    "--no-context-shift", "--perf", "--warmup", "--offline", "--host", "127.0.0.1",
    "--load-mode", "none", "--lazy-mode", "off", "--verbosity", "4",
    "--cors-origins", "http://127.0.0.1",
]


def save(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def sha(path):
    with path.open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def gguf_scalars(path):
    """Read GGUF v3 metadata; skip large tokenizer arrays without dependencies."""
    formats = {0: "B", 1: "b", 2: "H", 3: "h", 4: "I", 5: "i", 6: "f", 7: "?", 10: "Q", 11: "q", 12: "d"}
    with path.open("rb") as source:
        def number(fmt):
            return struct.unpack("<" + fmt, source.read(struct.calcsize(fmt)))[0]

        def string(retain=True):
            length = number("Q")
            if retain:
                return source.read(length).decode("utf-8")
            source.seek(length, 1)

        def value(kind, retain=True):
            if kind == 8:
                return string(retain)
            if kind == 9:
                subtype, count = number("I"), number("Q")
                if subtype in formats:
                    source.seek(struct.calcsize(formats[subtype]) * count, 1)
                else:
                    for _ in range(count):
                        value(subtype, False)
                return {"array_type": subtype, "count": count}
            return number(formats[kind])

        if source.read(4) != b"GGUF" or number("I") != 3:
            raise ValueError("Expected GGUF v3")
        tensors, count = number("Q"), number("Q")
        metadata = {"tensor_count": tensors}
        for _ in range(count):
            key = string()
            metadata[key] = value(number("I"))
        return metadata


def notebook():
    header = "Synthetic English lab notebook for a local context-capacity experiment. These records are invented fixtures.\n"
    lines = [
        f"Record {i:05d}: The operator placed sample {i % 97:02d} on shelf {i % 13:02d}. "
        "The notebook records a stable room, a numbered container, and a repeated observation. "
        "These sentences do not describe a real laboratory or evaluate answer quality.\n"
        for i in range(1200)
    ]
    return header + "".join(lines)


def post(base, endpoint, payload, timeout=30):
    request = urllib.request.Request(base + endpoint, json.dumps(payload).encode(), {"Content-Type": "application/json"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.load(response)


def stream_completion(base, payload, out, first_timeout=120, total_timeout=180):
    events = queue.Queue()
    started = time.monotonic()

    def reader():
        try:
            request = urllib.request.Request(base + "/completion", json.dumps(payload).encode(), {"Content-Type": "application/json"})
            with urllib.request.urlopen(request, timeout=total_timeout) as response, (out / "response.sse").open("wb") as raw:
                for line in response:
                    received = time.monotonic()
                    raw.write(line)
                    raw.flush()
                    if line.startswith(b"data:"):
                        body = line[5:].strip()
                        if body != b"[DONE]":
                            events.put((received, json.loads(body)))
            events.put((time.monotonic(), None))
        except Exception as error:
            events.put((time.monotonic(), error))

    threading.Thread(target=reader, daemon=True).start()
    first = None
    final = None
    recorded = []
    with (out / "events.jsonl").open("w", encoding="utf-8") as event_log:
        while True:
            deadline = started + (first_timeout if first is None else total_timeout)
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError("first_content_timeout" if first is None else "request_timeout")
            try:
                received, event = events.get(timeout=remaining)
            except queue.Empty as error:
                raise TimeoutError("completion_timeout") from error
            if isinstance(event, Exception):
                raise event
            if event is None:
                break
            if not isinstance(event, dict):
                raise ValueError("Malformed SSE response")
            item = {"received_monotonic": received, "event": event}
            recorded.append(item)
            event_log.write(json.dumps(item) + "\n")
            event_log.flush()
            if first is None and isinstance(event.get("content"), str) and event["content"]:
                first = received
            if event.get("stop") is True:
                final = event
    if first is None or final is None:
        raise ValueError("Missing generated content or final event")
    return {"request_start_monotonic": started, "first_content_monotonic": first,
            "completed_monotonic": received, "client_ttft_seconds": first - started,
            "client_request_seconds": received - started, "final": final,
            "stream_token_count": sum(len(item["event"].get("tokens", [])) for item in recorded)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--label", required=True)
    args = parser.parse_args()
    if os.environ.get("WSL_DISTRO_NAME") != "VRAMLab-RTX-Context":
        raise RuntimeError("Wrong guest")
    if not re.fullmatch(r"[a-z0-9-]+", args.label):
        raise ValueError("Invalid label")
    out = DATA / "preparation" / args.label
    out.mkdir(parents=True, exist_ok=False)
    lock = check_package()
    model = DATA / "models" / lock["model"]["filename"]
    model_sha = verify_file(model, lock["model"]["bytes"], lock["model"]["sha256"])
    settings = json.loads((PACKAGE / "rtx.settings.json").read_text())
    metadata = gguf_scalars(model)
    save(out / "model-metadata.json", metadata)
    blocks = metadata[metadata["general.architecture"] + ".block_count"]
    if not isinstance(blocks, int) or blocks < 2:
        raise ValueError("Invalid repeated block count")
    if settings["gguf_repeated_blocks"] != blocks or settings["gpu_layer_arguments"] != ["all", blocks // 2]:
        raise ValueError("RTX settings differ from model metadata")
    server = DATA / "build/bin/llama-server"
    env = {key: value for key, value in os.environ.items() if not key.startswith(("LLAMA_ARG_", "GGML_CUDA_", "CUDA_"))}
    env["LD_LIBRARY_PATH"] = "/usr/local/cuda-13.2/lib64:/usr/lib/wsl/lib"
    env["CUDA_VISIBLE_DEVICES"] = "0"
    env["OMP_NUM_THREADS"] = "4"
    help_text = subprocess.check_output([str(server), "--help"], env=env, stderr=subprocess.STDOUT, text=True)
    for flag in COMMON_FLAGS:
        if flag.startswith("--") and flag not in help_text:
            raise ValueError("Unavailable flag: " + flag)
    (out / "server-help.txt").write_text(help_text)
    with socket.socket() as probe:
        probe.bind(("127.0.0.1", 0))
        port = probe.getsockname()[1]
    command = [str(server), "--model", str(model), *COMMON_FLAGS,
               "--ctx-size", "2048", "--gpu-layers", "all", "--port", str(port)]
    save(out / "command.json", command)
    save(out / "environment.json", {key: env.get(key) for key in ("CUDA_VISIBLE_DEVICES", "OMP_NUM_THREADS", "LD_LIBRARY_PATH", "GGML_CUDA_ENABLE_UNIFIED_MEMORY")})
    base = "http://127.0.0.1:" + str(port)
    manifest = {"kind": "setup_smoke_excluded", "primary_runs": 0, "scout_runs": 0,
                "started_utc_epoch": time.time(), "source_commit": lock["llama_cpp"]["commit"],
                "model_sha256": model_sha, "binary_sha256": sha(server), "gguf_blocks": blocks,
                "half_gpu_layers": blocks // 2, "warmup": "one built-in startup warmup; no extra request",
                "filesystem": "model/source/build on /mnt/c NTFS; dedicated guest rootfs in data/rtx/distro",
                "common_flags": COMMON_FLAGS, "contexts": CONTEXTS, "fixture_hashes": {}}
    manifest["script_hashes"] = {p.name: sha(p) for p in (PACKAGE / "scripts").glob("*.py")}
    save(out / "manifest.json", manifest)
    child = None
    try:
        with (out / "server.log").open("wb") as log:
            start = time.monotonic()
            child = subprocess.Popen(command, env=env, stdout=log, stderr=subprocess.STDOUT)
            while True:
                if child.poll() is not None:
                    raise RuntimeError("Server exited during startup")
                if time.monotonic() - start > 120:
                    raise TimeoutError("startup_timeout")
                try:
                    with urllib.request.urlopen(base + "/health", timeout=1) as response:
                        if json.load(response).get("status") == "ok":
                            break
                except (OSError, urllib.error.URLError):
                    time.sleep(0.2)
            manifest["startup_seconds"] = time.monotonic() - start
            text = notebook()
            (out / "notebook.txt").write_text(text, encoding="utf-8")
            tokenized = post(base, "/tokenize", {"content": text, "add_special": True, "parse_special": False})
            save(out / "tokenize-response.json", tokenized)
            tokens = tokenized["tokens"]
            if len(tokens) < max(CONTEXTS) - 256 or not all(type(token) is int for token in tokens):
                raise ValueError("Tokenizer output is incomplete")
            for context in CONTEXTS:
                path = out / f"tokens-{context}.json"
                save(path, tokens[:context - 256])
                manifest["fixture_hashes"][path.name] = sha(path)
            manifest["notebook_sha256"] = sha(out / "notebook.txt")
            payload = {"prompt": tokens[:1792], "stream": True, "cache_prompt": False,
                       "n_predict": 128, "temperature": 0, "seed": 20260910,
                       "ignore_eos": True, "return_tokens": True}
            save(out / "request.json", payload)
            result = stream_completion(base, payload, out)
            save(out / "completion.json", result)
            startup = (out / "server.log").read_text(errors="replace")
            offload = re.search(r"offloaded (\d+)/(\d+) layers to GPU", startup)
            if not offload or int(offload[1]) != blocks + 1 or offload[1] != offload[2]:
                raise ValueError("Full GPU offload was not established")
            final = result["final"]
            if final.get("tokens_evaluated") != 1792 or final.get("tokens_predicted") != 128:
                raise ValueError("Token count mismatch; preserve any overrun for review")
            if final.get("truncated") is not False:
                raise ValueError("Context was truncated or status missing")
            manifest["observed_offload"] = [int(offload[1]), int(offload[2])]
            manifest["status"] = "setup_pass_pending_independent_validation"
    except Exception as error:
        manifest["status"] = "setup_failed"
        manifest["error"] = f"{type(error).__name__}: {error}"
        raise
    finally:
        if child is not None and child.poll() is None:
            child.terminate()
            try:
                child.wait(timeout=3)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait(timeout=3)
        manifest["server_exit_code"] = child.returncode if child else None
        manifest["binary_sha256_after"] = sha(server)
        save(out / "manifest.json", manifest)
    print(json.dumps({"status": manifest["status"], "half_gpu_layers": blocks // 2, "primary_runs": 0}))


if __name__ == "__main__":
    main()
