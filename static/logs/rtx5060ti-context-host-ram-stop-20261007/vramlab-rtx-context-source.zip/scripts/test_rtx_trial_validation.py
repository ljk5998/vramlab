#!/usr/bin/env python3
"""Synthetic FULL-TRIAL evidence controls; NO GPU/model/backend is executed.

Passing these tests establishes parser/audit behavior on fabricated files only.
It is not a hardware measurement, a real model hash verification or a clean-room
reader replay. Mutations refresh the raw hash ledger deliberately, so semantic
controls cannot accidentally pass by catching only a stale file hash.
"""
import copy
import json
from pathlib import Path
import shutil
import tempfile
import unittest

from validate_rtx_trial import COMMON_FLAGS, canonical_hash, digest, validate


SCRIPT_NAMES = ("rtx_measure.py", "validate_rtx_trial.py", "guard_rtx.py", "prepare_rtx.py", "snapshot_rtx_runtime.py", "check_package.py")


def temporary():
    # Windows sandbox's inherited system TEMP can create an inaccessible folder.
    # Keep synthetic files and tempfile's cleanup inside this owned workspace.
    root = Path(__file__).resolve().parent / ".synthetic-test-temp"
    root.mkdir(exist_ok=True)
    return tempfile.TemporaryDirectory(dir=root)


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def load(path):
    return json.loads(path.read_text())


class Evidence:
    """Construct physically fabricated evidence with independently chosen values."""
    def __init__(self, root, context=2048, layers="all", phase="scout"):
        self.package = root / "synthetic-package"
        self.context, self.layers, self.phase = context, layers, phase
        self.out = self.package / "data/rtx/synthetic-batch" / "trial-01" if phase == "primary" else self.package / "data/rtx/synthetic-trial"
        self.out.mkdir(parents=True)
        self.runtime_root = self.out.parent if phase == "primary" else self.out
        self.protocol_path = self.package / "synthetic-protocol.json" if phase == "primary" else None
        self.server_path = "/synthetic/package/data/rtx/reproduction-synthetic/build/bin/llama-server" if phase == "reader" else "/synthetic/build/bin/llama-server"
        library_path = self.server_path.removesuffix("llama-server") + "libggml-cuda.so"
        lock = {"llama_cpp": {"commit": "e5a8d439cef31f27fad6938233da10dae1ba5631"},
                "model": {"filename": "Qwen3-8B-Q4_K_M.gguf", "bytes": 5027783488,
                          "sha256": "d98cdcbd03e17ce47681435b5150e34c1417f50b5c0019dd560e4882c5745785",
                          "revision": "7c41481f57cb95916b40956ab2f0b139b296d974"}}
        write(self.package / "inputs.lock.json", lock)
        for name in SCRIPT_NAMES:
            path = self.package / "scripts" / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text("# SYNTHETIC binding identity only; never executed\n")
        for capacity in (2048, 4096, 8192, 16384):
            write(self.package / f"fixtures/rtx-tokens-{capacity}.json", list(range(capacity - 256)))
        (self.package / "fixtures/rtx-notebook.txt").write_text("SYNTHETIC TEST NOTEBOOK; NOT MODEL OUTPUT\n")
        write(self.package / "fixtures/rtx-tokenizer.json", {"tokens": list(range(17000))})
        self.runtime = {
            "time": 1700000000, "source_commit": lock["llama_cpp"]["commit"], "source_status": "",
            "files": {
                self.server_path: {"resolved": self.server_path, "bytes": 17888, "sha256": "1" * 64},
                library_path: {"resolved": library_path, "bytes": 1000000, "sha256": "2" * 64},
            },
            "input_verification": {
                "status": "PASS", "inputs_lock_sha256": digest(self.package / "inputs.lock.json"),
                "model": lock["model"],
                "scripts_sha256": {name: digest(self.package / "scripts" / name) for name in SCRIPT_NAMES},
                "fixtures_sha256": {path.name: digest(path) for path in sorted((self.package / "fixtures").glob("rtx-*"))},
                "flags_sha256": canonical_hash(COMMON_FLAGS),
            },
        }
        self.fingerprint = self.write_runtime("runtime-before.json", self.runtime)
        self.write_runtime("runtime-after.json", {**self.runtime, "time": 1700000100})
        self.result = {
            "schema_version": 1, "status": "completed_pending_validation", "phase": phase,
            "primary_eligible": phase == "primary", "context": context, "gpu_layers": layers,
            "source_commit": lock["llama_cpp"]["commit"], "model_sha256": lock["model"]["sha256"],
            "binary_before_sha256": "1" * 64, "binary_after_sha256": "1" * 64,
            "server_path": self.server_path,
            "fixture_sha256": digest(self.package / f"fixtures/rtx-tokens-{context}.json"),
            "runtime_binding_scope": "batch" if phase == "primary" else "trial",
            "runtime_before_sha256": digest(self.runtime_root / "runtime-before.json"),
            "runtime_after_sha256": digest(self.runtime_root / "runtime-after.json"),
            "input_binding_fingerprint": self.fingerprint, "input_verification_status": "PASS",
            "batch_post_pending": False, "failure_class": None,
            "raw_stability": "PASS",
            "exit_code": 0, "collector_error": None, "server_pid": 123,
            "startup_start_monotonic": 30, "startup_s": 2,
            "baseline": {"host_available_bytes": 5 * 1024**3, "gpu_used_mib": 1000.0},
            "protocol_sha256": None,
        }
        request = {"prompt": list(range(context - 256)), "stream": True, "cache_prompt": False,
                   "n_predict": 128, "temperature": 0, "seed": 20260910, "ignore_eos": True, "return_tokens": True}
        write(self.out / "request.json", request)
        command = [self.server_path, "--model", "/synthetic/package/data/rtx/models/Qwen3-8B-Q4_K_M.gguf", *COMMON_FLAGS,
                   "--ctx-size", str(context), "--gpu-layers", layers, "--port", "19091"]
        write(self.out / "command.json", command)
        write(self.out / "environment.json", {"CUDA_VISIBLE_DEVICES": "0", "GGML_CUDA_ENABLE_UNIFIED_MEMORY": None,
              "LD_LIBRARY_PATH": "/usr/local/cuda-13.2/lib64:/usr/lib/wsl/lib", "OMP_NUM_THREADS": "4"})
        offload = 37 if layers == "all" else 18
        # Independent fixture construction from locked head geometry and the
        # pinned 17/19 repeating-block placement; output has no KV cache.
        kv = context * 4096 * (36 if layers == "all" else 17) / 1024**2
        cpu_kv = context * 4096 * 19 / 1024**2
        log = (f"offloaded {offload}/37 layers to GPU\nn_ctx_seq = {context}\nflash_attn = enabled\n"
               f"CUDA0 model buffer size = 3000.00 MiB\nCUDA0 KV buffer size = {kv:.2f} MiB\n"
               "CUDA0 compute buffer size = 64.00 MiB\nK (f16) V (f16)\n")
        if layers == "18":
            log += f"CPU model buffer size = 2500.00 MiB\nCPU KV buffer size = {cpu_kv:.2f} MiB\n"
        (self.out / "server.log").write_text(log)
        write(self.out / "request-clock.json", {"monotonic": 32, "utc": "SYNTHETIC"})
        self.events = [
            {"received_monotonic": 32.1, "event": {"content": "", "tokens": [], "stop": False}},
            {"received_monotonic": 33, "event": {"content": "SYNTHETIC", "tokens": list(range(128)), "stop": False}},
            {"received_monotonic": 34, "event": {"content": "", "tokens": [], "stop": True,
                "tokens_evaluated": context - 256, "tokens_predicted": 128, "truncated": False, "stop_type": "limit",
                "timings": {"cache_n": 0, "prompt_n": context - 256, "predicted_n": 128,
                            "prompt_ms": 100, "predicted_ms": 1000, "predicted_per_second": 127}}},
        ]
        self.save_events()
        self.memory = [self.sample(t) for t in range(66)]
        self.save_memory()
        write(self.out / "post-health.json", {"status": "ok"})
        write(self.out / "gpu-process-accounting.json", {"exit_code": 0, "stdout": "123, N/A\n", "stderr": "",
              "scope": "SYNTHETIC WDDM query: deliberately unavailable; not zero VRAM"})
        if phase == "primary":
            self.protocol = {
                "status": "frozen_before_primary", "retained": [[context, layers]],
                "order": [{"id": self.out.name, "context": context, "gpu_layers": layers, "repetition": 1}],
                "flags": COMMON_FLAGS, "inputs_lock_sha256": digest(self.package / "inputs.lock.json"),
                "scripts_sha256": self.runtime["input_verification"]["scripts_sha256"],
                "fixtures_sha256": self.runtime["input_verification"]["fixtures_sha256"],
                "runtime_reference": self.runtime, "startup_budget_seconds": 120, "first_content_budget_seconds": 120,
                "request_budget_seconds": 180, "baseline_seconds": 30, "recovery_seconds": 30, "sample_cadence_seconds": 1,
                "baseline_vram_range_mib": 128, "baseline_host_ram_range_mib": 512, "baseline_gpu_util_median_max": 10,
                "cross_trial_vram_drift_mib": 256, "cross_trial_host_ram_drift_mib": 1024,
            }
            self.save_protocol()
        self.ledger()

    def write_runtime(self, name, runtime):
        path = self.runtime_root / name
        write(path, runtime)
        identity = {key: runtime[key] for key in ("source_commit", "source_status", "files", "input_verification")}
        fingerprint = canonical_hash(identity)
        write(path.with_name(name + ".verification.json"), {"status": "PASS", "runtime_sha256": digest(path),
              "input_binding_fingerprint": fingerprint})
        return fingerprint

    def save_protocol(self):
        write(self.protocol_path, self.protocol)
        self.result["protocol_sha256"] = digest(self.protocol_path)

    def rebind_runtime(self):
        self.result["input_binding_fingerprint"] = self.write_runtime("runtime-before.json", self.runtime)
        self.write_runtime("runtime-after.json", {**self.runtime, "time": 1700000100})
        self.result["runtime_before_sha256"] = digest(self.runtime_root / "runtime-before.json")
        self.result["runtime_after_sha256"] = digest(self.runtime_root / "runtime-after.json")

    def later_primary_trial(self):
        first = self.out
        later = first.parent / "trial-02"
        shutil.copytree(first, later)
        self.protocol["order"].append({"id": later.name, "context": self.context, "gpu_layers": self.layers, "repetition": 2})
        self.save_protocol()
        self.ledger()
        self.result = copy.deepcopy(self.result)
        self.out = later
        self.ledger()

    def sample(self, timestamp):
        phase = "baseline" if timestamp < 30 else "startup" if timestamp < 32 else "request" if timestamp < 35 else "shutdown" if timestamp == 35 else "recovery"
        active = phase in ("startup", "request", "shutdown")
        used = "5000" if active else "1000"
        gpu = {"total_mib": "8151", "used_mib": used, "temperature_c": "50", "utilization_percent": "40" if active else "0",
               "sm_mhz": "2000", "power_w": "100", "pstate": "P0"}
        rss = 1024**3 if active else None
        return {"phase": phase, "monotonic": timestamp, "epoch": 1700000000 + timestamp, "sample_duration_s": 0.01,
                "host": {"time": 1700000000 + timestamp, "abort": None, "available_ram_bytes": 5 * 1024**3,
                         "disk_free_bytes": 30 * 1024**3, "gpu": gpu, "gpu_raw": ", ".join(gpu.values()) + "\n"},
                "guest_available_bytes": 3 * 1024**3, "guest_swap_used_bytes": 0,
                "meminfo_raw": "MemAvailable: 3145728 kB\nSwapTotal: 1048576 kB\nSwapFree: 1048576 kB\n",
                "process_rss_bytes": rss, "process_hwm_bytes": rss,
                "process_status_raw": "Pid:\t123\nVmRSS:\t1048576 kB\nVmHWM:\t1048576 kB\n" if active else None,
                "guest_swap_counters_pages": {"pswpin": 0, "pswpout": 0}}

    def save_events(self):
        (self.out / "response.sse").write_text("".join("data: " + json.dumps(item["event"]) + "\n\n" for item in self.events))
        (self.out / "events.jsonl").write_text("".join(json.dumps(item) + "\n" for item in self.events))
        self.result["completion"] = {"request_start_monotonic": 32,
            "first_content_monotonic": self.events[1]["received_monotonic"],
            "final_monotonic": self.events[-1]["received_monotonic"],
            "ttft_s": self.events[1]["received_monotonic"] - 32,
            "completion_s": self.events[-1]["received_monotonic"] - 32,
            "final": self.events[-1]["event"]}

    def save_memory(self):
        (self.out / "memory.jsonl").write_text("".join(json.dumps(sample) + "\n" for sample in self.memory))

    def ledger(self):
        self.result["files_sha256"] = {path.name: digest(path) for path in self.out.iterdir() if path.is_file() and path.name != "result.json"}
        write(self.out / "result.json", self.result)

    def audit(self, **kwargs):
        return validate(self.out, self.protocol_path, package_root=self.package, **kwargs)


class FullTrialControls(unittest.TestCase):
    def setUp(self):
        self.temporary = temporary()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)

    def evidence(self, **kwargs):
        return Evidence(self.root, **kwargs)

    def reject(self, evidence, expected):
        evidence.ledger()
        with self.assertRaisesRegex(ValueError, expected):
            evidence.audit()

    def test_all_eight_fixed_conditions_have_valid_synthetic_contract(self):
        for capacity in (2048, 4096, 8192, 16384):
            for layers in ("all", "18"):
                with self.subTest(context=capacity, layers=layers), temporary() as directory:
                    ev = Evidence(Path(directory), capacity, layers)
                    receipt = ev.audit()
                    self.assertEqual(receipt["status"], "raw_checks_passed")
                    self.assertEqual(receipt["offloaded_layers"], 37 if layers == "all" else 18)
                    self.assertEqual(receipt["metrics"]["global_vram_sampled_peak_mib"], 5000)
                    self.assertEqual(receipt["metrics"]["global_vram_peak_minus_baseline_mib"], 4000)
                    self.assertIn("not process VRAM", receipt["metrics"]["global_vram_scope"])
                    observed = {(row["backend"], row["kind"]): row["mib"] for row in receipt["metrics"]["buffers"]}
                    expected_gpu = {2048: 136, 4096: 272, 8192: 544, 16384: 1088} if layers == "18" else {2048: 288, 4096: 576, 8192: 1152, 16384: 2304}
                    self.assertEqual(observed["CUDA0", "KV"], expected_gpu[capacity])
                    if layers == "18":
                        self.assertEqual(observed["CPU", "KV"], {2048: 152, 4096: 304, 8192: 608, 16384: 1216}[capacity])

    def test_strict_primary_checks_frozen_protocol_and_batch_prepost(self):
        ev = self.evidence(phase="primary")
        self.assertEqual(ev.audit()["runtime_post_check"], "pre_post_binding_verified")

    def test_reader_replay_is_separate_fresh_2k_all_trial(self):
        ev = self.evidence(phase="reader")
        receipt = ev.audit()
        self.assertEqual(receipt["phase"], "reader")
        self.assertEqual(receipt["input_tokens"], 1792)
        self.assertFalse(ev.result["primary_eligible"])

    def test_reader_other_condition_is_rejected(self):
        for context, layers in ((4096, "all"), (2048, "18")):
            with self.subTest(context=context, layers=layers), temporary() as directory:
                ev = Evidence(Path(directory), context, layers, "reader")
                self.reject(ev, "Reader replay requires 2K/all")

    def test_reader_cannot_claim_primary_eligibility(self):
        ev = self.evidence(phase="reader")
        ev.result["primary_eligible"] = True
        self.reject(ev, "Primary classification mismatch")

    def test_reader_ordinary_build_path_is_rejected(self):
        ev = self.evidence(phase="reader")
        ev.result["server_path"] = "/synthetic/build/bin/llama-server"
        command = load(ev.out / "command.json")
        command[0] = ev.result["server_path"]
        write(ev.out / "command.json", command)
        self.reject(ev, "Reader server is not a fresh reproduction build path")

    def test_declared_server_must_equal_actual_command(self):
        ev = self.evidence()
        ev.result["server_path"] = "/synthetic/other/build/bin/llama-server"
        self.reject(ev, "Declared server path differs")

    def test_server_binary_must_be_bound_at_exact_executed_path(self):
        ev = self.evidence()
        ev.runtime["files"][ev.server_path]["sha256"] = "4" * 64
        ev.rebind_runtime()
        self.reject(ev, "Executed binary not runtime-bound")

    def test_missing_dependency_script_binding_is_rejected_with_fresh_receipts(self):
        ev = self.evidence()
        del ev.runtime["input_verification"]["scripts_sha256"]["check_package.py"]
        ev.rebind_runtime()
        self.reject(ev, "script binding coverage mismatch")

    def test_unclosed_raw_writers_are_rejected(self):
        ev = self.evidence()
        ev.result["raw_stability"] = "FAIL"
        self.reject(ev, "Raw writers did not establish stable closure")

    def test_loader_environment_mismatch_is_rejected(self):
        ev = self.evidence()
        env = load(ev.out / "environment.json")
        env["LD_LIBRARY_PATH"] = "/synthetic/unbound-libraries"
        write(ev.out / "environment.json", env)
        self.reject(ev, "Loader/thread environment differs")

    def test_wrong_model_argument_is_rejected_even_when_metadata_claims_locked_hash(self):
        ev = self.evidence()
        command = load(ev.out / "command.json")
        command[command.index("--model") + 1] = "/synthetic/package/data/rtx/models/other.gguf"
        write(ev.out / "command.json", command)
        self.reject(ev, "Executed model path differs")

    def test_decode_throughput_is_recomputed_from_raw_timing(self):
        ev = self.evidence()
        ev.events[-1]["event"]["timings"]["predicted_per_second"] = 256
        ev.save_events()
        self.reject(ev, "Decode timing/throughput arithmetic mismatch")

    def test_old_128_step_decode_rate_is_rejected_with_fresh_hashes(self):
        ev = self.evidence()
        ev.events[-1]["event"]["timings"]["predicted_per_second"] = 128
        ev.save_events()
        self.reject(ev, "Decode timing/throughput arithmetic mismatch")

    def test_missing_fixture_binding_is_rejected_with_fresh_receipts(self):
        ev = self.evidence()
        del ev.runtime["input_verification"]["fixtures_sha256"]["rtx-tokenizer.json"]
        ev.rebind_runtime()
        self.reject(ev, "Fixture binding coverage mismatch")

    def test_pending_flag_cannot_be_kept_after_post_binding_exists(self):
        ev = self.evidence(phase="primary")
        ev.result["batch_post_pending"] = True
        self.reject(ev, "Batch post-binding pending state mismatch")

    def test_repeated_heartbeat_reads_count_as_one_gpu_observation(self):
        ev = self.evidence()
        originals = copy.deepcopy(ev.memory)
        for sample in ev.memory:
            sample["host"] = copy.deepcopy(originals[(sample["monotonic"] // 4) * 4]["host"])
        ev.save_memory()
        ev.ledger()
        metrics = ev.audit()["metrics"]
        self.assertEqual(metrics["telemetry_samples"], 66)
        self.assertEqual(metrics["unique_host_heartbeat_queries"], 17)
        self.assertEqual(metrics["max_effective_gpu_gap_s"], 4)

    def test_same_heartbeat_timestamp_cannot_have_different_data(self):
        ev = self.evidence()
        ev.memory[31]["host"]["time"] = ev.memory[30]["host"]["time"]
        ev.memory[31]["host"]["gpu"]["used_mib"] = "5001"
        ev.memory[31]["host"]["gpu_raw"] = ", ".join(ev.memory[31]["host"]["gpu"].values()) + "\n"
        ev.save_memory()
        self.reject(ev, "conflicting observations")

    def test_effective_gpu_gap_can_fail_with_individually_fresh_reads(self):
        ev = self.evidence()
        for sample in ev.memory[1:9]:
            sample["host"] = copy.deepcopy(ev.memory[0]["host"])
        ev.save_memory()
        self.reject(ev, "Effective GPU heartbeat gap")

    def test_cross_trial_baseline_drift_is_recomputed_from_first_raw_trial(self):
        for gpu_delta, ram_delta in ((257, 0), (0, 1024**3 + 1)):
            with self.subTest(gpu_delta=gpu_delta, ram_delta=ram_delta), temporary() as directory:
                ev = Evidence(Path(directory), phase="primary")
                ev.later_primary_trial()
                for sample in ev.memory:
                    if sample["phase"] in ("baseline", "recovery"):
                        sample["host"]["available_ram_bytes"] += ram_delta
                        sample["host"]["gpu"]["used_mib"] = str(float(sample["host"]["gpu"]["used_mib"]) + gpu_delta)
                        sample["host"]["gpu_raw"] = ", ".join(sample["host"]["gpu"].values()) + "\n"
                ev.result["baseline"]["host_available_bytes"] += ram_delta
                ev.result["baseline"]["gpu_used_mib"] += gpu_delta
                ev.save_memory()
                self.reject(ev, "Cross-trial baseline drift")

    def test_provisional_primary_is_labeled_and_cannot_pass_strict_final(self):
        ev = self.evidence(phase="primary")
        (ev.runtime_root / "runtime-after.json").unlink()
        (ev.runtime_root / "runtime-after.json.verification.json").unlink()
        ev.result.update(runtime_after_sha256=None, batch_post_pending=True)
        ev.ledger()
        self.assertEqual(ev.audit(allow_pending_batch_post=True)["status"], "trial_checks_passed_batch_post_pending")
        self.reject(ev, "Post-runtime binding missing")

    def test_finished_primary_without_protocol_is_rejected(self):
        ev = self.evidence(phase="primary")
        with self.assertRaisesRegex(ValueError, "Primary requires frozen protocol"):
            validate(ev.out, package_root=ev.package)

    def test_eos_early_stop_is_rejected_semantically(self):
        ev = self.evidence()
        ev.events[-1]["event"]["stop_type"] = "eos"
        ev.save_events()
        self.reject(ev, "Unexpected completion boundary")

    def test_output_under_and_overrun_are_rejected_semantically(self):
        for count in (127, 129):
            with self.subTest(count=count), temporary() as directory:
                ev = Evidence(Path(directory))
                ev.events[1]["event"]["tokens"] = list(range(count))
                ev.events[-1]["event"]["tokens_predicted"] = count
                ev.events[-1]["event"]["timings"]["predicted_n"] = count
                ev.save_events()
                self.reject(ev, "Output count mismatch")

    def test_stream_token_mismatch_is_not_hidden_by_final_counter(self):
        ev = self.evidence()
        ev.events[1]["event"]["tokens"].pop()
        ev.save_events()
        self.reject(ev, "Stream tokens mismatch")

    def test_input_counter_mismatch_is_rejected_semantically(self):
        ev = self.evidence()
        ev.events[-1]["event"]["tokens_evaluated"] -= 1
        ev.save_events()
        self.reject(ev, "Evaluated input mismatch")

    def test_prompt_reuse_is_rejected_semantically(self):
        ev = self.evidence()
        ev.events[-1]["event"]["timings"]["cache_n"] = 1
        ev.save_events()
        self.reject(ev, "Timing token counts mismatch")

    def test_truncation_is_rejected_semantically(self):
        ev = self.evidence()
        ev.events[-1]["event"]["truncated"] = True
        ev.save_events()
        self.reject(ev, "Unexpected completion boundary")

    def test_duplicate_final_is_rejected(self):
        ev = self.evidence()
        ev.events.append(copy.deepcopy(ev.events[-1]))
        ev.save_events()
        self.reject(ev, "duplicate/nonterminal final")

    def test_nonterminal_final_is_rejected(self):
        ev = self.evidence()
        ev.events.append({"received_monotonic": 35, "event": {"content": "", "stop": False}})
        ev.save_events()
        self.reject(ev, "duplicate/nonterminal final")

    def test_effective_layer_count_mismatch_is_rejected(self):
        ev = self.evidence()
        path = ev.out / "server.log"
        path.write_text(path.read_text().replace("37/37", "18/37"))
        self.reject(ev, "Incorrect GPU offload")

    def test_cuda_kv_buffer_mismatch_is_rejected(self):
        ev = self.evidence()
        path = ev.out / "server.log"
        path.write_text(path.read_text().replace("KV buffer size = 288.00", "KV buffer size = 144.00"))
        self.reject(ev, "CUDA KV allocation mismatch")

    def test_partial_cpu_kv_buffer_mismatch_is_rejected(self):
        ev = self.evidence(layers="18")
        path = ev.out / "server.log"
        path.write_text(path.read_text().replace("CPU KV buffer size = 152.00", "CPU KV buffer size = 144.00"))
        self.reject(ev, "CPU KV allocation mismatch")

    def test_old_balanced_partial_kv_is_rejected_with_fresh_hashes(self):
        ev = self.evidence(layers="18")
        path = ev.out / "server.log"
        path.write_text(path.read_text().replace("CUDA0 KV buffer size = 136.00", "CUDA0 KV buffer size = 144.00")
                       .replace("CPU KV buffer size = 152.00", "CPU KV buffer size = 144.00"))
        self.reject(ev, "CUDA KV allocation mismatch")

    def test_missing_partial_host_kv_is_rejected_with_fresh_hashes(self):
        ev = self.evidence(layers="18")
        path = ev.out / "server.log"
        path.write_text(path.read_text().replace("CPU KV buffer size = 152.00 MiB\n", ""))
        self.reject(ev, "CPU KV allocation mismatch")

    def test_quantized_kv_is_rejected_even_when_flags_claim_f16(self):
        ev = self.evidence()
        path = ev.out / "server.log"
        path.write_text(path.read_text().replace("K (f16)", "K (q8_0)"))
        self.reject(ev, "F16 KV types")

    def test_missing_value_cache_type_is_rejected(self):
        ev = self.evidence()
        path = ev.out / "server.log"
        path.write_text(path.read_text().replace("V (f16)", "K (f16)"))
        self.reject(ev, "F16 KV types")

    def test_negative_returned_token_id_is_rejected(self):
        ev = self.evidence()
        ev.events[1]["event"]["tokens"][0] = -1
        ev.save_events()
        self.reject(ev, "Malformed returned token list")

    def test_autofit_runtime_message_is_rejected(self):
        ev = self.evidence()
        path = ev.out / "server.log"
        path.write_text(path.read_text() + "common_init_result: fitting params to device memory\n")
        self.reject(ev, "Automatic fitting")

    def test_wrong_capacity_is_rejected_even_when_request_is_complete(self):
        ev = self.evidence()
        path = ev.out / "server.log"
        path.write_text(path.read_text().replace("n_ctx_seq = 2048", "n_ctx_seq = 4096"))
        self.reject(ev, "Effective context mismatch")

    def test_stale_host_telemetry_is_rejected(self):
        ev = self.evidence()
        ev.memory[32]["host"]["time"] -= 9
        ev.save_memory()
        self.reject(ev, "Stale host telemetry")

    def test_telemetry_gap_is_rejected(self):
        ev = self.evidence()
        ev.memory = [sample for sample in ev.memory if sample["monotonic"] not in (10, 11, 12)]
        ev.save_memory()
        self.reject(ev, "Telemetry cadence/gap")

    def test_raw_guest_memory_mismatch_is_rejected(self):
        ev = self.evidence()
        ev.memory[32]["guest_available_bytes"] += 1024
        ev.save_memory()
        self.reject(ev, "Raw guest available RAM mismatch")

    def test_raw_process_rss_mismatch_is_rejected(self):
        ev = self.evidence()
        ev.memory[32]["process_rss_bytes"] += 1024
        ev.save_memory()
        self.reject(ev, "Raw process RSS/HWM mismatch")

    def test_shutdown_zombie_and_dead_process_memory_is_unavailable_not_zero(self):
        for state in ("Z", "X"):
            with self.subTest(state=state), temporary() as directory:
                ev = Evidence(Path(directory))
                sample = ev.memory[35]
                sample.update(process_rss_bytes=None, process_hwm_bytes=None,
                              process_status_raw=f"Pid:\t123\nState:\t{state} (terminated)\n")
                ev.save_memory()
                ev.ledger()
                receipt = ev.audit()
                self.assertEqual(receipt["metrics"]["process_rss_sampled_peak_bytes"], 1024**3)
                self.assertIsNone(ev.memory[35]["process_rss_bytes"])

    def test_live_process_missing_vm_fields_is_rejected(self):
        for state in ("R", "S"):
            with self.subTest(state=state), temporary() as directory:
                ev = Evidence(Path(directory))
                ev.memory[35].update(process_rss_bytes=None, process_hwm_bytes=None,
                                    process_status_raw=f"Pid:\t123\nState:\t{state} (live)\n")
                ev.save_memory()
                self.reject(ev, "Process memory availability inconsistent")

    def test_unavailable_zombie_status_with_wrong_pid_is_rejected(self):
        ev = self.evidence()
        ev.memory[35].update(process_rss_bytes=None, process_hwm_bytes=None,
                            process_status_raw="Pid:\t124\nState:\tZ (zombie)\n")
        ev.save_memory()
        self.reject(ev, "Process memory availability inconsistent")

    def test_null_parsed_memory_cannot_hide_raw_vm_fields(self):
        for field in ("VmRSS", "VmHWM"):
            with self.subTest(field=field), temporary() as directory:
                ev = Evidence(Path(directory))
                ev.memory[35].update(process_rss_bytes=None, process_hwm_bytes=None,
                                    process_status_raw=f"Pid:\t123\nState:\tZ (zombie)\n{field}:\t0 kB\n")
                ev.save_memory()
                self.reject(ev, "Process memory availability inconsistent")

    def test_raw_gpu_memory_mismatch_is_rejected(self):
        ev = self.evidence()
        ev.memory[32]["host"]["gpu"]["used_mib"] = "5001"
        ev.save_memory()
        self.reject(ev, "Raw GPU telemetry differs")

    def test_baseline_busy_is_rejected(self):
        ev = self.evidence()
        for sample in ev.memory[:30]:
            sample["host"]["gpu"]["utilization_percent"] = "11"
            sample["host"]["gpu_raw"] = ", ".join(sample["host"]["gpu"].values()) + "\n"
        ev.save_memory()
        self.reject(ev, "Baseline GPU busy")

    def test_first_content_over_budget_is_rejected(self):
        ev = self.evidence()
        ev.events[1]["received_monotonic"] = 153
        ev.events[-1]["received_monotonic"] = 154
        ev.save_events()
        self.reject(ev, "Request exceeded budgets")

    def test_total_request_over_budget_after_early_content_is_rejected(self):
        ev = self.evidence()
        ev.events[-1]["received_monotonic"] = 213
        ev.save_events()
        self.reject(ev, "Request exceeded budgets")

    def test_metadata_used_as_ttft_is_rejected(self):
        ev = self.evidence()
        ev.result["completion"]["first_content_monotonic"] = 32.1
        ev.result["completion"]["ttft_s"] = 0.1
        self.reject(ev, "latency arithmetic mismatch")

    def test_unclean_or_escalated_shutdown_is_rejected(self):
        ev = self.evidence()
        ev.result["shutdown_escalated"] = True
        self.reject(ev, "Unclean server exit")

    def test_changed_post_runtime_closure_is_rejected_even_with_valid_sidecar(self):
        ev = self.evidence()
        after = copy.deepcopy(ev.runtime)
        after["files"]["/synthetic/build/bin/libggml-cuda.so"]["sha256"] = "3" * 64
        ev.write_runtime("runtime-after.json", after)
        ev.result["runtime_after_sha256"] = digest(ev.runtime_root / "runtime-after.json")
        self.reject(ev, "Runtime/input closure changed")

    def test_false_verification_sidecar_is_rejected(self):
        ev = self.evidence()
        sidecar = ev.runtime_root / "runtime-before.json.verification.json"
        record = load(sidecar)
        record["status"] = "FAIL"
        write(sidecar, record)
        self.reject(ev, "verification sidecar mismatch")

    def test_current_inputs_lock_change_is_rejected_against_frozen_primary(self):
        ev = self.evidence(phase="primary")
        lock = load(ev.package / "inputs.lock.json")
        lock["model"]["revision"] = "changed"
        write(ev.package / "inputs.lock.json", lock)
        self.reject(ev, "Frozen input lock changed")

    def test_frozen_script_change_is_rejected(self):
        ev = self.evidence(phase="primary")
        (ev.package / "scripts/rtx_measure.py").write_text("# changed\n")
        self.reject(ev, "Frozen scripts changed")

    def test_missing_required_raw_manifest_entry_is_rejected(self):
        ev = self.evidence()
        del ev.result["files_sha256"]["memory.jsonl"]
        write(ev.out / "result.json", ev.result)
        with self.assertRaisesRegex(ValueError, "omitted from hash manifest"):
            ev.audit()

    def test_safe_file_hash_tampering_is_rejected_when_semantics_unchanged(self):
        ev = self.evidence()
        (ev.out / "server.log").write_text((ev.out / "server.log").read_text() + "# harmless altered bytes\n")
        with self.assertRaisesRegex(ValueError, "Raw file hash mismatch"):
            ev.audit()


if __name__ == "__main__":
    unittest.main()
