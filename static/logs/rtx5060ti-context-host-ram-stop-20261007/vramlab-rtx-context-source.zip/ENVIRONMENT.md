# Recorded environment and execution boundaries

These values describe the installed lab used for the original scouts and the
stopped bounded-v1 primary attempt. They do not describe an installation created
by this archive. The separate reader's fresh build and one 2048/all request subsequently
completed, with guard exits 0, strict raw checks and matched pre/post bindings. The subsequent copied-package
no-GPU controls ran on Windows Python 3.12.14: 155 passed and 1 skipped out of
156. All 21 source assets stayed unchanged.

## Current evidence boundary

Six same-v4 scouts had original strict raw validation, matched pre/post input
and runtime bindings, and host/guest guard exits of 0 without abort. They provide
**one descriptive observation per condition**, n=1, for 2K/4K/8K × all/18. They
are not three-repeat measurements and are not mixed with older cohorts.

The original eight-condition contract is **NOT_MET**. The 16K/18 attempt stopped
at the hard host RAM floor without original post-binding; 16K/all was **NOT_RUN**.
The narrower eighteen-trial bounded-v1 primary contract is also **NOT_MET**.
Its host guard recorded `host_ram_below_2gib`, exit 124 and about 900.578 seconds.
Six original trial calls existed, five had provisional checks pending batch
post-binding, and the batch runtime-after snapshot was absent. **Final eligible
primary trials: 0.** No primary performance aggregate is permitted.

Missing post-binding remains missing. A later snapshot or cleanup inventory
cannot make the original incomplete attempt a final validated workload result.
The host safety stop is not an OOM or maximum-model-capacity claim. The archived
source preserves the attempted contract; it does not advertise its success.

## Recorded installed environment

| Item | Recorded value |
|---|---|
| Host | Windows 11 Home; WSL output reported build `10.0.26200.9457` |
| CPU | AMD Ryzen 7 7800X3D |
| Windows total visible physical memory | 15,603,676 KiB, approximately 14.88 GiB |
| GPU | RTX 5060 Ti 8 GB; NVIDIA total-memory counter 8,151 MiB |
| Windows NVIDIA driver | `610.88` |
| WSL | `2.7.12.0`; packaged kernel label `6.18.33.2-2` |
| Actual guest kernel release | `6.18.33.2-microsoft-standard-WSL2` |
| Guest | Ubuntu 24.04.4 LTS, Linux x86-64 |
| Recorded GCC | `13.3.0` |
| Recorded CUDA compiler | release `13.2`, `V13.2.86` |
| Recorded CMake | `3.28.3`; Ninja generator |
| Original build | Release; `GGML_CUDA=ON`, `GGML_NATIVE=ON`, CUDA architecture `120-real` |

The kernel labels came from different commands. Windows visible memory is not
model RSS or a WSL memory limit. Driver capability is not a CUDA Toolkit version.
Compiler values came from preserved version/build records. Separate terminal
receipts, rather than those version fields, prove that the reader build finished.

## Locked external inputs

| Input | Frozen value |
|---|---|
| llama.cpp commit | `e5a8d439cef31f27fad6938233da10dae1ba5631` |
| Model repository | `Qwen/Qwen3-8B-GGUF` |
| Model revision | `7c41481f57cb95916b40956ab2f0b139b296d974` |
| GGUF | `Qwen3-8B-Q4_K_M.gguf` |
| Size | 5,027,783,488 bytes |
| SHA-256 | `d98cdcbd03e17ce47681435b5150e34c1417f50b5c0019dd560e4882c5745785` |

The pinned [llama.cpp source](https://github.com/ggml-org/llama.cpp/tree/e5a8d439cef31f27fad6938233da10dae1ba5631)
and [model revision](https://huggingface.co/Qwen/Qwen3-8B-GGUF/tree/7c41481f57cb95916b40956ab2f0b139b296d974)
are external dependencies. Their source/model bytes are not archive assets.

The unchanged lock retains four context inputs and its initial
`prepared_not_measured` status. That historical field is not the current result
count. The separate frozen bounded-v1 protocol prospectively selected
2K/4K/8K × all/18 with three repetitions each, eighteen planned trials. The 16K
fixture remains in the source lock; it does not turn the incomplete diagnosis
into a valid primary result. No original lock or measurement flag was relaxed
after either host safety stop.

## Requirements outside the archive

No-GPU controls need Python 3.11+, writable temporary storage and loopback HTTP.
They use synthetic data and the standard library. Installed driver controls
passed 64/64 on Linux and 63 with 1 skipped on Windows. Those installed-lab counts are separate from the subsequent copied-package
Windows control run. The assembled source package subsequently
ran 29 collector, 60 raw-validator, 3 setup and 64 scope-driver controls:
156 run, 155 passed, 1 Windows symlink-permission skip. Those code controls did
not run a model, start WSL, or complete the reader. The copy-phase manifest's
`CONTROLS_PENDING` state is historical; the later receipt records the controls.

GPU execution additionally requires Windows, WSL2, Linux `fcntl`, Windows/guest
`nvidia-smi`, Bash, Git, CMake, Ninja, GNU C++ and the CUDA compiler. It requires
the external model/source, verified original build/runtime and a dedicated
registered guest. The archive does not install or download them.

`PACKAGE_WINDOWS` and `PACKAGE_WSL` are placeholders for the same prepared
package as seen by the host and guest. Registration must point exactly to
`PACKAGE_WINDOWS/data/rtx/distro`. Copying source elsewhere cannot implicitly
reuse that registration. Runtime fingerprints contain installation-specific
paths and resolved library hashes; identical source/settings do not make a
different installation's fingerprint equal.

## Preserved attempted measurement contract

Each original callable starts one new server for one raw request, with F16 K/V,
Flash Attention on, one slot, batch/ubatch 512/128 and four threads. Input count
is capacity minus 256; completion requires 128 output tokens. Capacity and input
length change together. The pinned server's decode rate uses 127 decode
intervals for those 128 outputs. With `--gpu-layers 18`, the output layer counts
toward offload; repeating KV blocks divide as 17 GPU and 19 CPU.

The ancillary driver prospectively adds a complete model size/SHA read before
each original trial call, then separately recorded idle observations. The read
uses 8 MiB chunks with a cooperative 120-second deadline checked before/after
each chunk under the outer guard. It can warm file caches; it does not guarantee
stable host RAM. Idle windows last 30 seconds, at most ten within 300 elapsed
seconds. They are not retries of a model request.

The original 30-second baseline and recovery remain unchanged. Baseline limits
are RAM spread 512 MiB, device-wide VRAM spread 128 MiB and median GPU utilization
10%. Cross-trial drift limits are 1 GiB RAM/256 MiB VRAM. Startup, first-content
and total-request budgets are 120/120/180 seconds. Hard host floors are 2 GiB
available RAM and 5 GiB free work disk. The total-request budget includes TTFT.

The internal batch field stays `390 * 18 + 900 = 7920` seconds. The actual outer
guard is `810 * 18 + 900 = 15480`, including added read/idle budgets. The earlier
690-based plan was superseded before primary execution. The ancillary driver
has a separate SHA binding from the original six-script input fingerprint.

Device-wide WDDM VRAM includes other applications; peak minus baseline is not
process VRAM. RSS/host RAM/guest swap have different scopes. A validated Z/X
process-exit boundary may have null RSS/HWM, which is unavailable rather than
zero. Single scout values do not establish stable repeat performance.

## Separate reader boundary

The reader uses the existing prepared guest, pinned source/model and toolchain.
Its fresh build is `PACKAGE_WSL/data/rtx/reproduction-20261007/build`, separate
from the original build. Its driver permits one 2048/all trial under a
600-second guard and requires fresh output plus pre/post verification.

The separate build guard completed with exit 0 after 1294.969 seconds. The
request guard completed with exit 0 after 138.204 seconds. Guest guard exits and
server exit were also 0; the reader receipt was `validated_reader_only` with
`success: true`, `raw_checks_passed` and pre/post input/runtime bindings. The
request used 1792 input and 128 output tokens. Whole-guard durations include
verification/collection work and are not request latency or TTFT. This one
reader check remains a same-environment fresh-build replay,
not reproduction on a clean OS, new computer, independent toolchain or cold
file cache. It never becomes a primary repetition or repairs its missing
post-binding.
