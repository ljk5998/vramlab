# VRAMLab RTX context source archive

Author: Sinhyeok Lee.

This archive contains source, a locked external-input description and synthetic
fixtures for a stopped RTX context experiment. It supports code inspection and
no-GPU controls. Its GPU entry points require the existing prepared Windows/WSL
lab. It is not a portable installer or an operating-system image.

**Packaged no-GPU controls: 155 passed, 1 skipped, 156 run.** The 21 experiment
assets were assembled and remained unchanged during the Windows Python 3.12.14
control run. Final ZIP extraction reproduced every packaged byte. The GNU checksum command
below was not rerun; packaging used Python SHA-256 comparison. This archive is
unpublished, with no live download URL claimed. The source manifest's
initial `CONTROLS_PENDING` state records the copy phase; the later control receipt
records subsequent execution without rewriting that historical manifest.

## Experiment status at this preparation cutoff

| Evidence group | Actual status | Permitted interpretation |
|---|---|---|
| Original eight-condition design | NOT_MET | 16K/18 stopped at the host RAM safety floor without original post-binding; 16K/all was NOT_RUN |
| Six same-v4 scouts, 2K/4K/8K × all/18 | Six original fully validated scouts | One descriptive observation per condition, n=1; no repeated-run summary or ranking |
| Prospective bounded-v1 primary, 18 planned trials | NOT_MET; final eligible primary trials: 0 | Six original trial calls were recorded; five provisional checks remained pending batch post-binding when the host floor stopped the batch |
| Separate fresh-build reader | Validated reader-only success; 2048/all, 1792 input and 128 output tokens | One same-lab fresh-build check; not a primary repetition or clean-OS reproduction |

The primary host guard recorded `host_ram_below_2gib` and exit 124 after about
900.578 seconds. The batch runtime-after snapshot was absent. Provisional checks
do not become final validated primary results, even when a request returned all
128 outputs. Primary performance values remain null. Missing values are not
zeroes. The 16K diagnosis and primary stop do not establish model capacity,
an OOM failure, or a throughput result.

Source files retain their original behavior and history. The `bounded-v1` driver
remains in the package for inspection of the failed prospective contract; its
presence does not imply that its eighteen-trial protocol succeeded.

## Contents

The experiment whitelist contains **21 files**. Documentation and archive
manifests are separate packaging files.

| Group | Files |
|---|---|
| Pinned engine, 6 | `rtx_measure.py`, `validate_rtx_trial.py`, `guard_rtx.py`, `prepare_rtx.py`, `snapshot_rtx_runtime.py`, `check_package.py` |
| Reader helpers, 3 | `build_rtx_reader.sh`, `snapshot_rtx_reader.py`, `run_rtx_reader.py` |
| Prospective scope driver, 1 | `rtx_bounded_scope.py` |
| No-GPU controls, 4 | `test_rtx_measure.py`, `test_rtx_trial_validation.py`, `test_rtx_setup.py`, `test_rtx_bounded_scope.py` |
| Synthetic fixtures, 6 | `rtx-notebook.txt`, `rtx-tokenizer.json`, `rtx-tokens-{2048,4096,8192,16384}.json` |
| External input lock, 1 | `inputs.lock.json` |

Scripts are under `scripts/`; fixtures are under `fixtures/`. The notebook is
invented material. `rtx-tokenizer.json` has a `tokens` array; each capacity
fixture is its saved `capacity - 256` prefix. This workload does not test answer
quality.

The model, llama.cpp checkout, CUDA/toolchain, binaries, libraries, build trees,
WSL disks/rootfs, private handoffs and original runtime/guard evidence are absent.
Nothing here installs them. [ENVIRONMENT.md](ENVIRONMENT.md) records the
environment and execution boundaries.

## Source integrity

From the extracted archive root, on a system with GNU coreutils:

```sh
sha256sum --check SHA256SUMS.txt
```

The checksum list covers the 21 experiment assets and final packaging documents,
excluding the checksum file itself. `source-manifest.json`
records relative path, bytes, original/exported SHA-256 and transformation.
Exact source exports must have matching hashes and `transformation: none`.
`packaging-evidence.json` records selected subsequent control, reader and failed-
primary receipt fields with source hashes; it contains no original console logs.
The external `SOURCE_ARCHIVE_MANIFEST.json` and extraction receipt bind this ZIP
and its extracted members. These checks verify package bytes; they do not
complete the primary contract or validate all private raw evidence.

## No-GPU controls

Use Python 3.11 or newer and a writable extracted copy. The standard-library
controls use small synthetic files; SSE controls also use a local loopback HTTP
server. From the archive root:

```sh
python3 -c "import pathlib,tempfile,unittest; p=pathlib.Path('.synthetic-test-temp').resolve(); p.mkdir(exist_ok=True); tempfile.tempdir=str(p); s=unittest.defaultTestLoader.discover('scripts',pattern='test_rtx_*.py'); r=unittest.TextTestRunner(verbosity=2).run(s); raise SystemExit(not r.wasSuccessful())"
```

On Windows, substitute `python` for `python3`. Discovery covers all four control
files. `test_rtx_setup.py` supplies the loopback fixture imported by collector
controls. The controls do not load the external model, start llama-server, build
CUDA code or start a WSL distribution.

The installed scope-driver controls passed **64/64 on Linux**. The Windows run
passed **63 with 1 skipped** because symbolic-link creation was not permitted.
Those are installed-lab control results. The subsequent copied-package run used
Windows Python 3.12.14:

| Suite | Tests run | Passed | Skipped |
|---|---:|---:|---:|
| Collector | 29 | 29 | 0 |
| Raw validator | 60 | 60 | 0 |
| Setup | 3 | 3 | 0 |
| Scope driver | 64 | 63 | 1 |
| Total | 156 | 155 | 1 |

The skip concerns Windows symbolic-link permission. All 21 source assets stayed
unchanged. This does not claim that the literal example command above or a
different platform was tested. Control success is not a GPU result, a reader
replay, a final primary PASS, or an article review round. Failed earlier harness
attempts were retained; those were control-harness failures, not model retries.

## Prepared-lab interfaces and limits

The Windows guard requires the exact registered `VRAMLab-RTX-Context` WSL2 guest.
Its registered BasePath must equal the executing package's `data/rtx/distro`.
Moving the archive does not move or register a guest, so these sources alone
cannot make GPU commands runnable in a new directory.

`rtx_bounded_scope.py` has `freeze` and `primary` modes with fixed
`data/rtx/article-20261007/bounded-v1` paths. It requires the six complete original
v4 scouts, pinned runtime/inputs, guard and measurement lock. That evidence is
absent here. Existing outputs are immutable single attempts; no output,
condition, automatic-retry or overwrite option is supplied. Internal budget:
7,920 seconds. Outer primary guard: 15,480 seconds. Freeze guard: 600 seconds.
The failed original attempt is not resumed by this archive.

Reader helpers use the existing source and toolchain and build only the new
`data/rtx/reproduction-20261007/build`. The reader driver permits one 2K/all
request under a 600-second guard, with fresh paths and pre/post verification.
This is a same-lab fresh-build check, not a new OS, independently installed
toolchain or cold-cache benchmark. The actual separate reader completed with build/request host and guest guard
exits 0, server exit 0, strict raw checks and matched pre/post bindings. Its input
count was 1792 and output count 128. That success does not repair primary
post-binding or the incomplete 16K attempt.

`check_package.py`'s handoff-integrity CLI and the Prepare CLI depend on private
handoff, Mac-plan and package documents omitted here. They are unsupported
archive setup commands. The former's `verify_file` import remains necessary;
the source was not altered to hide its other dependencies. Original strict
validation also needs byte-bound raw evidence and runtime receipts absent from
this archive. Sanitized derivatives cannot inherit an original PASS.

## Licensing and publication

No project-wide VRAMLab `LICENSE` or new grant is supplied. This document does
not assign MIT or Apache-2.0 to these scripts. The external llama.cpp engine has
its own MIT license; the input lock records Apache-2.0 for the external model.
Neither dependency is included, and neither license is transferred to VRAMLab's
own scripts. Licensing/publication review remains pending.
