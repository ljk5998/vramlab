set -euo pipefail
test "$(uname -s)" = Darwin
test "$(uname -m)" = arm64
xcode-select -p
python3 -c 'import platform, shutil, sys; assert platform.machine() == "arm64" and sys.version_info >= (3, 9); assert shutil.disk_usage(".").free >= 25 * 1024**3'
VRAMLAB_RUN="$(mktemp -d "$PWD/vramlab-m4.XXXXXX")"
export VRAMLAB_RUN
python3 -m venv "$VRAMLAB_RUN/tools"
"$VRAMLAB_RUN/tools/bin/python" -m pip --disable-pip-version-check \
  install --no-cache-dir cmake==4.1.3

VRAMLAB_BASE="${VRAMLAB_ARTIFACT_BASE:-https://vramlab.com}"
curl --fail --location --retry 3 \
  "$VRAMLAB_BASE/code/m4-context-toolkit-20260910.zip" \
  --output "$VRAMLAB_RUN/toolkit.zip"
"$VRAMLAB_RUN/tools/bin/python" - <<'PY'
import hashlib, os, zipfile
from pathlib import Path
root = Path(os.environ["VRAMLAB_RUN"])
archive = root / "toolkit.zip"
assert hashlib.sha256(archive.read_bytes()).hexdigest() == "3c17f976a9cb363df40051e6e2e8df94c532ca3d9ad9354bc42d22dee79c9b0f"
destination = root / "package"
assert not destination.exists()
with zipfile.ZipFile(archive) as z:
    assert all(not Path(n).is_absolute() and ".." not in Path(n).parts for n in z.namelist())
    z.extractall(destination)
PY
VRAMLAB_PACKAGE="$VRAMLAB_RUN/package"
VRAMLAB_DATA="$VRAMLAB_PACKAGE/data/mac"
mkdir -p "$VRAMLAB_DATA/models"

VRAMLAB_MODEL="$VRAMLAB_DATA/models/Qwen3-8B-Q4_K_M.gguf"
test ! -e "$VRAMLAB_MODEL"
if [ -n "${VRAMLAB_EXISTING_MODEL:-}" ]; then
  cp -n "$VRAMLAB_EXISTING_MODEL" "$VRAMLAB_MODEL"
else
  curl --fail --location --retry 3 \
    "https://huggingface.co/Qwen/Qwen3-8B-GGUF/resolve/7c41481f57cb95916b40956ab2f0b139b296d974/Qwen3-8B-Q4_K_M.gguf" \
    --output "$VRAMLAB_MODEL.part"
  mv -n "$VRAMLAB_MODEL.part" "$VRAMLAB_MODEL"
fi
"$VRAMLAB_RUN/tools/bin/python" - "$VRAMLAB_MODEL" <<'PY'
import hashlib, sys
from pathlib import Path
p = Path(sys.argv[1])
assert p.stat().st_size == 5027783488
h = hashlib.sha256()
with p.open("rb") as f:
    for block in iter(lambda: f.read(4 * 1024 * 1024), b""):
        h.update(block)
assert h.hexdigest() == "d98cdcbd03e17ce47681435b5150e34c1417f50b5c0019dd560e4882c5745785"
print("locked model verified")
PY

test ! -e "$VRAMLAB_DATA/llama.cpp"
git init "$VRAMLAB_DATA/llama.cpp"
git -C "$VRAMLAB_DATA/llama.cpp" remote add origin \
  https://github.com/ggml-org/llama.cpp.git
git -C "$VRAMLAB_DATA/llama.cpp" fetch --depth 1 origin \
  e5a8d439cef31f27fad6938233da10dae1ba5631
git -C "$VRAMLAB_DATA/llama.cpp" checkout --detach FETCH_HEAD
"$VRAMLAB_RUN/tools/bin/cmake" \
  -S "$VRAMLAB_DATA/llama.cpp" -B "$VRAMLAB_DATA/build-metal" \
  -DGGML_METAL=ON -DCMAKE_BUILD_TYPE=Release
"$VRAMLAB_RUN/tools/bin/cmake" --build "$VRAMLAB_DATA/build-metal" \
  --config Release --target llama-server -j 4
"$VRAMLAB_DATA/build-metal/bin/llama-server" --list-devices

caffeinate -i -s "$VRAMLAB_RUN/tools/bin/python" -B \
  "$VRAMLAB_PACKAGE/scripts/mac_measure.py" reader \
  --protocol "$VRAMLAB_PACKAGE/protocol-mac-v2.json" \
  --context 2048 --out "$VRAMLAB_DATA/reader-2k"
