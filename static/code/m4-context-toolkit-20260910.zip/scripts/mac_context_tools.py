#!/usr/bin/env python3
"""Read-only preparation and bounded, excluded MAC-CONTEXT scouts; never primary runs."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import signal
import socket
import statistics
import subprocess
import sys
import threading
import time
import urllib.request
import unicodedata

PACKAGE = Path(__file__).resolve().parents[1]
DATA = PACKAGE / "data/mac"
ENV = {"PATH": "/usr/bin:/bin:/usr/sbin:/sbin", "LC_ALL": "C", "LANG": "C"}
CONTEXTS = (2048, 4096, 8192, 16384)


def within_data(path, root=DATA):
    # APFS resolves Korean NFC/NFD spellings to the same path, while Path compares text.
    resolved = Path(unicodedata.normalize("NFC", str(Path(path).resolve())))
    parent = Path(unicodedata.normalize("NFC", str(Path(root).resolve())))
    return resolved != parent and resolved.is_relative_to(parent)


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(4 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def command(argv, timeout=5):
    p = subprocess.run([str(x) for x in argv], env=ENV, capture_output=True,
                       text=True, timeout=timeout)
    if p.returncode:
        raise RuntimeError(f"{argv[0]} exit {p.returncode}: {p.stderr.strip()}")
    return p.stdout


def parse_vm(raw):
    m = re.search(r"page size of (\d+) bytes", raw)
    if not m:
        raise ValueError("vm_stat page size missing")
    page = int(m[1])
    counts = {k.strip().strip('"'): int(v) for k, v in
              re.findall(r'^([^:\n]+):\s+(\d+)\.', raw, re.M)}
    required = ("Pages occupied by compressor", "Pages stored in compressor",
                "Pageouts", "Swapouts")
    if any(k not in counts for k in required):
        raise ValueError("vm_stat counters missing")
    return {"page_bytes": page, "pages": counts,
            "compressed_physical_bytes": counts[required[0]] * page,
            "compressor_logical_bytes": counts[required[1]] * page,
            "pageouts_cumulative_bytes": counts[required[2]] * page,
            "swapouts_cumulative_bytes": counts[required[3]] * page}


def parse_swap(raw):
    m = re.search(r"\bused\s*=\s*([0-9.]+)([KMGT])", raw)
    if not m:
        raise ValueError("swap used unavailable")
    return round(float(m[1]) * 1024 ** ("KMGT".index(m[2]) + 1))


def snapshot(pid=None):
    start = time.monotonic()
    vm = command(["/usr/bin/vm_stat"])
    swap = command(["/usr/sbin/sysctl", "vm.swapusage"])
    pressure = command(["/usr/sbin/sysctl", "-n", "kern.memorystatus_vm_pressure_level"])
    # This sysctl exports NOTE_MEMORYSTATUS_* dispatch values, not internal VM enums.
    level = int(pressure.strip())
    if level not in (1, 2, 4):
        raise ValueError("unknown pressure dispatch value")
    rss = None
    rss_raw = None
    if pid is not None:
        p = subprocess.run(["/bin/ps", "-o", "rss=", "-p", str(pid)],
                           env=ENV, capture_output=True, text=True, timeout=3)
        if p.returncode == 0 and p.stdout.strip():
            rss_raw = p.stdout
            rss = int(p.stdout.strip()) * 1024  # local ps(1): 1024-byte units
    power_raw = command(["/usr/bin/pmset", "-g", "batt"])
    power_source = "ac" if "Now drawing from 'AC Power'" in power_raw else "battery" if "Now drawing from 'Battery Power'" in power_raw else "unknown"
    return {"monotonic": start, "sample_duration_s": time.monotonic() - start,
            "power_source": power_source,
            "vm_stat_raw": vm, "swap_raw": swap, "pressure_raw": pressure,
            "vm": parse_vm(vm), "swap_used_bytes": parse_swap(swap),
            "pressure_dispatch": level, "process_rss_bytes": rss, "rss_raw": rss_raw}


def safety_reason(sample, baseline_swap, free_bytes):
    if sample["pressure_dispatch"] != 1:
        return "pressure_warning_or_critical"
    if sample["swap_used_bytes"] - baseline_swap >= 1024 ** 3:
        return "swap_increase_1_GiB"
    if free_bytes < 5 * 1024 ** 3:
        return "disk_below_5_GiB"
    return None


def deadline_reason(now, request_start, first_content):
    if now - request_start > 180:
        return "request_timeout_180_seconds"
    if first_content is None and now - request_start > 120:
        return "first_content_timeout_120_seconds"
    return None


def server_args(server, model, context, port):
    return [str(server), "--model", str(model), "--host", "127.0.0.1",
            "--port", str(port), "--ctx-size", str(context), "--gpu-layers", "all",
            "--fit", "off", "--parallel", "1", "--cache-type-k", "f16",
            "--cache-type-v", "f16", "--flash-attn", "on", "--batch-size", "512",
            "--ubatch-size", "128", "--threads", "4", "--threads-batch", "4",
            "--no-cache-prompt", "--no-context-shift", "--perf", "-lv", "4",
            "--cors-origins", "http://127.0.0.1:" + str(port)]


def fixture():
    header = "Synthetic English lab notebook for token-length instrumentation. No real observations.\n"
    return header + "".join(
        f"Entry {i:05d}. The fictional team labels sample {i % 17:02d}, records its location, "
        "checks the instrument log, and leaves the result unmeasured. "
        "This repeated passage is synthetic input, not a question answering benchmark.\n"
        for i in range(1200))


def readiness(out):
    out.mkdir(parents=True, exist_ok=False)
    lock = json.loads((PACKAGE / "inputs.lock.json").read_text())
    from check_package import check_package, verify_file
    check_package()
    if platform.system() != "Darwin" or platform.machine() != "arm64":
        raise RuntimeError("native arm64 macOS required")
    hardware = {k: command(["/usr/sbin/sysctl", "-n", k]).strip() for k in
                ("machdep.cpu.brand_string", "hw.memsize", "hw.model", "hw.physicalcpu", "hw.logicalcpu")}
    if hardware["machdep.cpu.brand_string"] != "Apple M4" or hardware["hw.memsize"] != "17179869184":
        raise RuntimeError("planned M4 / 16 GiB host mismatch")
    model = DATA / "models" / lock["model"]["filename"]
    source = DATA / "llama.cpp"
    build = DATA / "build-metal"
    model_sha = verify_file(model, lock["model"]["bytes"], lock["model"]["sha256"])
    commit = command(["/usr/bin/git", "-C", source, "rev-parse", "HEAD"]).strip()
    status = command(["/usr/bin/git", "-C", source, "status", "--porcelain"])
    if commit != lock["llama_cpp"]["commit"] or status:
        raise RuntimeError("runtime source revision/cleanliness mismatch")
    binaries = {}
    for name in ("llama-server", "llama-bench"):
        binary = build / "bin" / name
        binaries[name] = {"sha256": digest(binary), "file": command(["/usr/bin/file", binary]),
                          "libraries": command(["/usr/bin/otool", "-L", binary])}
        if "arm64" not in binaries[name]["file"]:
            raise RuntimeError("binary is not arm64")
    server = build / "bin/llama-server"
    probes = {}
    for flag in ("--version", "--help", "--list-devices"):
        p = subprocess.run([str(server), flag], env=ENV, capture_output=True, text=True, timeout=60)
        raw = p.stdout + p.stderr
        (out / (flag[2:] + ".txt")).write_text(raw)
        if p.returncode:
            raise RuntimeError(f"server probe failed: {flag}")
        probes[flag] = raw
    if not re.search(r"MTL\d+: Apple M4\b", probes["--list-devices"]):
        raise RuntimeError("Apple M4 Metal device not reported")
    flags = server_args(server, model, 2048, 8080)
    for flag in [s for s in flags if s.startswith("--")]:
        if flag not in probes["--help"]:
            raise RuntimeError(f"pinned server flag missing: {flag}")
    dylibs = {p.name: {"sha256": digest(p), "libraries": command(["/usr/bin/otool", "-L", p])}
              for p in sorted((build / "bin").glob("*.dylib"))}
    samples = []
    begin = time.monotonic()
    with (out / "baseline.jsonl").open("w") as f:
        for i in range(31):
            sample = snapshot()
            samples.append(sample)
            f.write(json.dumps(sample) + "\n")
            f.flush()
            if i < 30:
                time.sleep(max(0, begin + i + 1 - time.monotonic()))
    gpu_raw = json.loads(command(["/usr/sbin/system_profiler", "SPDisplaysDataType", "-json"], 30))
    gpu = [{k: row.get(k) for k in ("sppci_model", "sppci_cores")}
           for row in gpu_raw.get("SPDisplaysDataType", [])]
    result = {"schema_version": 1, "stage": "environment_prepared_not_measured",
              "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
              "hardware": hardware, "gpu": gpu, "os": command(["/usr/bin/sw_vers"]),
              "python": sys.version, "power": command(["/usr/bin/pmset", "-g", "batt"]),
              "power_modes": "\n".join(line for line in command(["/usr/bin/pmset", "-g", "custom"]).splitlines()
                                        if "Power:" in line or "lowpowermode" in line),
              "disk_free_bytes": shutil.disk_usage(DATA).free,
              "source_commit": commit, "source_clean": not status,
              "model_sha256": model_sha, "model_bytes": model.stat().st_size,
              "inputs_lock_sha256": digest(PACKAGE / "inputs.lock.json"),
              "cmake_cache_sha256": digest(build / "CMakeCache.txt"),
              "binaries": binaries, "dylibs": dylibs, "server_environment": ENV,
              "baseline_duration_s": samples[-1]["monotonic"] - samples[0]["monotonic"],
              "swap_used_range_bytes": [min(x["swap_used_bytes"] for x in samples), max(x["swap_used_bytes"] for x in samples)],
              "pressure_dispatch_values": sorted(set(x["pressure_dispatch"] for x in samples)),
              "model_loaded": False, "scouts_run": 0, "primary_trials_run": 0}
    write_json(out / "manifest.json", result)
    return result


def kill_group(process):
    if process is None:
        return
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    try:
        process.wait(timeout=2)
    except subprocess.TimeoutExpired:
        pass
    # Also terminate descendants that ignored TERM even if the group leader exited.
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    process.wait(timeout=3)


def stop_timed_server(process, child_pid):
    # Let time(1) reap its child and write rusage before cleaning the remaining group.
    if process is not None and child_pid is not None and process.poll() is None:
        try:
            os.kill(child_pid, signal.SIGINT)
            process.wait(timeout=3)
        except (ProcessLookupError, subprocess.TimeoutExpired):
            pass
    kill_group(process)


def http_json(base, endpoint, payload=None, timeout=5):
    data = None if payload is None else json.dumps(payload).encode()
    req = urllib.request.Request(base + endpoint, data=data,
                                 headers={"Content-Type": "application/json"})
    # Local connections never inherit proxies or credentials.
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(req, timeout=timeout) as r:
        return json.load(r)


def stream_completion(base, request, path, shared):
    shared["request_start"] = time.monotonic()
    try:
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        req = urllib.request.Request(base + "/completion", data=json.dumps(request).encode(),
                                     headers={"Content-Type": "application/json"})
        with path.open("w") as f, opener.open(req, timeout=185) as response:
            parts = []
            for raw in response:
                stamp = time.monotonic()
                line = raw.decode("utf-8").rstrip("\r\n")
                f.write(json.dumps({"monotonic": stamp, "line": line}) + "\n")
                f.flush()
                if line.startswith("data:"):
                    parts.append(line[5:].lstrip(" "))
                elif line == "" and parts:
                    payload = "\n".join(parts)
                    parts = []
                    if payload == "[DONE]":
                        break
                    event = json.loads(payload)
                    if "error" in event:
                        raise ValueError("server returned error event")
                    if event.get("content") and "first_content" not in shared:
                        shared["first_content"] = stamp
                    if event.get("stop") is True:
                        shared["final"] = event
                        shared["completion"] = stamp
                        break
            if "final" not in shared:
                raise ValueError("missing final completion event")
    except Exception as error:
        shared["error"] = f"{type(error).__name__}: {error}"
    finally:
        shared["done"] = True


def run_trial(out, context, power, phase="scout", frozen=None, runtime_root=None):
    """A prospectively labelled trial; primary requires a frozen protocol and inputs."""
    out.mkdir(parents=True, exist_ok=False)
    runtime = DATA if runtime_root is None else Path(runtime_root).resolve()
    result = {"schema_version": 2, "phase": phase, "context": context,
              "status": "failed", "warmup": "default server startup warmup; no extra completion",
              "primary_eligible": phase == "primary", "expected_prompt_tokens": context - 256,
              "expected_generated_tokens": 128, "power_condition": power}
    process = None
    collector_stop = threading.Event()
    sensor = {}
    collector = None
    worker = None
    try:
        lock = json.loads((PACKAGE / "inputs.lock.json").read_text())
        if phase not in ("scout", "primary", "reader"):
            raise ValueError("unsupported phase")
        if phase == "primary" and frozen is None:
            raise ValueError("primary requires frozen protocol")
        if frozen is not None:
            if context not in frozen["retained_contexts"]:
                raise ValueError("condition not retained by frozen protocol")
            if digest(Path(__file__)) != frozen["harness_sha256"]:
                raise ValueError("harness differs from frozen protocol")
            if digest(PACKAGE / "inputs.lock.json") != frozen["inputs_lock_sha256"]:
                raise ValueError("input lock differs from frozen protocol")
            result["protocol_sha256"] = frozen["protocol_sha256"]
            result["session_id"] = frozen["session_id"]
        if platform.system() != "Darwin" or platform.machine() != "arm64":
            raise RuntimeError("native macOS arm64 required")
        for key, expected in (("machdep.cpu.brand_string", "Apple M4"), ("hw.memsize", "17179869184")):
            if command(["/usr/sbin/sysctl", "-n", key]).strip() != expected:
                raise RuntimeError("host mismatch")
        model = runtime / "models" / lock["model"]["filename"]
        server = runtime / "build-metal/bin/llama-server"
        result["model_sha256"] = digest(model)
        if model.stat().st_size != lock["model"]["bytes"] or result["model_sha256"] != lock["model"]["sha256"]:
            raise ValueError("model differs from locked bytes/hash")
        result["binary_sha256"] = digest(server)
        result["runtime_files_before"] = {p.name: digest(p) for p in
                                           (runtime / "build-metal/bin").glob("*.dylib")}
        source = runtime / "llama.cpp"
        if command(["/usr/bin/git", "-C", source, "rev-parse", "HEAD"]).strip() != lock["llama_cpp"]["commit"] or command(["/usr/bin/git", "-C", source, "status", "--porcelain"]):
            raise RuntimeError("source revision/cleanliness mismatch")
        result["source_commit"] = lock["llama_cpp"]["commit"]
        result["inputs_lock_sha256"] = digest(PACKAGE / "inputs.lock.json")
        result["harness_sha256"] = digest(Path(__file__))
        result["power_modes_before"] = "\n".join(x for x in command(["/usr/bin/pmset", "-g", "custom"]).splitlines() if "Power:" in x or "lowpowermode" in x)
        if any(int(x) != 0 for x in re.findall(r"lowpowermode\s+(\d+)", result["power_modes_before"])):
            raise RuntimeError("low power mode enabled")
        result["power_before"] = command(["/usr/bin/pmset", "-g", "batt"])
        expected_power = "AC Power" if power == "ac" else "Battery Power"
        if f"Now drawing from '{expected_power}'" not in result["power_before"]:
            raise RuntimeError("power source differs from declared condition")
        baseline = []
        with (out / "baseline.jsonl").open("w") as f:
            start = time.monotonic()
            for i in range(31):
                s = snapshot()
                f.write(json.dumps(s) + "\n")
                f.flush()
                baseline.append(s)
                reason = safety_reason(s, baseline[0]["swap_used_bytes"], shutil.disk_usage(out).free)
                if reason:
                    raise RuntimeError("baseline: " + reason)
                if s["power_source"] != power:
                    raise RuntimeError("power source changed during baseline")
                if i < 30:
                    time.sleep(max(0, start + i + 1 - time.monotonic()))
        compressed = [x["vm"]["compressed_physical_bytes"] for x in baseline]
        swap = [x["swap_used_bytes"] for x in baseline]
        result["baseline_compressed_median_bytes"] = statistics.median(compressed)
        if frozen is not None:
            if max(compressed) - min(compressed) > frozen["baseline_compressed_range_limit_bytes"]:
                raise RuntimeError("baseline compressed memory not stable")
            if max(swap) - min(swap) > frozen["baseline_swap_range_limit_bytes"]:
                raise RuntimeError("baseline swap not stable")
            reference = frozen.get("session_baseline_compressed_bytes")
            if reference is not None and abs(statistics.median(compressed) - reference) > frozen["cross_trial_compressed_limit_bytes"]:
                raise RuntimeError("baseline differs from session reference; new session required")
        baseline_swap = statistics.median(x["swap_used_bytes"] for x in baseline)
        result["baseline_swap_bytes"] = baseline_swap
        with socket.socket() as port_socket:
            port_socket.bind(("127.0.0.1", 0))
            port = port_socket.getsockname()[1]
        base = f"http://127.0.0.1:{port}"
        args = server_args(server, model, context, port)
        result["command"] = args
        if frozen is not None:
            normalized = list(args)
            normalized[0] = "<SERVER>"
            normalized[normalized.index("--model") + 1] = "<MODEL>"
            normalized[normalized.index("--port") + 1] = "<PORT>"
            normalized[normalized.index("--ctx-size") + 1] = "<CONTEXT>"
            normalized[normalized.index("--cors-origins") + 1] = "http://127.0.0.1:<PORT>"
            if normalized != frozen["server_command_template"]:
                raise ValueError("server options differ from frozen protocol")
            if phase == "primary" and (result["binary_sha256"] != frozen["binary_sha256"] or result["runtime_files_before"] != frozen["runtime_files_sha256"]):
                raise ValueError("runtime differs from frozen primary build")
        result["environment"] = ENV
        result["launch_monotonic"] = time.monotonic()
        with (out / "server.stdout").open("w") as stdout, (out / "server.stderr").open("w") as stderr:
            process = subprocess.Popen(["/usr/bin/time", "-l", "-o", str(out / "time.txt")] + args,
                                       stdout=stdout, stderr=stderr, env=ENV, start_new_session=True)
        result["process_group"] = process.pid

        def collect():
            try:
                pid = None
                tick = time.monotonic()
                with (out / "memory.jsonl").open("w") as f:
                    while not collector_stop.is_set():
                        if pid is None:
                            p = subprocess.run(["/usr/bin/pgrep", "-P", str(process.pid)],
                                               env=ENV, text=True, capture_output=True, timeout=2)
                            children = p.stdout.split()
                            if len(children) == 1:
                                pid = int(children[0])
                                result["server_pid"] = pid
                        s = snapshot(pid)
                        f.write(json.dumps(s) + "\n")
                        f.flush()
                        sensor["last_sample"] = time.monotonic()
                        reason = safety_reason(s, baseline_swap, shutil.disk_usage(out).free)
                        if s["power_source"] != power:
                            reason = "power_source_changed"
                        if reason:
                            sensor["abort"] = reason
                            return
                        tick += 1
                        collector_stop.wait(max(0, tick - time.monotonic()))
            except Exception as error:
                sensor["abort"] = f"collector_failed: {error}"

        collector = threading.Thread(target=collect, daemon=True)
        collector.start()

        def supervise():
            if sensor.get("abort"):
                raise RuntimeError(sensor["abort"])
            if time.monotonic() - sensor.get("last_sample", result["launch_monotonic"]) > 8:
                raise RuntimeError("collector_stale_over_8_seconds")
            if process.poll() is not None:
                raise RuntimeError(f"server exited {process.returncode}")

        while True:
            supervise()
            if time.monotonic() - result["launch_monotonic"] > 120:
                raise TimeoutError("startup_timeout_120_seconds")
            try:
                health = http_json(base, "/health", timeout=1)
                if health.get("status") == "ok":
                    result["health"] = health
                    result["ready_monotonic"] = time.monotonic()
                    break
            except (OSError, ValueError):
                pass
            time.sleep(.1)
        # Full startup validation is also performed independently from saved logs.
        logs = (out / "server.stderr").read_text()
        offload = re.search(r"offloaded (\d+)/(\d+) layers to GPU", logs)
        if not offload or offload[1] != offload[2] or int(offload[1]) == 0 or "ggml_metal" not in logs:
            raise ValueError("full Metal offload not established")
        if not re.search(rf"n_ctx\s*=\s*{context}\b", logs):
            raise ValueError("effective context mismatch")
        text = fixture()
        (out / "fixture.txt").write_text(text)
        if frozen is None:
            tokens = http_json(base, "/tokenize", {"content": text, "add_special": True,
                                                  "parse_special": False}, timeout=5)["tokens"]
        else:
            fixture_path = PACKAGE / frozen["tokenizer_path"]
            if digest(fixture_path) != frozen["tokenizer_sha256"]:
                raise ValueError("frozen tokenizer arrays changed")
            if digest(out / "fixture.txt") != frozen["fixture_sha256"]:
                raise ValueError("synthetic fixture generator changed")
            tokens = json.loads(fixture_path.read_text())["tokens"]
            # Tokenizer is still bound to the real pinned model; input file supplies the exact prefix.
            result["frozen_tokenizer_sha256"] = frozen["tokenizer_sha256"]
        if len(tokens) < context - 256 or any(type(x) is not int for x in tokens):
            raise ValueError("tokenizer response invalid/too short")
        write_json(out / "tokenizer.json", {"tokens": tokens, "add_special": True, "parse_special": False})
        request = {"prompt": tokens[:context - 256], "stream": True, "cache_prompt": False,
                   "n_predict": 128, "temperature": 0, "seed": 20260910,
                   "ignore_eos": True, "return_tokens": True}
        write_json(out / "request.json", request)
        shared = {}
        result["transport"] = shared
        worker = threading.Thread(target=stream_completion,
                                  args=(base, request, out / "sse.jsonl", shared), daemon=True)
        worker.start()
        while not shared.get("done"):
            supervise()
            reason = deadline_reason(time.monotonic(), shared.get("request_start", time.monotonic()),
                                     shared.get("first_content"))
            if reason:
                raise TimeoutError(reason)
            time.sleep(.1)
        result["transport"] = shared
        if shared.get("error"):
            raise ValueError(shared["error"])
        result["power_after"] = command(["/usr/bin/pmset", "-g", "batt"])
        if f"Now drawing from '{expected_power}'" not in result["power_after"]:
            raise ValueError("power source changed")
        result["status"] = "transport_complete_pending_validation"
    except BaseException as error:
        result["error"] = f"{type(error).__name__}: {error}"
    finally:
        stop_timed_server(process, result.get("server_pid"))
        if worker is not None:
            worker.join(timeout=5)
            if worker.is_alive():
                result["status"] = "failed"
                result["error"] = "SSE worker did not stop"
        result["exit_code"] = None if process is None else process.returncode
        collector_stop.set()
        if collector is not None:
            collector.join(timeout=10)
            if collector.is_alive():
                result["status"] = "failed"
                result["error"] = "collector did not stop"
        try:
            with (out / "recovery.jsonl").open("w") as f:
                for _ in range(30 if frozen is not None else 10):
                    f.write(json.dumps(snapshot()) + "\n")
                    f.flush()
                    time.sleep(1)
        except Exception as error:
            result["recovery_error"] = str(error)
        if result["status"] == "transport_complete_pending_validation":
            try:
                result["model_sha256_after"] = digest(model)
                result["binary_sha256_after"] = digest(server)
                result["runtime_files_after"] = {p.name: digest(p) for p in
                                                 (runtime / "build-metal/bin").glob("*.dylib")}
                result["source_clean_after"] = not command(["/usr/bin/git", "-C", source, "status", "--porcelain"])
            except Exception as error:
                result["status"] = "failed"
                result["error"] = "post-run verification failed: " + str(error)
        result["completed_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        result["file_sha256"] = {p.name: digest(p) for p in out.iterdir() if p.is_file()}
        write_json(out / "result.json", result)
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="mode", required=True)
    ready = sub.add_parser("readiness", help="verify inputs/build and collect 30s idle baseline; no model load")
    ready.add_argument("--out", type=Path, required=True)
    run = sub.add_parser("scout", help="one excluded GPU scout, requires an explicit power condition")
    run.add_argument("--out", type=Path, required=True)
    run.add_argument("--context", type=int, choices=CONTEXTS, default=2048)
    run.add_argument("--power-condition", choices=("ac", "battery"), required=True)
    a = p.parse_args()
    # Raw observations must remain in the ignored local data tree.
    out = a.out.resolve()
    if not within_data(out):
        p.error("--out must be under this package's ignored data/mac directory")
    if a.mode == "readiness":
        result = readiness(out)
    else:
        result = run_trial(out, a.context, a.power_condition)
    print(json.dumps({"output": str(out), "stage": result.get("stage"),
                      "status": result.get("status"), "error": result.get("error")}, indent=2))
    return int(result.get("status") == "failed")


if __name__ == "__main__":
    raise SystemExit(main())
