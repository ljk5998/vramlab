#!/usr/bin/env python3
"""Independent raw-file validator for excluded Mac scouts. Does not launch a model."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import statistics


def check(condition, message):
    if not condition:
        raise ValueError(message)


def file_sha(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(4 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def read_events(path):
    events, parts = [], []
    previous = float("-inf")
    for line in path.read_text().splitlines():
        row = json.loads(line)
        check(row["monotonic"] >= previous, "SSE clock moved backwards")
        previous = row["monotonic"]
        raw = row["line"]
        if raw.startswith("data:"):
            parts.append(raw[5:].lstrip(" "))
        elif not raw and parts:
            payload = "\n".join(parts)
            parts = []
            if payload == "[DONE]":
                continue
            event = json.loads(payload)
            check(isinstance(event, dict), "non-object SSE response")
            check("error" not in event, "server error response")
            events.append((row["monotonic"], event))
    check(not parts, "unterminated SSE event")
    return events


def validate_response(request, events):
    check(bool(events), "no SSE events")
    finals = [(t, e) for t, e in events if e.get("stop") is True]
    check(len(finals) == 1, "expected exactly one final event")
    final_time, final = finals[0]
    check(events[-1] == finals[0], "events after final response")
    contents = [t for t, e in events if isinstance(e.get("content"), str) and e["content"]]
    check(bool(contents), "no generated content")
    check(final.get("tokens_evaluated") == len(request["prompt"]), "evaluated prompt count mismatch")
    check(final.get("tokens_predicted") == request["n_predict"], "generated count mismatch")
    raw_tokens = []
    for _, event in events:
        tokens = event.get("tokens", [])
        check(isinstance(tokens, list) and all(type(x) is int for x in tokens), "malformed output tokens")
        raw_tokens.extend(tokens)
    check(len(raw_tokens) == request["n_predict"], "streamed output token count mismatch")
    check(final.get("stop_type") == "limit", "unexpected stop type")
    check(final.get("truncated") is False, "truncated or missing truncation flag")
    timings = final.get("timings", {})
    for field in ("prompt_ms", "predicted_ms", "prompt_per_second", "predicted_per_second"):
        check(isinstance(timings.get(field), (int, float)) and timings[field] > 0,
              "missing/non-positive server timing: " + field)
    check(timings.get("cache_n") == 0, "prompt cache was used or unreported")
    check(timings.get("prompt_n") == len(request["prompt"]), "server prompt timing count mismatch")
    check(timings.get("predicted_n") == request["n_predict"], "server decode timing count mismatch")
    return {"first_content_monotonic": contents[0], "completion_monotonic": final_time,
            "evaluated_tokens": final["tokens_evaluated"], "generated_tokens": len(raw_tokens),
            "server_timings": timings}


def validate(directory, expected_phase="scout", protocol_path=None):
    directory = directory.resolve()
    result = json.loads((directory / "result.json").read_text())
    lock = json.loads((Path(__file__).resolve().parents[1] / "inputs.lock.json").read_text())
    check(result.get("model_sha256") == lock["model"]["sha256"], "model differs from input lock")
    check(result.get("source_commit") == lock["llama_cpp"]["commit"], "source differs from input lock")
    check(result.get("phase") == expected_phase, "trial phase mismatch")
    check(result.get("primary_eligible") is (expected_phase == "primary"), "primary eligibility mismatch")
    if protocol_path is not None:
        protocol_path = Path(protocol_path)
        protocol = json.loads(protocol_path.read_text())
        check(result.get("protocol_sha256") == file_sha(protocol_path), "protocol hash mismatch")
        check(result.get("harness_sha256") == protocol["harness_sha256"], "harness differs from frozen protocol")
        check(result.get("inputs_lock_sha256") == protocol["inputs_lock_sha256"], "input lock changed")
        check(result.get("frozen_tokenizer_sha256") == protocol["tokenizer_sha256"], "token arrays not bound")
        if expected_phase == "primary":
            check(result.get("binary_sha256") == protocol["binary_sha256"], "primary binary changed")
            check(result.get("runtime_files_before") == protocol["runtime_files_sha256"], "primary libraries changed")
    elif expected_phase == "primary":
        raise ValueError("primary validation requires frozen protocol")
    check(result.get("status") == "transport_complete_pending_validation", "run did not complete transport")
    check(result.get("model_sha256") == result.get("model_sha256_after") and result.get("model_sha256"), "model changed")
    check(result.get("binary_sha256") == result.get("binary_sha256_after") and result.get("binary_sha256"), "binary changed")
    check(result.get("runtime_files_before") == result.get("runtime_files_after") and result.get("runtime_files_before"), "libraries changed")
    check(result.get("source_clean_after") is True, "source changed during run")
    check(not result.get("recovery_error"), "recovery collection failed")
    time_raw = (directory / "time.txt").read_text()
    maxrss = re.search(r"(\d+)\s+maximum resident set size", time_raw)
    check(maxrss is not None, "time(1) peak RSS unavailable")
    for name, expected in result["file_sha256"].items():
        path = directory / name
        check(path.resolve().parent == directory, "unsafe artifact path")
        check(file_sha(path) == expected, "artifact hash mismatch: " + name)
    request = json.loads((directory / "request.json").read_text())
    context = result["context"]
    check(context in (2048, 4096, 8192, 16384), "context outside design")
    check(len(request["prompt"]) == context - 256, "wrong input length")
    check(all(type(x) is int for x in request["prompt"]), "non-integer prompt tokens")
    expected = {"stream": True, "cache_prompt": False, "n_predict": 128, "temperature": 0,
                "seed": 20260910, "ignore_eos": True, "return_tokens": True}
    check(all(request.get(k) == v for k, v in expected.items()), "request settings drift")
    tokenizer = json.loads((directory / "tokenizer.json").read_text())
    check(tokenizer["tokens"][:context - 256] == request["prompt"], "token prefix mismatch")
    args = result["command"]
    expected_flags = {"--host": "127.0.0.1", "--ctx-size": str(context), "--gpu-layers": "all",
                      "--fit": "off", "--parallel": "1", "--cache-type-k": "f16",
                      "--cache-type-v": "f16", "--flash-attn": "on", "--batch-size": "512",
                      "--ubatch-size": "128", "--threads": "4", "--threads-batch": "4"}
    for flag, value in expected_flags.items():
        check(args.count(flag) == 1 and args[args.index(flag) + 1] == value, "server flag drift: " + flag)
    check(all(flag in args for flag in ("--no-cache-prompt", "--no-context-shift", "--perf")), "missing control flags")
    check(args[args.index("-lv") + 1] == "4", "wrong logging condition")
    check(args[args.index("--cors-origins") + 1] == "http://127.0.0.1:" + args[args.index("--port") + 1], "wrong local CORS condition")
    log = (directory / "server.stderr").read_text()
    offload = re.search(r"offloaded (\d+)/(\d+) layers to GPU", log)
    check(offload is not None and int(offload[1]) > 0 and offload[1] == offload[2], "partial/no GPU offload")
    check("ggml_metal" in log and "Apple M4" in log, "M4 Metal not observed")
    check(re.search(rf"n_ctx\s*=\s*{context}\b", log), "effective context mismatch")
    check(re.search(rf"n_ctx_seq\s*=\s*{context}\b", log), "effective per-sequence context mismatch")
    check(re.search(r"flash_attn\s*=\s*(?:enabled|on)\b", log), "flash attention not observed enabled")
    check(re.search(r"K \(f16\):.*V \(f16\):", log), "F16 KV buffers not observed")
    rows = [json.loads(x) for x in (directory / "baseline.jsonl").read_text().splitlines()]
    check(len(rows) >= 30 and rows[-1]["monotonic"] - rows[0]["monotonic"] >= 29.9, "baseline shorter than 30 seconds")
    memory = [json.loads(x) for x in (directory / "memory.jsonl").read_text().splitlines()]
    check(len(memory) > 1, "missing memory series")
    for sample in rows + memory:
        raw = sample["vm_stat_raw"]
        page_match = re.search(r"page size of (\d+) bytes", raw)
        check(page_match is not None, "raw page size absent")
        page_size = int(page_match[1])
        for field, label in (("compressed_physical_bytes", "Pages occupied by compressor"),
                             ("pageouts_cumulative_bytes", "Pageouts"),
                             ("swapouts_cumulative_bytes", "Swapouts")):
            match = re.search(r"^" + re.escape(label) + r":\s*(\d+)\.", raw, re.M)
            check(match is not None and int(match[1]) * page_size == sample["vm"][field], "raw vm_stat conversion mismatch")
        swap_match = re.search(r"\bused\s*=\s*([0-9.]+)([KMGT])", sample["swap_raw"])
        check(swap_match is not None, "raw swap missing")
        expected_swap = round(float(swap_match[1]) * 1024 ** ("KMGT".index(swap_match[2]) + 1))
        check(expected_swap == sample["swap_used_bytes"], "raw swap conversion mismatch")
        check(int(sample["pressure_raw"].strip()) == sample["pressure_dispatch"], "raw pressure mismatch")
        if expected_phase == "primary" and sample["process_rss_bytes"] is not None:
            check(int(sample["rss_raw"].strip()) * 1024 == sample["process_rss_bytes"], "raw ps RSS conversion mismatch")
    rss = [x["process_rss_bytes"] for x in memory if x["process_rss_bytes"] is not None]
    check(bool(rss), "target PID RSS not observed")
    check(all(x["pressure_dispatch"] == 1 for x in rows + memory), "pressure cutoff crossed")
    gaps = [b["monotonic"] - a["monotonic"] for a, b in zip(memory, memory[1:])]
    check(all(0 < x < 3 for x in gaps), "sampling interval gap >= 3 seconds or invalid ordering")
    base_swap = statistics.median(x["swap_used_bytes"] for x in rows)
    check(max(x["swap_used_bytes"] for x in memory) - base_swap < 1024 ** 3, "swap cutoff crossed")
    if expected_phase == "primary":
        check(all(x.get("power_source") == result["power_condition"] for x in rows + memory), "power changed")
        compressed = [x["vm"]["compressed_physical_bytes"] for x in rows]
        check(max(compressed) - min(compressed) <= protocol["baseline_compressed_range_limit_bytes"], "compressed baseline unstable")
        check(max(x["swap_used_bytes"] for x in rows) - min(x["swap_used_bytes"] for x in rows) <= protocol["baseline_swap_range_limit_bytes"], "swap baseline unstable")
    metrics = validate_response(request, read_events(directory / "sse.jsonl"))
    start = result["transport"]["request_start"]
    check(start <= metrics["first_content_monotonic"] <= metrics["completion_monotonic"], "request timing order invalid")
    metrics["client_first_content_latency_s"] = metrics.pop("first_content_monotonic") - start
    metrics["client_completion_s"] = metrics.pop("completion_monotonic") - start
    check(metrics["client_first_content_latency_s"] <= 120 and metrics["client_completion_s"] <= 180, "request time budget exceeded")
    metrics.update({"sampled_peak_rss_bytes": max(rss), "time_peak_rss_bytes": int(maxrss[1]),
                    "baseline_swap_bytes": base_swap,
                    "swap_used_peak_delta_bytes": max(x["swap_used_bytes"] for x in memory) - base_swap,
                    "max_sampling_gap_s": max(gaps)})
    # Quantitative memory summaries retain overlapping pools separately.
    buffer_rows = re.findall(r"(\S+) (model|KV|compute) buffer size =\s*([0-9.]+) MiB", log)
    buffers = {backend + "_" + kind + "_MiB": float(value) for backend, kind, value in buffer_rows}
    check(buffers.get("MTL0_KV_MiB") == context * 144 / 1024, "KV allocation inconsistent with this model")
    metrics["runtime_buffers_MiB"] = buffers
    metrics["model_load_and_startup_s"] = result["ready_monotonic"] - result["launch_monotonic"]
    baseline_comp = statistics.median(x["vm"]["compressed_physical_bytes"] for x in rows)
    comp = [x["vm"]["compressed_physical_bytes"] for x in memory]
    metrics.update({"baseline_compressed_bytes": baseline_comp,
                    "peak_compressed_bytes": max(comp),
                    "peak_compressed_delta_bytes": max(comp) - baseline_comp,
                    "end_compressed_delta_bytes": comp[-1] - baseline_comp,
                    "end_swap_delta_bytes": memory[-1]["swap_used_bytes"] - base_swap,
                    "pageouts_delta_bytes": memory[-1]["vm"]["pageouts_cumulative_bytes"] - rows[-1]["vm"]["pageouts_cumulative_bytes"],
                    "swapouts_delta_bytes": memory[-1]["vm"]["swapouts_cumulative_bytes"] - rows[-1]["vm"]["swapouts_cumulative_bytes"]})
    return {"status": expected_phase + "_raw_checks_passed", "primary_eligible": expected_phase == "primary",
            "limitations": ["Scope: " + expected_phase + "; protocol-bound: " + str(protocol_path is not None),
                            "Validation checks this run; aggregate and reader replay are separate gates.",
                            "System counters include other apps; sampled peaks can miss transients.",
                            "Three repeats and clean-room reproduction are separate future gates."],
            "metrics": metrics}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--phase", choices=("scout", "primary", "reader"), default="scout")
    parser.add_argument("--protocol", type=Path)
    args = parser.parse_args()
    try:
        print(json.dumps(validate(args.directory, args.phase, args.protocol), indent=2))
    except (OSError, ValueError, KeyError, IndexError, TypeError) as error:
        print(json.dumps({"status": "invalid", "error": str(error)}))
        raise SystemExit(1)
