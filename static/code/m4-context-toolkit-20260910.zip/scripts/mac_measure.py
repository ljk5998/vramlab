#!/usr/bin/env python3
"""Freeze and execute the MAC-CONTEXT protocol. Primary results are never scouts."""
import argparse
import json
from pathlib import Path
import statistics
import sys
import time

from mac_context_tools import PACKAGE, DATA, digest, run_trial, server_args, write_json
from validate_mac_scout import validate


def read_protocol(path):
    protocol = json.loads(path.read_text())
    protocol["protocol_sha256"] = digest(path)
    return protocol


def freeze(path):
    if path.exists():
        raise ValueError("protocol exists; never overwrite a frozen protocol")
    scouts = {2048: "scout-2k-02", 4096: "scout-4k-01", 8192: "scout-8k-01"}
    summaries = {str(context): validate(DATA / name) for context, name in scouts.items()}
    failure = json.loads((DATA / "scout-16k-01/result.json").read_text())
    if failure.get("error") != "TimeoutError: first_content_timeout_120_seconds":
        raise ValueError("16K exclusion evidence does not match")
    fixtures = PACKAGE / "fixtures"
    fixtures.mkdir(exist_ok=True)
    for name, src in (("mac-notebook.txt", "fixture.txt"), ("mac-notebook-tokens.json", "tokenizer.json")):
        dest = fixtures / name
        original = DATA / "scout-2k-02" / src
        if dest.exists():
            if digest(dest) != digest(original):
                raise ValueError("fixture destination differs")
        else:
            dest.write_bytes(original.read_bytes())
    for name in scouts.values():
        if digest(DATA / name / "tokenizer.json") != digest(fixtures / "mac-notebook-tokens.json"):
            raise ValueError("tokenizer outputs differ between scouts")
    baseline = json.loads((DATA / "scout-8k-01/result.json").read_text())
    template = server_args("<SERVER>", "<MODEL>", "<CONTEXT>", "<PORT>")
    order = [(2048, 1), (4096, 1), (8192, 1),
             (8192, 2), (2048, 2), (4096, 2),
             (4096, 3), (8192, 3), (2048, 3)]
    protocol = {
        "schema_version": 1, "status": "frozen_before_primary",
        "frozen_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "session_id": "mac-m4-ac-primary-20260910", "power_condition": "ac",
        "low_power_mode": 0, "retained_contexts": [2048, 4096, 8192],
        "original_contexts": [2048, 4096, 8192, 16384], "repetitions": 3,
        "exclusions": [{"context": 16384, "reason": "No first content within the predeclared 120-second budget during scout; larger condition held under the stop rule.",
                        "raw_result_sha256": digest(DATA / "scout-16k-01/result.json"),
                        "primary_repetitions_run": 0}],
        "order": [{"id": f"trial-{i:02d}-ctx-{ctx}-rep-{rep}", "context": ctx, "repetition": rep}
                  for i, (ctx, rep) in enumerate(order, 1)],
        "first_content_budget_s": 120, "request_budget_s": 180, "startup_budget_s": 120,
        "sample_cadence_s": 1, "baseline_duration_s": 30, "recovery_samples": 30,
        "baseline_compressed_range_limit_bytes": 128 * 1024**2,
        "baseline_swap_range_limit_bytes": 64 * 1024**2,
        "cross_trial_compressed_limit_bytes": 512 * 1024**2,
        "session_reference_rule": "Median compressed bytes in the first primary trial baseline; subsequent baselines must remain within 512 MiB, else pause and declare a new session.",
        "pressure_stop": "First sampled dispatch warning (2) or critical (4). This conservative rule is not the Activity Monitor color chart.",
        "swap_stop_delta_bytes": 1024**3, "minimum_disk_free_bytes": 5*1024**3,
        "cooling_rule": "After each request, stop the server, collect 30 recovery samples at one second; hash verification and the next 30-second baseline follow. No forced cache purge or app closure.",
        "baseline_failure_rule": "Stop the batch; preserve attempted rows. Do not silently rerun or replace trials.",
        "warmup": "Default server startup warmup, no additional completion; fresh process is not a cold OS cache.",
        "fixture_path": "fixtures/mac-notebook.txt",
        "fixture_sha256": digest(fixtures / "mac-notebook.txt"),
        "tokenizer_path": "fixtures/mac-notebook-tokens.json",
        "tokenizer_sha256": digest(fixtures / "mac-notebook-tokens.json"),
        "inputs_lock_sha256": digest(PACKAGE / "inputs.lock.json"),
        "harness_sha256": digest(PACKAGE / "scripts/mac_context_tools.py"),
        "validator_sha256": digest(PACKAGE / "scripts/validate_mac_scout.py"),
        "runner_sha256": digest(Path(__file__)),
        "binary_sha256": baseline["binary_sha256"],
        "runtime_files_sha256": baseline["runtime_files_before"],
        "server_command_template": template,
        "measurement_scope": "Near-filled-context sweep: both capacity and input token count change. Fixed Qwen3-8B Q4_K_M, F16 KV, 128 generated tokens, temperature 0. No answer-quality claim.",
        "scout_summaries": summaries,
        "background_condition": "AC connected, low power off; existing ordinary apps retained. One test server/request at a time. No site build, browser QA or other benchmark during primary trials. Agent text/status work and lightweight file reads continue.",
    }
    write_json(path, protocol)
    return {"protocol": str(path), "sha256": digest(path), "primary_trials_planned": len(order)}


def trial(protocol_path, out, phase, context):
    protocol = read_protocol(protocol_path)
    result = run_trial(out, context, protocol["power_condition"], phase=phase, frozen=protocol)
    if result["status"] != "transport_complete_pending_validation":
        raise RuntimeError(f"trial failed: {result.get('error')}; raw retained at {out}")
    checked = validate(out, phase, protocol_path)
    # Validation receipts live beside raw directories and cannot alter hashed trial artifacts.
    write_json(out.parent / (out.name + ".validation.json"), checked)
    return checked


def primary(protocol_path, out):
    out.mkdir(parents=True, exist_ok=False)
    protocol = read_protocol(protocol_path)
    for key, path in (("runner_sha256", Path(__file__)),
                      ("harness_sha256", PACKAGE / "scripts/mac_context_tools.py"),
                      ("validator_sha256", PACKAGE / "scripts/validate_mac_scout.py")):
        if digest(path) != protocol[key]:
            raise ValueError(f"frozen {key} changed")
    state = {"schema_version": 1, "phase": "primary", "status": "running",
             "protocol_sha256": digest(protocol_path), "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
             "trials": [], "session_baseline_compressed_bytes": None}
    write_json(out / "batch.json", state)
    for planned in protocol["order"]:
        trial_dir = out / planned["id"]
        print(json.dumps({"event": "start", **planned}), flush=True)
        protocol["session_baseline_compressed_bytes"] = state["session_baseline_compressed_bytes"]
        result = run_trial(trial_dir, planned["context"], protocol["power_condition"],
                           phase="primary", frozen=protocol)
        row = dict(planned, result_sha256=digest(trial_dir / "result.json"), status=result["status"])
        state["trials"].append(row)
        if result["status"] != "transport_complete_pending_validation":
            row["error"] = result.get("error")
            state["status"] = "stopped_on_failure"
            write_json(out / "batch.json", state)
            raise RuntimeError(f"primary stopped: {row}")
        try:
            checked = validate(trial_dir, "primary", protocol_path)
        except Exception as error:
            row["validation_error"] = str(error)
            state["status"] = "stopped_on_validation_failure"
            write_json(out / "batch.json", state)
            raise
        if state["session_baseline_compressed_bytes"] is None:
            state["session_baseline_compressed_bytes"] = checked["metrics"]["baseline_compressed_bytes"]
        row["metrics"] = checked["metrics"]
        row["status"] = "raw_checks_passed"
        write_json(out / (planned["id"] + ".validation.json"), checked)
        write_json(out / "batch.json", state)
        print(json.dumps({"event": "validated", "id": planned["id"], "metrics": checked["metrics"]}), flush=True)
    state["status"] = "all_retained_primary_trials_validated"
    state["completed_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    write_json(out / "batch.json", state)
    return {"status": state["status"], "completed": len(state["trials"])}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("freeze", "scout", "reader", "primary"))
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--out", type=Path)
    parser.add_argument("--context", type=int, choices=(2048, 4096, 8192), default=2048)
    args = parser.parse_args()
    if args.mode == "freeze":
        result = freeze(args.protocol)
    else:
        from mac_context_tools import within_data
        if args.out is None or not within_data(args.out):
            parser.error("fresh --out under ignored data/mac is required")
        out = args.out.resolve()
        result = primary(args.protocol, out) if args.mode == "primary" else trial(args.protocol, out, args.mode, args.context)
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
